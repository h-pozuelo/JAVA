/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[10];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println("INTRODUZCA NÚMERO " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();

        }

        Arrays.sort(numeros); // MODIFICA DE MANERA ASCENDENTE EL ORDEN DE LAS VARIABLES DEL OBJETO. 

        /*
        [CUANDO SE PASA UN OBJETO A UNA FUNCIÓN ESTE PUEDE SER MODIFICADO] 
        [CUANDO SE PASA UNA VARIABLE A UNA FUNCIÓN NO PUEDE SER MODIFICADO] 
        PASO POR VALOR: CUANDO SE PASA UNA VARIABLE [TIPO DE DATO SIMPLE] (COMO LO ES UN ENTERO) A UNA FUNCIÓN SE ESTÁ ALMACENANDO EN MEMORIA UNA COPIA DEL VALOR QUE TIENE ESA VARIABLE. DE ESTE MODO NUNCA SE MANIPULA LA DIRECCIÓN DE MEMORIA EN DONDE ESTÁ ALMACENADO DICHO VALOR. PARA ALTERAR EL VALOR DE UNA VARIABLE ES NECESARIO DEVOLVER (RETURN). 
        PASO POR REFERENCIA: CUANDO SE PASA UN OBJETO (COMO LO ES UN ARRAY) A UNA FUNCIÓN SE ESTÁ MANIPULACIÓN LA DIRECCIÓN DE MEMORIA EN DONDE ESTÁ ALMACENADO DICHO VALOR (EN ESTE CASO EL VALOR DE UNA CELDA DEL ARRAY). 
        AL MOMENTO DE CREAR UNA VARIABLE SE ALMACENA EN UNA DIRECCIÓN DE MEMORIA ALEATORIA. DEBIDO A ESTO NO ES POSIBLE LOCALIZAR Y MANIPULAR (SIN PUNTEROS) LOS DATOS GUARDADOS EN MEMORIA. 
        AL MOMENTO DE CREAR UNA LISTA (ARRAY) SE ALMACENAN EN DIRECCIONES DE MEMORIA SEGUIDAS CADA UNA DE LAS CELDAS QUE LA COMPONEN. DE ESTA FORMA ES POSIBLE LOCALIZAR Y MANIPULAR LOS DATOS GUARDADOS EN MEMORIA. 
         */
        
        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println(numeros[i]);

        }

        System.out.println("INTRODUZCA NÚMERO A BUSCAR: ");
        int numero = sc.nextInt();

        int posicion = Arrays.binarySearch(numeros, numero); // DADO QUE EL ARRAY SE ENCUENTRA YA ORDENADO ESTA BÚSQUEDA SE ENCARGA DE DIVIDIR EL ARRAY POR LA MITAD Y PREGUNTAR SI EL VALOR A BUSCAR SE ENCUENTRA POR ENCIMA O POR DEBAJO (ASÍ HASTA ENCONTRARLO). 

        if (posicion < 0) {
            System.out.println("NÚMERO NO ENCONTRADO. ");
        } else {
            System.out.println("EL NÚMERO SE ENCUENTRA EN LA POSICIÓN " + posicion + ".");
        }

    }

}
