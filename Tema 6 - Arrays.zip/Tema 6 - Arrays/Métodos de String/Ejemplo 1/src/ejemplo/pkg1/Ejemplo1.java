/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String entrada = "0.05$0.10$0.15$0.20$0.25$0.30$0.35$0.40$0.45$0.50";
        String salida[]; // DECLARO EL ARRAY DE SALIDA. 
        double resultado[]; // DECLARO EL ARRAY DE RESULTADO. 

        salida = entrada.split("[$]"); // CREO EL ARRAY DE SALIDA CON EL MÉTODO DE STRING. 
        resultado = new double[salida.length]; // CREO EL ARRAY DE RESULTADO CON LA LONGITUD DE SALIDA. 

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < salida.length; i += 1) {

            resultado[i] = Double.parseDouble(salida[i]); // TRANSFORMA EL FORMATO A DOUBLE PARA ALMACENARLO EN CADA CELDA DEL ARRAY DE RESULTADO. 

        }

        Arrays.sort(resultado);

        for (int i = 0; i < resultado.length; i += 1) {

            System.out.println(resultado[i]);

        }

    }

}
