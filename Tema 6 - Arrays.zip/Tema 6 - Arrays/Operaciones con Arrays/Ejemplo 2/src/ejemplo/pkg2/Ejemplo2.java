/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = {6, 2, 3, 87, 4, 34, 21, 31};

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        burbuja(numeros, numeros.length);

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println(numeros[i]);

        }

    }

    public static void burbuja(int v[], int TAM) { // SE PASA A LA FUNCIÓN UN VECTOR Y EL TAMAÑO DEL VECTOR QUE QUIERO ORDENAR. 

        int j, k, aux;

        for (j = 1; j < TAM; j += 1) {

            for (k = 0; k < TAM - j; k += 1) {

                // ASCENDENTE 
                if (v[k] > v[k + 1]) { // EN ESTE CASO ORDENA DE MENOR A MAYOR (COMO LO HACE LA FUNCIÓN SORT). PARA ORDENAR DE MANERA DESCENDENTE SOLO ES NECESARIO INVERTIR EL IF. 

                    aux = v[k];

                    v[k] = v[k + 1];

                    v[k + 1] = aux;

                }
                /*
                // DESCENDENTE 
                if (v[k] < v[k + 1]) {

                    aux = v[k];

                    v[k] = v[k + 1];

                    v[k + 1] = aux;

                }
                 */
            }

        }

    }

}
