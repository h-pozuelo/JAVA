/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num;
        int numeros[] = {6, 2, 3, 87, 4, 34, 21, 31};
        int tam = numeros.length;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < tam; i += 1) {

            System.out.println(numeros[i]);

        }

        System.out.println("INTRODUZCA ELEMENTO A ELIMINAR: ");
        num = sc.nextInt();

        for (int i = 0; i < tam; i += 1) { // DADO QUE NO PONGO EL <= NO HACE FALTA QUE PONGA EL -1. 

            if (num == numeros[i]) {

                for (int j = i; j < tam - 1; j += 1) { // COMIENZA A CONTAR DESDE EL VALOR DE LA VARIABLE i. EN ESTE CASO PONGO EL -1 (SIN PONER EL <=) DADO QUE LA ÚLTIMA CELDA LA VOY A ELIMINAR. 

                    numeros[j] = numeros[j + 1];

                }

                numeros[tam - 1] = 0; // SI DESEO ELIMINAR EL ÚLTIMO ELEMENTO (EL TAMAÑO 8 NO ES LO MISMO QUE EL NÚMERO DEL ÚLTIMO ELEMENTO 7). 

                tam -= 1; // COMO LUEGO UTILIZO ESTA VARIABLE PARA MOSTRAR EL VALOR DE CADA CELDA TENGO QUE DESCONTAR LA ÚLTIMA CELDA. 

                break;

            }

        }

        for (int i = 0; i < tam; i += 1) { // SI NO HUBIERA DESCONTADO LA ÚLTIMA CELDA ME APARECERÍA UN 0 AL SER MOSTRADA. 

            System.out.println(numeros[i]);

        }

    }

}
