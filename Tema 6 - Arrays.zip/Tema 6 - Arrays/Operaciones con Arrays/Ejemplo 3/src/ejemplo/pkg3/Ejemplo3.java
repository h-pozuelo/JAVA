/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = {6, 2, 3, 87, 4, 34, 21, 31};

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        quicksort(numeros, 0, numeros.length - 1); // LE PASO LA PRIMERA Y LA ÚLTIMA CELDA A ORDENAR. 

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println(numeros[i]);

        }

    }

    public static void quicksort(int array[], int izquierda, int derecha) {

        int pivote = array[izquierda];
        int i = izquierda;
        int j = derecha;
        int auxiliar;

        while (i < j) {

            // ASCENDENTE 
            while (array[i] <= pivote && i < j) {

                i += 1;

            }

            while (array[j] > pivote) {

                j -= 1;

            }
            /*
            // DESCENDENTE 
            while (array[i] >= pivote && i < j) {

                i += 1;

            }

            while (array[j] < pivote) {

                j -= 1;

            }
             */
            if (i < j) {

                auxiliar = array[i];
                array[i] = array[j];
                array[j] = auxiliar;

            }

        }

        array[izquierda] = array[j];
        array[j] = pivote;

        if (izquierda < j - 1) {

            quicksort(array, izquierda, j - 1);

        }

        if (j + 1 < derecha) {

            quicksort(array, j + 1, derecha);

        }

    }

}
