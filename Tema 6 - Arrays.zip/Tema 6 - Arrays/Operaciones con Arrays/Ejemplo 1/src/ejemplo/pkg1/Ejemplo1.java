/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[20];
        int longitud = 0; // NÚMERO DE CELDAS CON VALOR. 
        char respuesta;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println("INTRODUZCA NÚMERO: ");
            numeros[i] = sc.nextInt();

            if (i != numeros.length - 1) {

                sc.nextLine();

                System.out.println("¿DESEA INTRODUCIR OTRO NÚMERO?");
                respuesta = sc.nextLine().charAt(0);

                if (Character.toUpperCase(respuesta) == 'N') {

                    longitud = i + 1;

                    break;

                }

            } else {

                longitud = numeros.length;

            }

        }

        System.out.println("INTRODUZCA VALOR A BUSCAR: ");
        int valor = sc.nextInt();

        int posicion = buscar(numeros, longitud, valor);

        if (posicion == -1) {

            System.out.println("ELEMENTO NO ENCONTRADO.");

        } else {

            System.out.println("ENCONTRADO EN LA POSICIÓN " + posicion + ".");

        }

    }

    /**
     * BUSCA ELE EN UN ARRAY DE LONGITD ENTEROS.
     *
     * @param numeros
     * @param longitud
     * @param valor
     * @return -1 EN CASO DE QUE NO LO ENCUENTE. E.O.C LA POSICIÓN DONDE LO HA
     * ENCONTRADO.
     */
    public static int buscar(int numeros[], int longitud, int valor) {

        for (int i = 0; i < longitud; i += 1) {

            if (numeros[i] == valor) {

                return i;

            }

        }

        return -1;

    }

    // MODIFICAR LA FUNCIÓN PARA QUE ME DEVUELVA UN ARRAY CON LAS POSICIONES EN DÓNDE SE HA ENCONTRADO ESE ELEMENTO. 
    // EL ARRAY RESULTAD TIENE DE TAMAÑO EL MISMO QUE EL NÚMERO DE VECES QUE APARECE EL NÚMERO REPETIDO. 
    // SI NO SE ENCUENTRA DEVOLVER NULL. 
    public static int[] buscar2(int numeros[], int longitud, int valor) {

    }

}
