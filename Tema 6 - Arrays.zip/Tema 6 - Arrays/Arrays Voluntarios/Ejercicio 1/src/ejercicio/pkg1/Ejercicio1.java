/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[10];
        int numero;
        String respuesta;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            do {

                System.out.println("INTRODUZCA NÚMERO: ");
                numero = sc.nextInt();

            } while (numero < 0 || numero >= 10);

            numeros[numero] += 1;

            sc.nextLine();

            do {

                System.out.println("¿DESEA CONTINUAR?");
                respuesta = sc.nextLine();

            } while (!respuesta.equalsIgnoreCase("SI") && !respuesta.equalsIgnoreCase("NO"));

        } while (!respuesta.equalsIgnoreCase("NO"));

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println(i + ": " + numeros[i]);

        }

    }

}
