/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA PALABRA: ");
        String palabra = sc.nextLine();

        if (esPalindromo(palabra.toLowerCase())) {

            System.out.println("ES UN PALÍNDROMO. ");

        } else {

            System.out.println("NO ES UN PALÍNDROMO. ");

        }

    }

    public static boolean esPalindromo(String palabra) {

        int inicio = 0;
        int fin = palabra.length() - 1;
        boolean esPalindromo = true;

        while (inicio < fin) {

            if (palabra.charAt(inicio) != palabra.charAt(fin)) {

                esPalindromo = false;

                break;

            }

            inicio += 1;
            fin -= 1;

        }

        return esPalindromo;

    }

}
