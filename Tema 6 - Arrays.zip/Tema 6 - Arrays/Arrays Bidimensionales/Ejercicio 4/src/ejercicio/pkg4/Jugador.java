/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

import java.util.Arrays;

import java.util.Random;

/**
 *
 * @author Hugo
 */
public class Jugador {

    private String nombre;
    private int cartonBingo[][];
    private static int bolasAnotadas[] = new int[80];
    private boolean bolaTachada = false;
    private static boolean lineaTachada = false;

    public Jugador(String nombre) {

        this.nombre = nombre;

        generarNumeros();

    }

    public void generarNumeros() {

        final int f = 4;
        final int c = 5;

        cartonBingo = new int[f][c];

        for (int fila = 0; fila < f; fila += 1) {

            for (int columna = 0; columna < c; columna += 1) {

                cartonBingo[fila][columna] = randomNumber(fila);

                for (int i = columna - 1; i >= 0; i -= 1) {

                    while (cartonBingo[fila][columna] == cartonBingo[fila][i]) {

                        cartonBingo[fila][columna] = randomNumber2(fila);

                    }

                }

            }

            Arrays.sort(cartonBingo[fila]);

        }

    }

    private static int randomNumber(int fila) {

        int max = 20;
        int min = 1;

        for (int i = 0; i < fila; i += 1) {

            max += 20;
            min += 20;

        }

        return (int) (Math.random() * ((max - min) + 1)) + min;

    }

    private static int randomNumber2(int fila) {

        Random r = new Random();

        return r.nextInt(20) + 1 + (fila * 20);

    }

    public String getNombre() {
        return nombre.toUpperCase();
    }

    public void getCartonBingo() {

        for (int f = 0; f < 4; f += 1) {

            for (int c = 0; c < 5; c += 1) {

                System.out.print(cartonBingo[f][c] + "\t");

            }

            System.out.println("\n");

        }

    }

    public static int numeroBola() {

        Random r = new Random();

        int numeroBola = r.nextInt(80 - 1) + 1;

        while (bolasAnotadas[numeroBola] == 1) {

            numeroBola = r.nextInt(80 - 1) + 1;

        }

        bolasAnotadas[numeroBola] = 1;

        return numeroBola;

    }

    public void anotaBola(int numeroBola) {

        for (int fila = 0; fila < 4; fila += 1) {

            for (int columna = 0; columna < 5; columna += 1) {

                if (cartonBingo[fila][columna] == numeroBola) {

                    cartonBingo[fila][columna] = 0;

                    bolaTachada = true;

                }

            }

        }

        System.out.println(getNombre() + ":");

        getCartonBingo();

    }

    public boolean comprobarLinea() {

        comprobarLinea:
        for (int fila = 0; fila < 4; fila += 1) {

            for (int columna = 0; columna < 5; columna += 1) {

                if (cartonBingo[fila][columna] != 0) {

                    continue comprobarLinea;

                }

            }

            lineaTachada = true;

            return true;

        }

        return false;

    }

    public boolean comprobarBingo() {

        for (int fila = 0; fila < 4; fila += 1) {

            for (int columna = 0; columna < 5; columna += 1) {

                if (cartonBingo[fila][columna] != 0) {

                    return false;

                }

            }

        }

        return true;

    }

    public boolean isBolaTachada() {
        return bolaTachada;
    }

    public static boolean isLineaTachada() {
        return lineaTachada;
    }

}
