/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int cantidadJugadores;
        int jugadorLinea = -1;
        int jugadorBingo = -1;
        Jugador jugadores[];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("¿CUANTOS JUGADORES VAN A PARTICIPAR?");
            cantidadJugadores = sc.nextInt();

            if (cantidadJugadores <= 0 || cantidadJugadores > 10) {

                System.out.println("CANTIDAD DE JUGADORES NO VÁLIDA. ");

            }

        } while (cantidadJugadores <= 0 || cantidadJugadores > 10);

        jugadores = new Jugador[cantidadJugadores];

        sc.nextLine();

        for (int i = 0; i < cantidadJugadores; i += 1) {

            System.out.println("INTRODUZCA NOMBRE DEL JUGADOR " + (i + 1) + ":");
            String nombre = sc.nextLine();

            jugadores[i] = new Jugador(nombre);

        }

        for (int i = 0; i < cantidadJugadores; i += 1) {

            System.out.println(jugadores[i].getNombre() + ":");
            jugadores[i].getCartonBingo();

        }

        int opcion;

        do {

            System.out.println("INTRODUZCA UNA OPCIÓN:\n"
                    + "\n\t1. ANOTAR NÚMERO DE BOLA.\n"
                    + "\n\t2. SALIR DEL PROGRAMA.\n");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    int numeroBola = Jugador.numeroBola();

                    for (int i = 0; i < cantidadJugadores; i += 1) {

                        jugadores[i].anotaBola(numeroBola);

                    }

                    for (int i = 0; i < cantidadJugadores; i += 1) {

                        if (jugadores[i].isBolaTachada()) {

                            if (!Jugador.isLineaTachada()) {

                                if (jugadores[i].comprobarLinea()) {

                                    jugadorLinea = i;

                                    System.out.println("EL JUGADOR " + jugadores[jugadorLinea].getNombre() + " HA CONSEGUIDO LÍNEA. ");

                                }

                            } else {

                                if (jugadores[i].comprobarBingo()) {

                                    jugadorBingo = i;

                                    System.out.println("EL JUGADOR " + jugadores[jugadorLinea].getNombre() + " HA CONSEGUIDO LÍNEA. ");

                                    System.out.println("EL JUGADOR " + jugadores[jugadorBingo].getNombre() + " HA CONSEGUIDO BINGO. ");

                                    System.exit(0);

                                }

                            }

                        }

                    }

                    break;

                default:

                    if (opcion != 2) {

                        System.out.println("OPCIÓN NO VÁLIDA. ");

                    }

                    break;

            }

        } while (opcion != 2);

    }

}
