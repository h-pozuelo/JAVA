/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int matriz[][];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA TAMAÑO DE MATRIZ: ");
        int dim = sc.nextInt();

        matriz = new int[dim][dim];

        for (int fila = 0; fila < dim; fila += 1) {

            for (int columna = 0; columna < dim; columna += 1) {

                if (fila == columna) {

                    matriz[fila][columna] = 1;

                } else {

                    matriz[fila][columna] = 0;

                }

                System.out.print(matriz[fila][columna] + "\t");

            }

            System.out.print("\n");

        }

    }

}
