/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[][] = new int[3][4];
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int fila = 0; fila < 3; fila += 1) {

            for (int columna = 0; columna < 4; columna += 1) {

                System.out.println("INTRODUZCA ELEMENTO [" + fila + "][" + columna + "]:");
                numeros[fila][columna] = sc.nextInt();

                if (numeros[fila][columna] > max) { // SIEMPRE QUE EL VALOR ALMACENADO EN [fila][columna] SEA MAYOR QUE EL MÁXIMO (CON VALOR ACTUAL DEL MÍNIMO VALOR ÍNTEGRO POSIBLE) SOBRE-ESCRIBIRÁ EL VALOR. 
                    max = numeros[fila][columna];
                }

                if (numeros[fila][columna] < min) { // SIEMPRE QUE EL VALOR ALMACENADO EN [fila][columna] SEA MENOR QUE EL MÍNIMO (CON VALOR ACTUAL DEL MÁXIMO VALOR ÍNTEGRO POSIBLE) SOBRE-ESCRIBIRÁ EL VALOR. 
                    min = numeros[fila][columna];
                }

            }

        }

        for (int fila = 0; fila < 3; fila += 1) {

            for (int columna = 0; columna < 4; columna += 1) {

                System.out.print(numeros[fila][columna] + "\t");

            }

            System.out.println("");

            System.out.print("\n");

        }

        System.out.println("MÁXIMO: " + max);
        System.out.println("MÍNIMO: " + min);

    }

}
