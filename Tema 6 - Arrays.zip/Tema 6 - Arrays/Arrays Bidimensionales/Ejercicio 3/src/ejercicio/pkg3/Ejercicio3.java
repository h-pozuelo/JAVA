/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int filas = randomNumber();
        int columnas = randomNumber();

        int matriz[][] = new int[filas][columnas];

        for (int fila = 0; fila < filas; fila += 1) {

            for (int columna = 0; columna < columnas; columna += 1) {

                matriz[fila][columna] = randomNumber();

                System.out.print(randomNumber() + "\t");

            }

            System.out.print("\n");

        }

    }

    private static int randomNumber() {
        return (int) (Math.random() * ((10 - 1) + 1)) + 1;
    }

}
