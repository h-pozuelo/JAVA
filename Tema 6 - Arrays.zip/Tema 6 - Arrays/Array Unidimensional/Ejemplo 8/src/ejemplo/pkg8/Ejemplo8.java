/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg8;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String meses[] = {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"};

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA DÍA: ");
        int dia = sc.nextInt();

        System.out.println("INTRODUZCA MES: ");
        int mes = sc.nextInt();

        System.out.println("INTRODUZCA AÑO: ");
        int anyo = sc.nextInt();

        String formatoLargo = "";

        for (int i = 0; i < meses.length; i += 1) {

            if (mes - 1 == i) {
                formatoLargo = meses[i];
            }

        }

        System.out.println(dia + " DE " + formatoLargo + " DE " + anyo);

    }

}
