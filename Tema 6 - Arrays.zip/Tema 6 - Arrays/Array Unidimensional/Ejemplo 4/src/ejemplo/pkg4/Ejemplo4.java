/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[10];
        int count = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < numeros.length; i++) {

            System.out.println("INTRODUZCA NÚMERO " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();

        }

        System.out.println("INTRODUZCA NÚMERO: ");
        int num = sc.nextInt();

        for (int i = 0; i < numeros.length; i++) {

            if (num == numeros[i]) {
                count++;
            }

        }

        System.out.println("EL NÚMERO " + num + " SE HA REPETIDO UN TOTAL DE " + count + " VECES.");

    }

}
