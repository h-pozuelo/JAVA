/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String cadenas[];
        String cadena = "";
        String respuesta = "";

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("¿CUANTAS CADENAS DESEA INTRODUCIR?");
        int num = sc.nextInt();

        cadenas = new String[num]; // VARIABLE QUE ME PERMITE ESPECIFICAR EL TAMAÑO DEL ARRAY. 

        sc.nextLine();

        int count = 0; // CONTADOR QUE ME PERMITE SABER EN QUE POSICIÓN DEL ARRAY ME HE QUEDADO. 

        do {

            for (int i = count; !cadena.equalsIgnoreCase("FIN") && i < cadenas.length; i++) {

                System.out.println("INTRODUZCA CADENA " + (i + 1) + ": ");
                cadena = sc.nextLine();

                if (!cadena.equalsIgnoreCase("FIN")) {

                    cadenas[i] = cadena;

                    count++;

                }

            }

            cadena = ""; // SI NO PONGO EN BLANCO LA VARIABLE NO ME DEJARÁ VOLVER A ENTRAR AL BUCLE DADO QUE SU VALOR ES "FIN". 
            /*
            for (int i = 0; i < cadenas.length; i++) {

                if (cadenas[i] != null) {
                    System.out.println(cadenas[i]);
                }

            }
             */
            for (int i = 0; i < count; i++) { // HACIENDO USO DEL CONTADOR NO ES NECESARIO INTRODUCIR EL IF. 

                System.out.println("[" + (i + 1) + "] " + cadenas[i]);

            }

            if (count < cadenas.length) {

                System.out.println("¿DESEA SEGUIR INTRODUCIENDO CADENAS?");
                respuesta = sc.nextLine();

            }

        } while (!respuesta.equalsIgnoreCase("NO") && count != cadenas.length);

    }

}
