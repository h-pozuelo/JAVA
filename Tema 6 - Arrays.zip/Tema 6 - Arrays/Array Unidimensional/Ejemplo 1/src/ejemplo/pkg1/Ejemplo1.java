/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[5];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA CINCO NÚMEROS: ");

        for (int i = 0; i < numeros.length; i++) { // SALE DEL BUCLE CUANDO i LLEGA A 5 (SIN INCLUIRLO). 

            System.out.println("INTRODUZCA NÚMERO " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();

        }

        for (int i = 0; i <= numeros.length - 1; i++) { // TIENE QUE COMENZAR EN 0 COMO LOS STRINGS. 

            System.out.println(numeros[i]);

        }

    }

}
