/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double temperaturaMedia = 0;
        double temperaturas[] = new double[7];
        String dias[] = {"LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO", "DOMINGO"};

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < temperaturas.length; i += 1) {

            System.out.println("INTRODUZCA TEMPERATURA DEL " + dias[i] + ": ");
            double temperatura = sc.nextDouble();

            temperaturas[i] = temperatura;

            temperaturaMedia += temperatura;

        }

        System.out.println("TEMPERATURA MEDIA: " + (temperaturaMedia / dias.length));

        String respuesta = "";

        sc.nextLine();

        do {

            System.out.println("INTRODUZCA DÍA DE LA SEMANA: ");
            String dia = sc.nextLine();

            for (int i = 0; i < dias.length; i += 1) {

                if (dia.equalsIgnoreCase(dias[i])) {

                    System.out.println(temperaturas[i]);

                }

            }

            System.out.println("¿DESEA CONTINUAR?");
            respuesta = sc.nextLine();

        } while (!respuesta.equalsIgnoreCase("NO"));

        double min = temperaturas[0];
        double max = temperaturas[0];
        int posMin = 0;
        int posMax = 0;

        for (int i = 1; i < dias.length; i += 1) {

            if (temperaturas[i] < min) {
                posMin = i;
            }

            if (temperaturas[i] > max) {
                posMax = i;
            }

        }

        System.out.println("LA TEMPERATURA MÍNIMA FUE DE " + temperaturas[posMin] + " GRADOS EL DÍA " + dias[posMin] + ".");

        System.out.println("LA TEMPERATURA MÁXIMA FUE DE " + temperaturas[posMax] + " GRADOS EL DÍA " + dias[posMax] + ".");

    }

}
