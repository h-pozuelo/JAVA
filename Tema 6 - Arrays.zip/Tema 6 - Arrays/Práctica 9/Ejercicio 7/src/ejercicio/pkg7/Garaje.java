/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

/**
 *
 * @author Hugo
 */
public class Garaje {

    private int identificador;
    private double metrosCuadrados;
    private int planta;
    private double precioAlquiler;
    private boolean estaAlquilado = false;
    private static double gananciasTotales;

    public Garaje(int identificador, double metrosCuadrados, int planta) {
        this.identificador = identificador;
        this.metrosCuadrados = metrosCuadrados;
        this.planta = planta;
    }

    public double calcularPrecioAlquiler() {

        precioAlquiler = 18;

        switch (planta) {

            case 1:

                precioAlquiler += 3;

                break;

            case 2:

                precioAlquiler += 1.5;

                break;

            case 0:

                precioAlquiler += 1;

                break;

        }

        if (metrosCuadrados > 4) {

            precioAlquiler += 1.5;

        } else if (metrosCuadrados < 3) {

            precioAlquiler -= 1;

        }

        return precioAlquiler;

    }

    public double alquilarGaraje() {

        if (estaAlquilado == true) {

            System.out.println("EL GARAJE NO SE ENCUENTRA DISPONIBLE. ");

            return 0;

        }

        estaAlquilado = true;

        gananciasTotales += precioAlquiler;

        return precioAlquiler;

    }

    public int getIdentificador() {
        return identificador;
    }

    public double getPrecioAlquiler() {
        return precioAlquiler;
    }

    public boolean isEstaAlquilado() {
        return estaAlquilado;
    }

    @Override
    public String toString() {
        return "Garaje{" + "identificador=" + identificador + ", metrosCuadrados=" + metrosCuadrados + ", planta=" + planta + ", precioAlquiler=" + precioAlquiler + ", estaAlquilado=" + estaAlquilado + '}';
    }

    public void subirPrecioAlquiler(double porcentaje) {

        precioAlquiler += ((precioAlquiler * porcentaje) / 100);

    }

    public static double getGananciasTotales() {
        return gananciasTotales;
    }

}
