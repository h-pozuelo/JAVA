/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Garaje garajes[] = new Garaje[2];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < garajes.length; i += 1) {

            int identificador;
            double metrosCuadrados;
            int planta;

            System.out.println("INFORMACIÓN DEL GARAJE [" + (i + 1) + "]: ");

            do {

                System.out.println("INTRODUZCA IDENTIFICADOR: ");
                identificador = sc.nextInt();

                if (identificador <= 0) {

                    System.out.println("IDENTIFICADOR NO VÁLIDO. ");

                }

            } while (identificador <= 0);

            do {

                System.out.println("INTRODUZCA METROS CUADRADOS: ");
                metrosCuadrados = sc.nextDouble();

                if (metrosCuadrados <= 0) {

                    System.out.println("METROS CUADRADOS NO VÁLIDOS. ");

                }

            } while (metrosCuadrados <= 0);

            do {

                System.out.println("INTRODUZCA PLANTA: ");
                planta = sc.nextInt();

                if (planta != 0 && planta != 1 && planta != 2) {

                    System.out.println("PLANTA NO VÁLIDA. ");

                }

            } while (planta != 0 && planta != 1 && planta != 2);

            garajes[i] = new Garaje(identificador, metrosCuadrados, planta);

            garajes[i].calcularPrecioAlquiler();

        }

        int opcion;

        do {

            System.out.println("SELECCIONE UNA OPCIÓN: \n1. ALQUILAR UN GARAJE. \n2. MOSTRAR EL PRECIO DE UN GARAJE. \n3. MOSTRAR LA INFORMACIÓN DE LOS GARAJES DISPONIBLES. \n4. SUBIR EL PRECIO DE UN GARAJE. \n5. MOSTRAR LOS BENEFICIOS DE LA EMPRESA. \n6. SALIR DEL PROGRAMA. ");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                case 2:
                case 4:

                    int posicion = buscar(sc, garajes);

                    switch (opcion) {

                        case 1:

                            System.out.println("TOTAL: " + garajes[posicion].alquilarGaraje() + " €");

                            break;

                        case 2:

                            System.out.println("PRECIO: " + garajes[posicion].getPrecioAlquiler() + " €");

                            break;

                        default:

                            if (garajes[posicion].isEstaAlquilado()) {

                                System.out.println("EL PRECIO DEL GARAJE NO PUEDE SER MANIPULADO. ");

                                break;

                            }

                            System.out.println("¿CUANTO DESEA AUMENTAR EL PRECIO?");
                            double porcentaje = sc.nextDouble();

                            garajes[posicion].subirPrecioAlquiler(porcentaje);

                            break;

                    }

                    break;

                case 3:

                    for (int i = 0; i < garajes.length; i += 1) {

                        if (!garajes[i].isEstaAlquilado()) {

                            System.out.println(garajes[i].toString());

                        }

                    }

                    break;

                case 5:

                    System.out.println("GANANCIAS TOTALES: " + Garaje.getGananciasTotales() + " €");

                    break;

                default:

                    if (opcion != 6) {

                        System.out.println("OPCIÓN NO VÁLIDA. ");

                    }

                    break;

            }

        } while (opcion != 6);

    }

    private static int buscar(Scanner sc, Garaje[] garajes) {

        int posicion;

        do {

            System.out.println("INTRODUZCA IDENTIFICADOR: ");
            int identificador = sc.nextInt();

            posicion = busqueda(garajes, identificador);

            if (posicion == -1) {

                System.out.println("NO SE ENCUENTRA EL GARAJE. ");

            }

        } while (posicion == -1);

        return posicion;

    }

    public static int busqueda(Garaje garajes[], int identificador) {

        int posicion = 0;

        for (int i = 0; i < garajes.length; i += 1) {

            if (identificador == garajes[i].getIdentificador()) {

                posicion = i;

            }

        }

        return posicion;

    }

}
