/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg10;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Alumno alumnos[] = new Alumno[25];

        int posicion = 0; // EQUIVALE A LA CANTIDAD DE ALUMNOS MATRICULADOS. (ADEMÁS DE COINCIDIR CON LA SIGUIENTE CELDA A RELLENAR DEL ARRAY) 

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int opcion;

        do {

            System.out.println("INTRODUZCA UNA OPCIÓN: "
                    + "\n1. MATRICULAR UN ALUMNO "
                    + "\n2. INTRODUCIR CALIFICACIONES "
                    + "\n3. LISTAR ALUMNOS (ORDENADO POR CALIFICACIONES) "
                    + "\n4. LISTAR ALUMNOS (ORDENADO ALFABÉTICAMENTE) "
                    + "\n5. MOSTRAR ALUMNO ESPECÍFICO "
                    + "\n6. ELIMINAR MATRÍCULA DE UN ALUMNO "
                    + "\n7. SALIR DEL PROGRAMA ");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    if (posicion < alumnos.length) {

                        sc.nextLine();

                        System.out.println("INTRODUZCA NOMBRE: ");
                        String nombre = sc.nextLine().toUpperCase();

                        System.out.println("INTRODUZCA APELLIDOS: ");
                        String apellidos = sc.nextLine().toUpperCase();

                        String telefono;

                        do {

                            System.out.println("INTRODUZCA TELÉFONO: ");
                            telefono = sc.nextLine();

                            if (!Alumno.validarTelefono(telefono)) {

                                System.out.println("TELÉFONO NO VÁLIDO. ");

                            }

                        } while (!Alumno.validarTelefono(telefono));

                        String dni;

                        do {

                            System.out.println("INTRODUZCA DNI: ");
                            dni = sc.nextLine().toUpperCase();

                            if (!Alumno.validarDNI(dni)) {

                                System.out.println("DNI NO VÁLIDO. ");

                            }

                        } while (!Alumno.validarDNI(dni));

                        alumnos[posicion] = new Alumno(nombre, apellidos, telefono, dni);

                        posicion += 1;

                    } else {

                        System.out.println("CAPACIDAD MÁXIMA DE ALUMNOS MATRICULADOS. ");

                    }

                    break;

                case 2:

                    int asignatura;

                    do {

                        System.out.println("ESCOJA LA ASIGNATURA: ");
                        System.out.println(Alumno.mostrarAsignaturas());
                        asignatura = sc.nextInt();

                        if (asignatura < 1 || asignatura > 6) {

                            System.out.println("ASIGNATURA NO VÁLIDA. ");

                        }

                    } while (asignatura < 1 || asignatura > 6);

                    if (posicion != 0) {

                        for (int i = 0; i < posicion; i += 1) {

                            double nota;

                            do {

                                System.out.println("INTRODUZCA NOTA DE " + alumnos[i].getNombreApellidos() + ": ");
                                nota = sc.nextDouble();

                                if (nota < 0 || nota > 10) {

                                    System.out.println("NOTA NO VÁLIDA. ");

                                }

                            } while (nota < 0 || nota > 10);

                            alumnos[i].setNota(asignatura, nota);

                            alumnos[i].calcularMedia();

                        }

                    } else {

                        System.out.println("NO EXISTE NINGÚN ALUMNO MATRICULADO. ");

                    }

                    break;

                case 3:

                    if (posicion > 1) {

                        burbuja(alumnos, posicion);
                        /*
                        quicksort1(alumnos, 0, posicion - 1);
                         */
                        for (int i = 0; i < posicion; i += 1) {

                            System.out.println(alumnos[i].toString());

                        }

                    } else {

                        if (posicion != 0) {

                            System.out.println(alumnos[0].toString());

                        } else {

                            System.out.println("NO EXISTE NINGÚN ALUMNO MATRICULADO. ");

                        }

                    }

                    break;

                case 4:

                    if (posicion > 1) {

                        quicksort2(alumnos, 0, posicion - 1);

                        for (int i = 0; i < posicion; i += 1) {

                            System.out.println(alumnos[i].toString());

                        }

                    } else {

                        if (posicion != 0) {

                            System.out.println(alumnos[0].toString());

                        } else {

                            System.out.println("NO EXISTE NINGÚN ALUMNO MATRICULADO. ");

                        }

                    }

                    break;

                case 5:

                    if (posicion > 0) {

                        sc.nextLine();

                        int posicion2 = posicion;

                        boolean encontrado = false;

                        System.out.println("INTRODUZCA DNI: ");
                        String dni = sc.nextLine();

                        for (int i = 0; i < posicion2; i += 1) {

                            if (dni.equalsIgnoreCase(alumnos[i].getDNI())) {

                                encontrado = true;

                                posicion2 = i;

                                System.out.println(alumnos[i].toString());

                            }

                        }

                        if (encontrado == false) {

                            System.out.println("DNI NO ENCONTRADO. ");

                        }

                    } else {

                        System.out.println("NO EXISTE NINGÚN ALUMNO MATRICULADO. ");

                    }

                    break;

                case 6:

                    if (posicion > 0) {

                        sc.nextLine();

                        int posicion2 = posicion;

                        boolean encontrado = false;

                        System.out.println("INTRODUZCA DNI: ");
                        String dni = sc.nextLine();

                        for (int i = 0; i < posicion2; i += 1) { // LA VARIABLE POSICIÓN CORRESPONDE CON LA CANTIDAD DE ELEMENTOS DEL ARRAY (NO CON LA CELDA). 

                            if (dni.equalsIgnoreCase(alumnos[i].getDNI())) {

                                encontrado = true;

                                for (int j = i; j < posicion2 - 1; j += 1) { // COMIENZA A CONTAR DESDE EL VALOR DE LA VARIABLE i. EN ESTE CASO PONGO EL -1 (SIN PONER EL <=) DADO QUE LA ÚLTIMA CELDA LA VOY A ELIMINAR. 

                                    alumnos[j] = alumnos[j + 1];

                                }

                                alumnos[posicion2 - 1] = null; // SI DESEO ELIMINAR EL ÚLTIMO ELEMENTO (EL TAMAÑO 8 NO ES LO MISMO QUE EL NÚMERO DEL ÚLTIMO ELEMENTO 7). 

                                posicion -= 1; // COMO LUEGO UTILIZO ESTA VARIABLE PARA MOSTRAR EL VALOR DE CADA CELDA TENGO QUE DESCONTAR LA ÚLTIMA CELDA. 

                                break;

                            }

                        }

                        if (encontrado == false) {

                            System.out.println("DNI NO ENCONTRADO. ");

                        }

                    } else {

                        System.out.println("NO EXISTE NINGÚN ALUMNO MATRICULADO. ");

                    }
                    /*
                    System.out.println("INTRODUZCA DNI: ");
                    String dni = sc.nextLine();

                    int pos = buscar(alumnos, posicion, dni);

                    if (pos == -1) {

                        System.out.println("DNI NO ENCONTRADO. ");

                    } else {

                        for (int i = pos; i < posicion - 1; i += 1) {

                            alumnos[i] = alumnos[i + 1];

                        }

                        alumnos[posicion - 1] = null; // OPCIONAL DADO QUE EL ARRAY SOLO ES RECORRIDO HASTA POSICIÓN. 

                        posicion -= 1;

                    }
                     */
                    break;

                default:

                    if (opcion != 7) {

                        System.out.println("OPCIÓN NO VÁLIDA. ");

                    }

                    break;

            }

        } while (opcion != 7);

    }

    public static void burbuja(Alumno alumnos[], int posicion) {

        int j, k;
        Alumno aux;

        for (j = 1; j < posicion; j += 1) {

            for (k = 0; k < posicion - j; k += 1) {

                if (alumnos[k].getNotaMedia() < alumnos[k + 1].getNotaMedia()) {

                    aux = alumnos[k];
                    alumnos[k] = alumnos[k + 1];
                    alumnos[k + 1] = aux;

                }

            }

        }

    }

    public static void quicksort1(Alumno array[], int izquierda, int derecha) {

        Alumno pivote = array[izquierda];
        int i = izquierda;
        int j = derecha;
        Alumno auxiliar;

        while (i < j) {

            // DESCENDENTE  
            while (array[i].getNotaMedia() >= pivote.getNotaMedia() && i < j) {

                i += 1;

            }

            while (array[j].getNotaMedia() < pivote.getNotaMedia()) {

                j -= 1;

            }

            if (i < j) {

                auxiliar = array[i];
                array[i] = array[j];
                array[j] = auxiliar;

            }

        }

        array[izquierda] = array[j];
        array[j] = pivote;

        if (izquierda < j - 1) {

            quicksort1(array, izquierda, j - 1);

        }

        if (j + 1 < derecha) {

            quicksort1(array, j + 1, derecha);

        }

    }

    public static void quicksort2(Alumno array[], int izquierda, int derecha) {

        Alumno pivote = array[izquierda];
        int i = izquierda;
        int j = derecha;
        Alumno auxiliar;

        while (i < j) {

            // DESCENDENTE  
            while (array[i].getApellidosNombre().compareToIgnoreCase(pivote.getApellidosNombre()) <= 0 && i < j) {

                i += 1;

            }

            while (array[j].getApellidosNombre().compareToIgnoreCase(pivote.getApellidosNombre()) > 0) {

                j -= 1;

            }

            if (i < j) {

                auxiliar = array[i];
                array[i] = array[j];
                array[j] = auxiliar;

            }

        }

        array[izquierda] = array[j];
        array[j] = pivote;

        if (izquierda < j - 1) {

            quicksort2(array, izquierda, j - 1);

        }

        if (j + 1 < derecha) {

            quicksort2(array, j + 1, derecha);

        }

    }

    public static int buscar(Alumno alumnos[], int posicion, String dni) {

        for (int i = 0; i < posicion; i += 1) {

            if (alumnos[i].getDNI().equalsIgnoreCase(dni)) {

                return i;

            }

        }

        return -1;

    }

}
