/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg10;

import java.util.Arrays;

/**
 *
 * @author Hugo
 */
public class Alumno {

    private String nombre;
    private String apellidos;
    private String telefono;
    private String dni;
    private double notas[];
    private static final String asignaturas[] = {"PROGRAMACIÓN", "ENTORNOS", "MARCAS", "SISTEMAS", "FOL", "BBDD"};
    private double notaMedia;

    public Alumno(String nombre, String apellidos, String telefono, String dni) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.dni = dni;
        notas = new double[6];

        Arrays.fill(notas, -1); // FUNCIÓN QUE RELLENA TODAS LAS CELDAS CON UN VALOR ESPECÍFICO. 

    }

    public double calcularMedia() {

        notaMedia = 0;

        int countNotas = 0;

        for (int i = 0; i < asignaturas.length; i += 1) {

            if (notas[i] != -1) {

                notaMedia += notas[i];

                countNotas += 1;

            }

        }

        notaMedia /= countNotas;

        return notaMedia;

    }

    public static String mostrarAsignaturas() {

        String aux = "ASIGNATURAS: \n";

        for (int i = 0; i < asignaturas.length; i += 1) {

            aux += (i + 1) + ". " + asignaturas[i] + "\n";

        }

        return aux;

    }

    public static boolean validarTelefono(String telefono) {

        if (telefono.length() != 9) {

            return false;

        }

        for (int i = 0; i < telefono.length(); i += 1) {

            int digito = telefono.charAt(i);

            if (!Character.isDigit(digito)) {

                return false;

            }

        }

        return true;

    }

    public static boolean validarDNI(String dni) {

        if (dni.length() != 9) {

            return false;

        }

        for (int i = 0; i < dni.length() - 1; i += 1) {

            int digito = dni.charAt(i);

            if (!Character.isDigit(digito)) {

                return false;

            }

        }

        char letra = dni.charAt(dni.length() - 1);

        if (!Character.isLetter(letra)) {

            return false;

        }

        return true;

    }

    public String getNombreApellidos() {
        return nombre + " " + apellidos;
    }

    public String getApellidosNombre() {
        return apellidos + " " + nombre;
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    public String getDNI() {
        return dni;
    }

    public void setNota(int asignatura, double nota) {

        asignatura -= 1;

        notas[asignatura] = nota;

    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", apellidos=" + apellidos + ", telefono=" + telefono + ", dni=" + dni + ", notaMedia=" + notaMedia + '}';
    }

}
