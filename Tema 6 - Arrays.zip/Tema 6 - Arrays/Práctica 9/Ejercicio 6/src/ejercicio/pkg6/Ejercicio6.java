/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Vehiculo vehiculos[] = new Vehiculo[3]; // SE CREA UN ARRAY PARA ALMACENAR 5 VEHÍCULOS CON NULL EN CADA UNA DE LAS CELDAS (5 VEHÍCULOS == 5 CELDAS). 
        /*
        Vehiculo v1 = new Vehiculo("2773YNO", "CLIO", "RENAULT", 2001, 2);
        Vehiculo v2 = new Vehiculo("9069VBY", "FIESTA", "FORD", 2017, 2);
        Vehiculo v3 = new Vehiculo("1854SJJ", "CARENS", "KIA", 2014, 1);
        Vehiculo v4 = new Vehiculo("5940FRP", "LEAF", "NISSAN", 2012, 1);
        Vehiculo v5 = new Vehiculo("2810SVX", "C4", "CITROËN", 2002, 1);
         */
        String matricula, modelo, marca;
        int añoMatriculacion, categoria, opcion, posicion;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < vehiculos.length; i += 1) {

            do {

                System.out.println("INTRODUZCA MATRÍCULA: ");
                matricula = sc.nextLine();

                if (!validarMatricula(matricula)) {

                    System.out.println("MATRÍCULA NO VÁLIDA. ");

                }

            } while (!validarMatricula(matricula));

            System.out.println("INTRODUZCA MODELO: ");
            modelo = sc.nextLine();

            System.out.println("INTRODUZCA MARCA: ");
            marca = sc.nextLine();

            do {

                System.out.println("INTRODUZCA AÑO DE MATRICULACIÓN: ");
                añoMatriculacion = sc.nextInt();

                if (!validarAño(añoMatriculacion)) {

                    System.out.println("AÑO NO VÁLIDO. ");

                }

            } while (!validarAño(añoMatriculacion));

            do {

                System.out.println("INTRODUZCA CATEGORÍA: ");
                categoria = sc.nextInt();

                if (!validarCategoria(categoria)) {

                    System.out.println("CATEGORÍA NO VÁLIDA. ");

                }

            } while (!validarCategoria(categoria));

            sc.nextLine();

            vehiculos[i] = new Vehiculo(matricula, modelo, marca, añoMatriculacion, categoria);

        }

        for (int i = 0; i < vehiculos.length; i += 1) {

            System.out.println(vehiculos[i].toString());

        }

        do {

            System.out.println("INTRODUZCA UNA OPCIÓN: \n1. ALQUILAR VEHÍCULO. \n2. DEVOLVER VEHÍCULO. \n3. SABER SI EL VEHÍCULO ESTÁ ALQUILADO. \n4. CANTIDAD DE VEHÍCULOS ALQUILADOS. \n5. GANANCIAS TOTALES DE UN VEHÍCULO. \n6. GANANCIAS TOTALES DE LA EMPRESA. \n7. ORDENAR VEHÍCULOS. \n8. SALIR. ");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    do {

                        System.out.println("TIPO DE VEHÍCULO: (1/2)");
                        categoria = sc.nextInt();

                        if (categoria != 1 && categoria != 2) {

                            System.out.println("TIPO DE VEHÍCULO NO VÁLIDO. ");

                        }

                    } while (categoria != 1 && categoria != 2);

                    posicion = buscar(vehiculos, categoria);

                    if (posicion == -1) {

                        System.out.println("NO NOS QUEDAN VEHÍCULOS DE ESA CATEGORÍA. ");

                    } else {

                        System.out.println("¿CUANTOS DÍAS DESEA ALQUILARLO?");
                        int dias = sc.nextInt();

                        double precio = vehiculos[posicion].alquiler(dias);

                        System.out.println("TOTAL: " + precio + " €");

                    }

                    break;

                case 2:

                    sc.nextLine();

                    System.out.println("INTRODUZCA MATRÍCULA: ");
                    matricula = sc.nextLine();

                    posicion = buscar2(vehiculos, matricula);

                    if (posicion == -1) {

                        System.out.println("MATRÍCULA NO VÁLIDA. ");

                    } else {

                        vehiculos[posicion].devolver();

                    }

                    break;

                case 3:

                    sc.nextLine();

                    System.out.println("INTRODUZCA MATRÍCULA: ");
                    matricula = sc.nextLine();

                    posicion = buscar2(vehiculos, matricula);

                    if (posicion == -1) {

                        System.out.println("MATRÍCULA NO VÁLIDA. ");

                    } else {

                        if (vehiculos[posicion].isAlquilado() == true) {

                            System.out.println("EL VEHÍCULO CON MATRÍCULA " + matricula.toUpperCase() + " ESTÁ ALQUILADO. ");

                        } else {

                            System.out.println("EL VEHÍCULO CON MATRÍCULA " + matricula.toUpperCase() + " ESTÁ DISPONIBLE. ");

                        }

                    }

                    break;

                case 4:

                    totalAlquilados(vehiculos);

                    break;

                case 5:

                    sc.nextLine();

                    System.out.println("INTRODUZCA MATRÍCULA: ");
                    matricula = sc.nextLine();

                    posicion = buscar2(vehiculos, matricula);

                    if (posicion == -1) {

                        System.out.println("MATRÍCULA NO VÁLIDA. ");

                    } else {

                        double ganancias = vehiculos[posicion].getGanancias();

                        System.out.println("TOTAL: " + ganancias + " €");

                    }

                    break;

                case 6:

                    double gananciasTotales = Vehiculo.getGananciasTotales();

                    System.out.println("TOTAL: " + gananciasTotales + " €");

                    break;

                case 7:

                    burbuja(vehiculos, vehiculos.length);

                    for (int i = 0; i < vehiculos.length; i += 1) {

                        System.out.println(vehiculos[i].toString());

                    }

                    break;

                default:

                    if (opcion != 8) {

                        System.out.println("OPCIÓN NO VÁLIDA.");

                    }

            }

        } while (opcion != 8);

    }

    public static boolean validarMatricula(String matricula) {

        if (matricula.length() != 7) {

            return false;

        }

        for (int i = 0; i <= 3; i += 1) {
            /*
            Character.isDigit(matricula.charAt(i));
             */
            if (matricula.charAt(i) < '0' || matricula.charAt(i) > '9') { // COMO ES UN CARACTER TENGO QUE PONER LOS DÍGITOS ENTRE COMILLAS SIMPLES. 

                return false;

            }

        }

        for (int i = 4; i < 7; i += 1) {

            if (!Character.isLetter(matricula.charAt(i))) {

                return false;

            }

        }

        return true;

    }

    public static boolean validarAño(int añoMatriculacion) {

        return añoMatriculacion > 0000 && añoMatriculacion <= 9999;

    }

    public static boolean validarCategoria(int categoria) {

        return categoria == 1 || categoria == 2;

    }

    public static int buscar(Vehiculo vehiculos[], int categoria) {

        for (int i = 0; i < vehiculos.length; i += 1) {

            if (vehiculos[i].getCategoria() == categoria && vehiculos[i].isAlquilado() == false) {

                return i; // ME DEVUELVE LA POSICIÓN DEL ARRAY EN DONDE HA ENCONTRADO EL VEHÍCULO. 

            }

        }

        return -1;

    }

    public static int buscar2(Vehiculo vehiculos[], String matricula) {

        for (int i = 0; i < vehiculos.length; i += 1) {

            if (vehiculos[i].getMatricula().equalsIgnoreCase(matricula)) {

                return i;

            }

        }

        return -1;

    }

    public static void totalAlquilados(Vehiculo vehiculos[]) {

        int totalAlquilados = 0;

        for (int i = 0; i < vehiculos.length; i += 1) {

            if (vehiculos[i].isAlquilado() == true) {

                totalAlquilados += 1;

            }

        }

        System.out.println("EN ESTE MOMENTO SE ENCUENTRAN " + totalAlquilados + " VEHÍCULOS ALQUILADOS. ");

    }

    public static void burbuja(Vehiculo v[], int TAM) { // SE PASA A LA FUNCIÓN UN VECTOR Y EL TAMAÑO DEL VECTOR QUE QUIERO ORDENAR. 

        int j, k;
        Vehiculo aux;
        /*
        LA VARIABLE AUXILIAR TIENE QUE SER DE TIPO VEHÍCULO PARA PODER ALMACENAR EL OBJETO EN ELLA. 
        LA VARIABLE AUXILIAR NO PERTENECE AL ARRAY SINO QUE ES UN OBJETO A PARTE DE TIPO VEHÍCULO. 
         */

        for (j = 1; j < TAM; j += 1) {

            for (k = 0; k < TAM - j; k += 1) {

                // ASCENDENTE 
                if (v[k].getMatricula().compareToIgnoreCase(v[k + 1].getMatricula()) > 0) { // COMPARA LAS MATRÍCULAS DE 2 VEHÍCULOS (< 0 SI LA MATRÍCULA 1 ES MENOR QUE LA MATRÍCULA 2; 0 SI LAS MATRÍCULAS SON IGUALES; > 0 SI LA MATRÍCULA 1 ES MAYOR QUE LA MATRÍCULA 2). 

                    aux = v[k];

                    v[k] = v[k + 1];

                    v[k + 1] = aux;

                }

            }

        }

    }

}
