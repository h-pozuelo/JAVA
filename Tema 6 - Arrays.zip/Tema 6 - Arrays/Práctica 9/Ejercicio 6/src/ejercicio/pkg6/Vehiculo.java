/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg6;

/**
 *
 * @author Hugo
 */
public class Vehiculo {

    private String matricula;
    private String modelo;
    private String marca;
    private int añoMatriculacion;
    private int categoria;
    private boolean alquilado = false;
    private double ganancias;
    private static double gananciasTotales;

    public Vehiculo(String matricula, String modelo, String marca, int añoMatriculacion, int categoria) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.marca = marca;
        this.añoMatriculacion = añoMatriculacion;
        this.categoria = categoria;
    }

    public double alquiler(int dias) {

        double precio = 0;

        if (alquilado == true) {

            return 0;

        }

        if (categoria == 1) {

            if (dias <= 2) {

                precio = dias * 45;

            } else {

                precio = dias * 30;

            }

        } else {

            if (dias <= 2) {

                precio = dias * 50;

            } else {

                precio = dias * 40;

            }

        }

        alquilado = true;

        ganancias += precio;

        gananciasTotales += precio;

        return precio;

    }

    public void devolver() {

        if (alquilado == true) {

            alquilado = false;

            System.out.println("EL VEHÍCULO HA SIDO DEVUELTO.");

        } else {

            System.out.println("ERROR. EL VEHÍCULO AÚN NO HA SIDO ALQUILADO.");

        }

    }

    @Override
    public String toString() {
        return "Vehiculo{" + "matricula=" + matricula + ", modelo=" + modelo + ", marca=" + marca + ", a\u00f1oMatriculacion=" + añoMatriculacion + ", categoria=" + categoria + '}';
    }

    public int getCategoria() {
        return categoria;
    }

    public boolean isAlquilado() {
        return alquilado;
    }

    public String getMatricula() {
        return matricula;
    }

    public double getGanancias() {
        return ganancias;
    }

    public static double getGananciasTotales() {
        return gananciasTotales;
    }

}
