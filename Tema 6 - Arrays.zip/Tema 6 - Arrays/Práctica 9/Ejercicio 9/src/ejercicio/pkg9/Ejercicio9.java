/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg9;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Equipo equipos[] = new Equipo[10];
        equipos[0] = new Equipo("BARCELONA");
        equipos[1] = new Equipo("REAL MADRID");
        equipos[2] = new Equipo("ATLETICO MADRID");
        equipos[3] = new Equipo("SEVILLA");
        equipos[4] = new Equipo("REAL SOCIEDAD");
        equipos[5] = new Equipo("GETAFE");
        equipos[6] = new Equipo("GRANADA");
        equipos[7] = new Equipo("VALENCIA");
        equipos[8] = new Equipo("OSASUNA");
        equipos[9] = new Equipo("REAL BETIS");

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int opcion;

        do {

            System.out.println("INTRODUZCA UNA OPCIÓN: \n1. INTRODUCIR PARTIDO. \n2. ORDENAR EQUIPOS POR PUNTUACIÓN. \n3. MOSTRAR INFORMACIÓN DE EQUIPOS. \n4. SALIR DEL PROGRAMA.");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    sc.nextLine();

                    int equipo = -1;
                    int posicion = 0;

                    for (int i = 1; i <= 2; i += 1) {

                        do {

                            System.out.println("INTRODUZCA EL NOMBRE DEL EQUIPO " + i + ": ");
                            String nombre = sc.nextLine();

                            posicion = buscar(nombre, equipos);

                            if (posicion == -1) {

                                System.out.println("NOMBRE DE EQUIPO NO ENCONTRADO. ");

                            } else if (posicion == equipo) {

                                System.out.println("EL EQUIPO YA ESTÁ SELECCIONADO. ");

                            }

                        } while (posicion == -1 || equipo == posicion);

                        if (i == 1) {

                            equipo = posicion;

                        }

                    }

                    int golesAnotadosEquipo1 = 0; // CORRESPONDE CON EL EQUIPO CON VARIABLE equipo. 
                    int golesAnotadosEquipo2 = 0; // CORRESPONDE CON EL EQUIPO CON VARIABLE posicion. 

                    for (int i = 1; i <= 2; i += 1) {

                        int golesAnotados;

                        do {

                            System.out.println("INTRODUZCA GOLES ANOTADOS POR EL EQUIPO " + i + ": ");
                            golesAnotados = sc.nextInt();

                        } while (golesAnotados < 0);

                        if (i == 1) {

                            golesAnotadosEquipo1 = golesAnotados;

                            equipos[equipo].setGolesAFavor(equipos[equipo].getGolesAFavor() + golesAnotados);

                            equipos[posicion].setGolesEnContra(equipos[posicion].getGolesEnContra() + golesAnotados);

                        }

                        if (i == 2) {

                            golesAnotadosEquipo2 = golesAnotados;

                            equipos[posicion].setGolesAFavor(equipos[posicion].getGolesAFavor() + golesAnotados);

                            equipos[equipo].setGolesEnContra(equipos[equipo].getGolesEnContra() + golesAnotados);

                        }

                    }

                    if (golesAnotadosEquipo1 > golesAnotadosEquipo2) {

                        equipos[equipo].setVictorias(equipos[equipo].getVictorias() + 1);

                        equipos[posicion].setDerrotas(equipos[posicion].getDerrotas() + 1);

                    } else if (golesAnotadosEquipo1 < golesAnotadosEquipo2) {

                        equipos[equipo].setDerrotas(equipos[equipo].getDerrotas() + 1);

                        equipos[posicion].setVictorias(equipos[posicion].getVictorias() + 1);

                    } else {

                        equipos[equipo].setEmpates(equipos[equipo].getEmpates() + 1);

                        equipos[posicion].setEmpates(equipos[posicion].getEmpates() + 1);

                    }

                    for (int i = 1; i <= 2; i += 1) {

                        int equipoPuntos;

                        if (i == 1) {

                            equipoPuntos = equipo;

                        } else {

                            equipoPuntos = posicion;

                        }

                        double totalPuntos = (equipos[equipoPuntos].getVictorias() * 3) + equipos[equipoPuntos].getEmpates();

                        equipos[equipoPuntos].setPuntos(totalPuntos);

                    }

                    break;

                case 2:

                    quicksort(equipos, 0, equipos.length - 1);

                    break;

                case 3:

                    for (int i = 0; i < equipos.length; i += 1) {

                        System.out.println(equipos[i].toString());

                    }

                    break;

                default:

                    if (opcion != 4) {

                        System.out.println("OPCIÓN NO VÁLIDA. ");

                    }

                    break;

            }

        } while (opcion != 4);

    }

    private static int buscar(String nombre, Equipo equipos[]) {

        for (int i = 0; i < equipos.length; i += 1) {

            if (equipos[i].getNombre().equalsIgnoreCase(nombre)) {

                return i;

            }

        }

        return -1;

    }

    public static void quicksort(Equipo array[], int izquierda, int derecha) {

        Equipo pivote = array[izquierda];
        int i = izquierda;
        int j = derecha;
        Equipo auxiliar;

        while (i < j) {

            // DESCENDENTE  
            while (array[i].getPuntos() >= pivote.getPuntos() && i < j) {

                i += 1;

            }

            while (array[j].getPuntos() < pivote.getPuntos()) {

                j -= 1;

            }

            if (i < j) {

                auxiliar = array[i];
                array[i] = array[j];
                array[j] = auxiliar;

            }

        }

        array[izquierda] = array[j];
        array[j] = pivote;

        if (izquierda < j - 1) {

            quicksort(array, izquierda, j - 1);

        }

        if (j + 1 < derecha) {

            quicksort(array, j + 1, derecha);

        }

    }

}
