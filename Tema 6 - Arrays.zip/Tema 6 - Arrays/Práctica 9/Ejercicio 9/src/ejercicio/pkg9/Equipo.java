/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg9;

/**
 *
 * @author Hugo
 */
public class Equipo {

    private String nombre;
    private int victorias;
    private int derrotas;
    private int empates;
    private int golesAFavor;
    private int golesEnContra;
    private double puntos;

    public Equipo(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setGolesAFavor(int golesAFavor) {
        this.golesAFavor = golesAFavor;
    }

    public void setGolesEnContra(int golesEnContra) {
        this.golesEnContra = golesEnContra;
    }

    public int getGolesAFavor() {
        return golesAFavor;
    }

    public int getGolesEnContra() {
        return golesEnContra;
    }

    public void setVictorias(int victorias) {
        this.victorias = victorias;
    }

    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

    public void setEmpates(int empates) {
        this.empates = empates;
    }

    public int getVictorias() {
        return victorias;
    }

    public int getDerrotas() {
        return derrotas;
    }

    public int getEmpates() {
        return empates;
    }

    public void setPuntos(double puntos) {
        this.puntos = puntos;
    }

    public double getPuntos() {
        return puntos;
    }

    @Override
    public String toString() {
        return "Equipo{" + "nombre=" + nombre + ", victorias=" + victorias + ", derrotas=" + derrotas + ", empates=" + empates + ", golesAFavor=" + golesAFavor + ", golesEnContra=" + golesEnContra + ", puntos=" + puntos + '}';
    }

}
