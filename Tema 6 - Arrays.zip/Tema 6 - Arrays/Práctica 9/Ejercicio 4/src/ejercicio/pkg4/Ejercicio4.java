/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombres[] = new String[5];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA NOMBRES: ");

        for (int i = 0; i < nombres.length; i += 1) {

            System.out.println("NOMBRE [" + (i + 1) + "]:");
            nombres[i] = sc.nextLine();

        }

        Arrays.sort(nombres);

        System.out.println("INTRODUZCA NOMBRE A BUSCAR: ");
        String nombre = sc.nextLine();
        /*
        boolean coincidencia = false;

        for (int i = 0; i < nombres.length; i += 1) {

            if (nombre.equalsIgnoreCase(nombres[i])) {

                coincidencia = true;

                break;

            }

        }

        if (coincidencia == true) {

            System.out.println("EL NOMBRE [" + nombre.toUpperCase() + "] SÍ SE ENCUENTRA EN LA LISTA.");

        } else {

            System.out.println("EL NOMBRE [" + nombre.toUpperCase() + "] NO SE ENCUENTRA EN LA LISTA.");

        }
         */
        int posicion = Arrays.binarySearch(nombres, nombre);

        if (posicion < 0) {

            System.out.println("EL NOMBRE [" + nombre.toUpperCase() + "] NO SE ENCUENTRA EN LA LISTA.");

        } else {

            System.out.println("EL NOMBRE [" + nombre.toUpperCase() + "] SÍ SE ENCUENTRA EN LA LISTA.");

        }

    }

}
