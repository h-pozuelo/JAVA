/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[10];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println("INTRODUZCA NÚMERO " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();

        }

        System.out.println("NÚMEROS PARES INTRODUCIDOS: ");

        for (int i = 0; i < numeros.length; i += 1) {

            if (numeros[i] % 2 == 0) {
                System.out.println(numeros[i]);
            }

        }

        System.out.println("NÚMEROS IMPARES INTRODUCIDOS: ");

        for (int i = 0; i < numeros.length; i += 1) {

            if (numeros[i] % 2 != 0) {
                System.out.println(numeros[i]);
            }

        }

    }

}
