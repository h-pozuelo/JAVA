/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[];
        int count = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("¿CUANTOS NÚMEROS DESEA INTRODUCIR?");
        int cantidad = sc.nextInt();

        numeros = new int[cantidad];

        for (int i = 0; i < numeros.length; i += 1) {

            System.out.println("INTRODUZCA NÚMERO " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();

        }

        for (int i = 0; i < numeros.length; i += 1) {

            if (numeros[i] == numeros[numeros.length - 1]) {
                count += 1;
            }

        }

        System.out.println("EL NÚMERO " + numeros[numeros.length - 1] + " SE REPITE " + count + " VECES.");

    }

}
