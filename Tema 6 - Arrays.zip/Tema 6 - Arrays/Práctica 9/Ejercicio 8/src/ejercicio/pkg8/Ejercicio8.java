/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg8;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        Cargamento cargamentos[];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int longitud;

        do {

            System.out.println("¿CANTIDAD DE CARGAMENTOS?");
            longitud = sc.nextInt();

            if (longitud <= 0 || longitud > 10) {

                System.out.println("CANTIDAD NO VÁLIDA. ");

            }

        } while (longitud <= 0 || longitud > 10);
        
        cargamentos = new Cargamento[longitud];
         */
        Cargamento cargamentos[] = new Cargamento[10];
        int posicion = 0;
        int posicion2;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int opcion;

        do {

            System.out.println("INTRODUZCA UNA OPCIÓN: \n1. DAR DE ALTA UN CARGAMENTO. \n2. MOSTRAR INFORMACIÓN DE LOS CARGAMENTOS. \n3. REBAJAR UN CARGAMENTO. \n4. VENDER FRUTA. \n5. MOSTRAR BENEFICIO OBTENIDO. \n6. ELIMINAR CARGAMENTOS VACÍOS. \n7. SALIR DEL PROGRAMA. ");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    if (posicion <= cargamentos.length - 1) {

                        sc.nextLine();

                        System.out.println("NOMBRE DEL CARGAMENTO: ");
                        String nombre = sc.nextLine();

                        System.out.println("PROCEDENCIA: ");
                        String procedencia = sc.nextLine();

                        System.out.println("PESO DEL CARGAMENTO: ");
                        double peso = sc.nextDouble();

                        System.out.println("PRECIO DE COSTE: ");
                        double precioCoste = sc.nextDouble();

                        System.out.println("PRECIO DE VENTA: ");
                        double precioVenta = sc.nextDouble();

                        cargamentos[posicion] = new Cargamento(nombre, procedencia, peso, precioCoste, precioVenta);

                        posicion += 1;

                    } else {

                        System.out.println("CAPACIDAD MÁXIMA DE CARGAMENTOS. ");

                    }

                    break;

                case 2:

                    for (int i = 0; i < posicion; i += 1) {

                        System.out.println(cargamentos[i].toString());

                    }

                    break;

                case 3:

                    boolean encontrado = false;

                    sc.nextLine();

                    System.out.println("INTRODUZCA NOMBRE DEL CARGAMENTO: ");
                    String nombre = sc.nextLine();

                    System.out.println("INTRODUZCA PROCEDENCIA: ");
                    String procedencia = sc.nextLine();
                    /*
                    posicion2 = buscar(cargamentos, posicion, nombre, procedencia);

                    if (posicion2 == -1) {

                        System.out.println("CARGAMENTO NO ENCONTRADO. ");

                    } else {

                        System.out.println("INTRODUZCA CANTIDAD A REBAJAR: ");
                        double descuento = sc.nextDouble();

                        boolean resultado = cargamentos[posicion2].rebajar(descuento);

                        if (resultado) {

                            System.out.println("REBAJA REALIZADA CON ÉXITO. ");

                        } else {

                            System.out.println("NO SE HA PODIDO REALIZAR LA REBAJA. ");

                        }

                    }
                     */
                    for (int i = 0; i < posicion; i += 1) {

                        if (nombre.equalsIgnoreCase(cargamentos[i].getNombre()) && procedencia.equalsIgnoreCase(cargamentos[i].getProcedencia())) {

                            encontrado = true;

                            double descuento;

                            do {

                                System.out.println("INTRODUZCA CANTIDAD A REBAJAR: ");
                                descuento = sc.nextDouble();

                            } while (!cargamentos[i].rebajar(descuento));

                            break;

                        }

                    }

                    if (!encontrado) {

                        System.out.println("CARGAMENTO NO ENCONTRADO. ");

                    }

                    break;

                case 4:

                    boolean cargamentoSuficiente = false;

                    encontrado = false;

                    sc.nextLine();

                    System.out.println("INTRODUZCA NOMBRE DEL CARGAMENTO: ");
                    nombre = sc.nextLine();

                    System.out.println("INTRODUZCA CANTIDAD: ");
                    double cantidad = sc.nextDouble();

                    for (int i = 0; i < posicion; i += 1) {

                        if (nombre.equalsIgnoreCase(cargamentos[i].getNombre())) {

                            encontrado = true;

                            if (cargamentos[i].vender(cantidad)) {

                                cargamentoSuficiente = true;

                                break;

                            } else {

                                System.out.println("BUSCANDO SIGUIENTE CARGAMENTO DE " + nombre.toUpperCase() + ".");

                            }

                        }

                    }

                    if (!encontrado) {

                        System.out.println("CARGAMENTO NO ENCONTRADO. ");

                    } else if (!cargamentoSuficiente) {

                        System.out.println("NO TENEMOS " + nombre.toUpperCase() + "SUFICIENTES. ");

                    }

                    break;

                case 5:

                    System.out.println("TOTAL DE BENEFICIOS: " + Cargamento.getBeneficios() + " €");

                    break;

                case 6:

                    sc.nextLine();

                    int tam = cargamentos.length;

                    System.out.println("INTRODUZCA NOMBRE DEL CARGAMENTO: ");
                    nombre = sc.nextLine();

                    System.out.println("INTRODUZCA PROCEDENCIA: ");
                    procedencia = sc.nextLine();

                    for (int i = 0; i < tam; i += 1) { // DADO QUE NO PONGO EL <= NO HACE FALTA QUE PONGA EL -1. 

                        if (nombre.equalsIgnoreCase(cargamentos[i].getNombre()) && procedencia.equalsIgnoreCase(cargamentos[i].getProcedencia())) {

                            for (int j = i; j < tam - 1; j += 1) { // COMIENZA A CONTAR DESDE EL VALOR DE LA VARIABLE i. EN ESTE CASO PONGO EL -1 (SIN PONER EL <=) DADO QUE LA ÚLTIMA CELDA LA VOY A ELIMINAR. 

                                cargamentos[j] = cargamentos[j + 1];

                            }

                            cargamentos[tam - 1] = null; // SI DESEO ELIMINAR EL ÚLTIMO ELEMENTO (EL TAMAÑO 8 NO ES LO MISMO QUE EL NÚMERO DEL ÚLTIMO ELEMENTO 7). 

                            tam -= 1; // COMO LUEGO UTILIZO ESTA VARIABLE PARA MOSTRAR EL VALOR DE CADA CELDA TENGO QUE DESCONTAR LA ÚLTIMA CELDA. 

                            break;

                        }

                    }

                    for (int i = 0; i < tam; i += 1) {

                        System.out.println(cargamentos[i].toString());

                    }

                    break;

                default:

                    if (opcion != 7) {

                        System.out.println("OPCIÓN NO VÁLIDA. ");

                    }

                    break;

            }

        } while (opcion != 7);

    }
    /*
    public static int buscar(Cargamento cargamentos[], int posicion, String nombre, String procedencia) {

        for (int i = 0; i < posicion; i += 1) {

            if (cargamentos[i].getNombre().equalsIgnoreCase(nombre) && cargamentos[i].getProcedencia().equalsIgnoreCase(procedencia)) {

                return i;

            }

        }

        return -1;

    }
     */
}
