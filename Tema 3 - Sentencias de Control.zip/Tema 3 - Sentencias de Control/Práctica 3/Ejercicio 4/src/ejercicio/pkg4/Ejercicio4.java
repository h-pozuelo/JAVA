/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a, b, c;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("Anota valor de A");
        a = sc.nextInt();
        System.out.println("Anota valor de B");
        b = sc.nextInt();
        System.out.println("Anota valor de C");
        c = sc.nextInt();

        if (a != b && a != c && b != c) {
            if (a > b && a > c) {
                System.out.println(a + " es mayor que " + b + " y " + c);
            } else if (b > a && b > c) {
                System.out.println(b + " es mayor que " + a + " y " + c);
            } else {
                System.out.println(c + " es mayor que " + a + " y " + b);
            }
        } else {
            System.out.println("Los números tienen que ser distintos");
        }
    }

}
