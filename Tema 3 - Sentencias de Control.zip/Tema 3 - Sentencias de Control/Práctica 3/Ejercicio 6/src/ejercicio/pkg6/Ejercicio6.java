/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double precioProducto;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("Introduce precio de producto");
        precioProducto = sc.nextDouble();

        if (precioProducto < 6) {
            System.out.println(precioProducto + " €");
        } else if (precioProducto < 60) {
            System.out.println(precioProducto * 0.95 + " €");
        } else {
            System.out.println(precioProducto * 0.9 + " €");
        }
    }

}
