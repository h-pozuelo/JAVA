/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg9;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int horas, minutos, segundos;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("");
        horas = sc.nextInt();
        System.out.println("");
        minutos = sc.nextInt();
        System.out.println("");
        segundos = sc.nextInt();

        if (minutos == 59 && segundos == 59) {
            segundos = 0;
            minutos = 0;
            minutos++;
            horas += 2;
        } else if (minutos == 59) {
            segundos++;
            minutos = 0;
            horas += 2;
        } else if (segundos == 59) {
            segundos = 0;
            minutos += 2;
            horas++;
        } else {
            segundos++;
            minutos++;
            horas++;
        }

        System.out.println(horas + ":" + minutos + ":" + segundos);
    }

}
