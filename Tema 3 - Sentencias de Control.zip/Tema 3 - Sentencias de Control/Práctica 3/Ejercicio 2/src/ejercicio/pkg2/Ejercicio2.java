/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a, b;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("Anota valor de A");
        a = sc.nextInt();
        System.out.println("Anota valor de B");
        b = sc.nextInt();

        if (a != b) {
            if (a > b) {
                System.out.println(a + " es mayor que " + b);
            } else if (b > a) {
                System.out.println(b + " es mayor que " + a);
            } else {
                System.out.println(a + " es igual que " + b);
            }
        } else {
            System.out.println("Los números tienen que ser distintos");
        }
    }

}
