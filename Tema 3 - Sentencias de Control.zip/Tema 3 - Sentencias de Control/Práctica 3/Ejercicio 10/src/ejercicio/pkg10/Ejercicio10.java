/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg10;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a, b, c, seccion;
        char categoria;

        a = 900;
        b = 1000;
        c = 1200;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("INTRODUZCA CATEGORÍA: ");
        categoria = sc.nextLine().charAt(0);

        if (categoria == 'A' || categoria == 'a') {
            System.out.println(a + 240 + " €");
        } else if (categoria == 'B' || categoria == 'b') {
            System.out.println(b + 240 + " €");
        } else if (categoria == 'C' || categoria == 'c') {

            System.out.println("INTRODUZCA SECCIÓN: ");
            seccion = sc.nextInt();

            if (seccion == 1) {

                int diasTrabajados, diasBajaInjustificada, bajaInjustificada;
                double suplemento = 0.5;

                bajaInjustificada = 30;

                System.out.println("INTRODUZCA DÍAS TRABAJADOS: ");
                diasTrabajados = sc.nextInt();
                System.out.println("INTRODUZCA DÍAS DE BAJA INJUSTIFICADA: ");
                diasBajaInjustificada = sc.nextInt();

                if (diasBajaInjustificada == 0) {
                    System.out.println(c + (diasTrabajados * suplemento) + " €");
                } else {
                    System.out.println(c + (diasTrabajados * suplemento) - (diasBajaInjustificada * bajaInjustificada) + " €");
                }

            } else {
                System.out.println(c + 120 + " €");
            }

        }
    }

}
