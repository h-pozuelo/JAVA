/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double precioBillete, distancia;
        int diasEstancia;

        final double precioPorKm = 0.05;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("Introduce distancia a recorrer");
        distancia = sc.nextDouble();
        System.out.println("Introduce días de estancia");
        diasEstancia = sc.nextInt();

        double precioFinal = distancia * precioPorKm * diasEstancia;

        if (distancia > 1000 && diasEstancia > 7) {
            System.out.println(precioFinal * 0.7 + " €");
        } else {
            System.out.println(precioFinal + " €");
        }
    }

}
