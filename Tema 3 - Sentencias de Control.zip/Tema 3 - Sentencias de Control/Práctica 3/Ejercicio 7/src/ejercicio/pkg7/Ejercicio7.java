/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

import java.util.*;

/**
 *
 * @author daw202323
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int ultimaLectura, actualLectura, consumo;
        double precio;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("Anota última lectura");
        ultimaLectura = sc.nextInt();
        System.out.println("Anora lectura actual");
        actualLectura = sc.nextInt();

        if (actualLectura >= ultimaLectura) {

            consumo = actualLectura - ultimaLectura;

            if (consumo <= 100) {
                precio = consumo * 0.5;
            } else if (consumo <= 250) {
                precio = 100 * 0.5 + (consumo - 100) * 0.7;
            } else {
                precio = 100 * 0.5 + 150 * 0.7 + (consumo - 250) * 1;
            }

            precio = precio + 2;

            System.out.println("Tienes que pagar: " + precio + " €");
        } else {
            System.out.println("Lectura incorrecta");
        }
    }

}
