/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num;
        long numL;
        float numF;
        double numD;

        num = Integer.MAX_VALUE;
        numL = Long.MAX_VALUE;
        numD = Double.MAX_VALUE;

        numL = 21474836476L;
        numF = 345.4F;
        numF = (float) 345.4;
        /*
        int num;
        double numD = 7.8;

        num = (int) numD;
        num = (int) 5.4;
        
        int num;
        double numD = 7.8;

        num = (int) numD;
        
        int num=7;
        double numD;
        
        numD=7;
         */
        System.out.println("El valor de num es: " + num);
        System.out.println("El valor de numL es: " + numL);
        System.out.println("El valor de numF es: " + numF);
        System.out.println("El valor de numD es: " + numD);
    }

}
