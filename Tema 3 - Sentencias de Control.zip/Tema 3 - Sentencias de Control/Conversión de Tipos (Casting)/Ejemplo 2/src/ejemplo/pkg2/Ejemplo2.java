/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num = 8, div;
        long numL;
        double numD = 8, divD;
        float numF;

        div = num / 3;
        System.out.println("El valor de div es: " + div);
        divD = numD / 3;
        System.out.println("El valor de div es: " + divD);
        divD = num / 3;
        System.out.println("El valor de div es: " + divD);
        divD = (double) num / 3;
        System.out.println("El valor de div es: " + divD);
        divD = num / 3.0;
        System.out.println("El valor de div es: " + divD);
    }

}
