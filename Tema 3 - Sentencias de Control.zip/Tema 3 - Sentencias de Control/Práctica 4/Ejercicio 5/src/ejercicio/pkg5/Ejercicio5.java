/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int año;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA UN AÑO: ");
        año = sc.nextInt();

        if ((año % 4 == 0) && ((año % 100 != 0) || (año % 400 == 0))) {

            System.out.println("EL AÑO " + año + " ES BISIESTO.");

        } else {

            System.out.println("EL AÑO " + año + " NO ES BISIESTO.");

        }
    }

}
