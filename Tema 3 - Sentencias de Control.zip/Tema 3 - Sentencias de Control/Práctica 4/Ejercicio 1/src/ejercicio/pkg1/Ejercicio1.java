/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int dia, mes, año;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("INTRODUZCA DÍA: ");
        dia = sc.nextInt();
        System.out.println("INTRODUZCA MES: ");
        mes = sc.nextInt();
        System.out.println("INTRODUZCA AÑO: ");
        año = sc.nextInt();

        if (dia == 31 && mes == 12) {
            dia = 1;
            mes = 1;
            mes += 1;
            año += 2;
        } else if (dia == 31 && (mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10)) {
            dia = 1;
            mes += 2;
            año += 1;
        } else if (dia == 30 && mes == 11) {
            dia = 1;
            mes = 1;
            año += 2;
        } else if (dia == 30 && (mes == 4 || mes == 6 || mes == 9)) {
            dia = 1;
            mes += 2;
            año += 1;
        } else if (dia == 28 && mes == 2) {
            dia = 1;
            mes += 2;
            año += 1;
        } else if (mes == 12) {
            dia += 1;
            mes = 1;
            año += 2;
        } else {
            dia += 1;
            mes += 1;
            año += 1;
        }

        System.out.println(dia + "/" + mes + "/" + año);

    }

}
