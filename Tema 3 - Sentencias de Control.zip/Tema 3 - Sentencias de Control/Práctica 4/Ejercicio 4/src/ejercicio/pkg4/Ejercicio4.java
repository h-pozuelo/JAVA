/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int formato, horas, minutos, segundos;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("FORMATO: ");
        System.out.println("(1) HH:MM:SS");
        System.out.println("(2) SEGUNDOS");
        formato = sc.nextInt();

        if (formato == 1) {

            System.out.println("INTRODUZCA EL NÚMERO DE HORAS: ");
            horas = sc.nextInt();

            System.out.println("INTRODUZCA EL NÚMERO DE MINUTOS: ");
            minutos = sc.nextInt();

            System.out.println("INTRODUZCA EL NÚMERO DE SEGUNDOS: ");
            segundos = sc.nextInt();

            System.out.println((horas * 3600) + (minutos * 60) + segundos + " SEGUNDOS.");

        } else if (formato == 2) {

            System.out.println("INTRODUZCA EL NÚMERO DE SEGUNDOS: ");
            segundos = sc.nextInt();

            horas = segundos / 3600;

            minutos = (segundos % 3600) / 60;

            segundos = (segundos % 3600) % 60;

            System.out.println(horas + ":" + minutos + ":" + segundos);

        } else {

            System.out.println("OPERACIÓN NO VÁLIDA.");
            System.exit(0);

        }
    }

}
