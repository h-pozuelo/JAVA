/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num1, num2, num3;
        char orden;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("INTRODUZCA NÚMERO 1: ");
        num1 = sc.nextInt();
        System.out.println("INTRODUZCA NÚMERO 2: ");
        num2 = sc.nextInt();
        System.out.println("INTRODUZCA NÚMERO 3: ");
        num3 = sc.nextInt();
        System.out.println("¿ORDEN DE VISUALIZACIÓN?");
        sc.nextLine();
        orden = sc.nextLine().charAt(0);

        switch (orden) {
            case 'A':
            case 'a':

                System.out.println("HA ESCOGIDO ORDEN DE VISUALIZACIÓN ASCENDENTE.");

                if (num1 > num2 && num1 > num3 && num2 > num3) {
                    System.out.println(num3 + " > " + num2 + " > " + num1);
                } else if (num1 < num2 && num1 > num3 && num2 > num3) {
                    System.out.println(num3 + " > " + num1 + " > " + num2);
                } else if (num1 < num2 && num1 < num3 && num2 > num3) {
                    System.out.println(num1 + " > " + num3 + " > " + num2);
                } else if (num1 < num2 && num1 < num3 && num2 < num3) {
                    System.out.println(num1 + " > " + num2 + " > " + num3);
                } else if (num1 > num2 && num1 < num3 && num2 < num3) {
                    System.out.println(num2 + " > " + num1 + " > " + num3);
                } else if (num1 > num2 && num1 > num3 && num2 < num3) {
                    System.out.println(num2 + " > " + num3 + " > " + num1);
                }

                break;
            case 'D':
            case 'd':

                System.out.println("HA ESCOGIDO ORDEN DE VISUALIZACIÓN DESCENDENTE.");

                if (num1 > num2 && num1 > num3 && num2 > num3) {
                    System.out.println(num1 + " > " + num2 + " > " + num3);
                } else if (num1 < num2 && num1 > num3 && num2 > num3) {
                    System.out.println(num2 + " > " + num1 + " > " + num3);
                } else if (num1 < num2 && num1 < num3 && num2 > num3) {
                    System.out.println(num2 + " > " + num3 + " > " + num1);
                } else if (num1 < num2 && num1 < num3 && num2 < num3) {
                    System.out.println(num3 + " > " + num2 + " > " + num1);
                } else if (num1 > num2 && num1 < num3 && num2 < num3) {
                    System.out.println(num3 + " > " + num1 + " > " + num2);
                } else if (num1 > num2 && num1 > num3 && num2 < num3) {
                    System.out.println(num1 + " > " + num3 + " > " + num2);
                }

                break;
            default:
                System.out.println("CARÁCTER INVÁLIDO.");
                System.exit(0);
        }
    }

}
