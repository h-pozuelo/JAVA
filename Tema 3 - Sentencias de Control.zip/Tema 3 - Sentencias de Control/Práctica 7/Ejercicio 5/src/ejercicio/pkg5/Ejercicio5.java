/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final double precioEntrada = 5;
        char diaSemana, finalizarCompra;
        int descuento;
        double precioFinal, precioTotal = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA DÍA DE LA SEMANA: ");
        diaSemana = sc.nextLine().charAt(0);

        diaSemana = Character.toUpperCase(diaSemana);

        while (diaSemana(diaSemana) != true) {

            System.out.println("DÍA DE LA SEMANA NO VÁLIDO.");

            System.out.println("INTRODUZCA DÍA DE LA SEMANA: ");
            diaSemana = sc.nextLine().charAt(0);

            diaSemana = Character.toUpperCase(diaSemana);

        }

        do {

            descuento = descuento(diaSemana);

            precioFinal = precioEntrada - (precioEntrada * descuento / 100);

            System.out.println("USTED DISFRUTA DE UN " + descuento + "% DE DESCUENTO EN SU ENTRADA: " + precioFinal + " €");

            precioTotal = precioTotal + precioFinal;

            System.out.println("¿DESEA COMPRAR OTRA ENTRADA?");
            finalizarCompra = sc.nextLine().charAt(0);

            finalizarCompra = Character.toUpperCase(finalizarCompra);

            while (finalizarCompra != 'S' && finalizarCompra != 'N') {

                System.out.println("OPCIÓN NO VÁLIDA.");

                System.out.println("¿DESEA COMPRAR OTRA ENTRADA?");
                finalizarCompra = sc.nextLine().charAt(0);

                finalizarCompra = Character.toUpperCase(finalizarCompra);

            }

        } while (finalizarCompra != 'N');

        System.out.println("TOTAL: " + precioTotal + " €");

    }

    public static boolean diaSemana(char diaSemana) {

        boolean validador = true;

        if (diaSemana != 'L' && diaSemana != 'M' && diaSemana != 'X' && diaSemana != 'J' && diaSemana != 'V' && diaSemana != 'S' && diaSemana != 'D') {
            validador = false;
        }

        return validador;

    }

    public static int descuento(char diaSemana) {

        int descuento = 0, edad;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        switch (diaSemana) {

            case 'L':
            case 'J':
            case 'V':

                descuento = 0;

                break;

            case 'M':

                System.out.println("INTRODUZCA EDAD: ");
                edad = sc.nextInt();

                if (edad > 65) {
                    descuento = 50;
                } else {
                    descuento = 0;
                }

                break;

            case 'X':

                descuento = 20;

                break;

            case 'S':
            case 'D':

                System.out.println("INTRODUZCA EDAD: ");
                edad = sc.nextInt();

                if (edad < 18) {
                    descuento = 15;
                } else {
                    descuento = 0;
                }

                break;

        }

        return descuento;

    }

}
