/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double numero, resultado;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA NÚMERO: ");
        numero = sc.nextDouble();

        resultado = factorial(numero);

        System.out.println(resultado);

    }

    public static double factorial(double numero) {

        double resultado = 1;

        for (; numero != 0; numero--) {
            resultado = resultado * numero;
        }

        return resultado;

    }

}
