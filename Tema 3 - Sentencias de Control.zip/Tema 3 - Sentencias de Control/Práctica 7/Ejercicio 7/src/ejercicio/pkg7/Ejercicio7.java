/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int totalDias, mm, dd = 0;
        char continuar;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("INTRODUZCA CANTIDAD DE DÍAS: ");
            totalDias = sc.nextInt();

            while (totalDias < 1 || totalDias > 365) {
                System.out.println("VALOR NO VÁLIDO. INTRODUZCA CANTIDAD DE DÍAS: ");
                totalDias = sc.nextInt();
            }

            dd = totalDias;

            for (mm = 1; dd > diasMes(mm); mm += 1) {
                dd = dd - diasMes(mm);
            }

            switch (mm) {
                case 1:
                    System.out.println(dd + " de Enero [día " + totalDias + "]");
                    break;
                case 2:
                    System.out.println(dd + " de Febrero [día " + totalDias + "]");
                    break;
                case 3:
                    System.out.println(dd + " de Marzo [día " + totalDias + "]");
                    break;
                case 4:
                    System.out.println(dd + " de Abril [día " + totalDias + "]");
                    break;
                case 5:
                    System.out.println(dd + " de Mayo [día " + totalDias + "]");
                    break;
                case 6:
                    System.out.println(dd + " de Junio [día " + totalDias + "]");
                    break;
                case 7:
                    System.out.println(dd + " de Julio [día " + totalDias + "]");
                    break;
                case 8:
                    System.out.println(dd + " de Agosto [día " + totalDias + "]");
                    break;
                case 9:
                    System.out.println(dd + " de Septiembre [día " + totalDias + "]");
                    break;
                case 10:
                    System.out.println(dd + " de Octubre [día " + totalDias + "]");
                    break;
                case 11:
                    System.out.println(dd + " de Noviembre [día " + totalDias + "]");
                    break;
                case 12:
                    System.out.println(dd + " de Diciembre [día " + totalDias + "]");
                    break;
            }

            sc.nextLine();

            System.out.println("¿DESEA CONTINUAR LA OPERACIÓN?");
            continuar = sc.nextLine().charAt(0);

            continuar = Character.toUpperCase(continuar);

            while (continuar != 'S' && continuar != 'N') {

                System.out.println("CARÁCTER NO VÁLIDO. ¿DESEA CONTINUAR LA OPERACIÓN?");
                continuar = sc.nextLine().charAt(0);

                continuar = Character.toUpperCase(continuar);

            }

        } while (continuar == 'S');
    }

    public static int diasMes(int mm) {

        int diasMes = 0;

        switch (mm) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:

                diasMes = 31;

                break;

            case 4:
            case 6:
            case 9:
            case 11:

                diasMes = 30;

                break;

            case 2:

                diasMes = 28;

                break;

        }

        return diasMes;

    }

}
