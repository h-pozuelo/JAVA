/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg10;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA NÚMERO: ");
        num = sc.nextInt();

        if (funcionArmstrong(num) == true) {

            System.out.println("SÍ ES UN NÚMERO ARMSTRONG.");

        } else {

            System.out.println("NO ES UN NÚMERO ARMSTRONG. ");

        }
    }

    public static boolean funcionArmstrong(int num) {

        int numRaiz = num, suma = 0, raiz, numArmstrong = num;

        for (raiz = 0; numRaiz != 0; raiz += 1) {

            numRaiz /= 10;

        }

        do {

            int resto = num % 10;

            num /= 10;

            suma = suma + (int) Math.pow(resto, raiz);

        } while (num != 0);

        if (suma == numArmstrong) {

            return true;

        } else {

            return false;

        }

    }

}
