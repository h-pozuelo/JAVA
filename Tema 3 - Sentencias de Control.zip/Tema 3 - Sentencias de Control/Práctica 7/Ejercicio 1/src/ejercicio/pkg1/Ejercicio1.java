/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numEmple, horasExtras;
        float sueldo, precioH, otrosIngresos, finalPrecio;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA NÚMERO DE EMPLEADO: ");
        numEmple = sc.nextInt();

        while (numEmple != 0) {

            System.out.println("INTRODUZCA SUELDO: ");
            sueldo = sc.nextFloat();

            System.out.println("INTRODUZCA HORAS EXTRAS: ");
            horasExtras = sc.nextInt();

            System.out.println("INTRODUZCA PRECIO HORAS EXTRAS: ");
            precioH = sc.nextFloat();

            System.out.println("INTRODUZCA OTROS INGRESOS: ");
            otrosIngresos = sc.nextFloat();

            finalPrecio = calcularSalario(sueldo, horasExtras, precioH, otrosIngresos); // EL ORDEN EN EL QUE INTRODUZCAMOS LAS VARIABLES SERÁ COMO SE RECOJAN EN LA FUNCIÓN CREADA. 

            if (finalPrecio > 600) {
                System.out.println("EL EMPLEADO " + numEmple + " GANA " + finalPrecio + " €.");
            }

            System.out.println("INTRODUZCA NÚMERO DE EMPLEADO: ");
            numEmple = sc.nextInt();

        }
    }

    public static float calcularSalario(float sueldo, int horasExtras, float precioH, float otrosIngresos) { // MIENTRAS EL TIPO DE VARIABLE SEA EL MISMO NO HACE FALTA QUE COINCIDA EL NOMBRE DE LA VARIABLE. 

        float resultado;

        resultado = sueldo + (horasExtras * precioH) + otrosIngresos;

        return resultado;

    }

}
