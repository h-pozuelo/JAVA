/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int dd, mm, aa, totalDias = 0;
        boolean esBisiesto;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA DÍA: ");
        dd = sc.nextInt();
        /*
        while (dd < 1 || dd > 31) {
            System.out.println("DÍA NO VÁLIDO. INTRODUZCA DÍA DE NUEVO: ");
            dd = sc.nextInt();
        }
         */
        System.out.println("INTRODUZCA MES: ");
        mm = sc.nextInt();
        /*
        while (mm < 1 || mm > 12) {
            System.out.println("MES NO VÁLIDO. INTRODUZCA MES DE NUEVO: ");
            dd = sc.nextInt();
        }

        switch (mm) {
            case 2:
                while (dd < 1 || dd > 29) {
                    System.out.println("DÍA NO VÁLIDO. INTRODUZCA DÍA DE NUEVO: ");
                    dd = sc.nextInt();
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                while (dd < 1 || dd > 30) {
                    System.out.println("DÍA NO VÁLIDO. INTRODUZCA DÍA DE NUEVO: ");
                    dd = sc.nextInt();
                }
                break;
        }
         */
        System.out.println("INTRODUZCA AÑO: ");
        aa = sc.nextInt();
        /*
        while (aa < 1000 || aa > 9999) {
            System.out.println("AÑO NO VÁLIDO. INTRODUZCA AÑO DE NUEVO: ");
            aa = sc.nextInt();
        }
        
        if ((aa % 4 != 0 || (aa % 100 == 0 && aa % 400 != 0)) && mm == 2) {

            esBisiesto = false;

            while (dd < 1 || dd > 28) {
                System.out.println("DÍA NO VÁLIDO. INTRODUZCA DÍA DE NUEVO: ");
                dd = sc.nextInt();
            }

        } else {

            esBisiesto = true;

        }
         */
        esBisiesto = esBisiesto(aa);

        for (int i = 1; i < mm; i += 1) { // RECORRE EL BUCLE SIEMPRE Y CUANDO EL VALOR DE i NO COINCIDA CON EL VALOR DEL MES INTRODUCIDO. 
            totalDias = diasMes(i, aa, esBisiesto) + totalDias;
        }

        totalDias += dd; // SUMA LOS DÍAS RESTANTES. 

        switch (mm) {
            case 1:
                System.out.println(dd + " de Enero [día " + totalDias + "]");
                break;
            case 2:
                System.out.println(dd + " de Febrero [día " + totalDias + "]");
                break;
            case 3:
                System.out.println(dd + " de Marzo [día " + totalDias + "]");
                break;
            case 4:
                System.out.println(dd + " de Abril [día " + totalDias + "]");
                break;
            case 5:
                System.out.println(dd + " de Mayo [día " + totalDias + "]");
                break;
            case 6:
                System.out.println(dd + " de Junio [día " + totalDias + "]");
                break;
            case 7:
                System.out.println(dd + " de Julio [día " + totalDias + "]");
                break;
            case 8:
                System.out.println(dd + " de Agosto [día " + totalDias + "]");
                break;
            case 9:
                System.out.println(dd + " de Septiembre [día " + totalDias + "]");
                break;
            case 10:
                System.out.println(dd + " de Octubre [día " + totalDias + "]");
                break;
            case 11:
                System.out.println(dd + " de Noviembre [día " + totalDias + "]");
                break;
            case 12:
                System.out.println(dd + " de Diciembre [día " + totalDias + "]");
                break;
        }
    }

    public static boolean esBisiesto(int aa) {

        return (aa % 4 == 0 && (aa % 100 != 0 || aa % 400 == 0));
        /*
        if (aa % 4 == 0 && (aa % 100 != 0 || aa % 400 == 0)) {
            return true;
        } else {
            return false;
        }
         */
    }

    public static int diasMes(int i, int aa, boolean esBisiesto) { // LA SIGUIENTE FUNCIÓN ME DEVUELVE LA CANTIDAD DE DÍAS QUE TIENE EL MES CORRESPONDIENTE. 

        int diasMes = 0;

        switch (i) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:

                diasMes = 31;

                break;

            case 4:
            case 6:
            case 9:
            case 11:

                diasMes = 30;

                break;

            case 2:

                if (esBisiesto == true) {

                    diasMes = 29;

                } else {

                    diasMes = 28;

                }

                break;

        }

        return diasMes;

    }

}
