/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numero;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("INTRODUZCA NÚMERO: ");
            numero = sc.nextInt();

            if (numero >= 100) {
                System.out.println("NÚMERO NO VÁLIDO.");
            }

        } while (numero >= 100);

        mostrar(numero);

    }

    public static void mostrar(int num) {

        for (int i = 1; i <= num; i += 1) {
            System.out.println("MÓDULO EJECUTÁNDOSE.");
        }

    }

}
