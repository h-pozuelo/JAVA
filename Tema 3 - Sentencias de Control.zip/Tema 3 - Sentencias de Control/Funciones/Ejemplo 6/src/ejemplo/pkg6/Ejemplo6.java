/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean primo = true;
        int numPrimos = 0, numero = 1;
        final int totalPrimos = 20;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        while (numPrimos < totalPrimos) {

            if (esPrimo(numero)) {

                System.out.println(numero);

                numPrimos += 1;

            }

            numero += 1;

        }
    }

    public static boolean esPrimo(int n) {

        for (int i = 2; i < n; i += 1) {

            if (n % i == 0) {

                return false;

            }

        }
        return true;

    }

}
