/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int año;
        char respuesta;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            do {

                System.out.println("INTRODUZCA AÑO: ");
                año = sc.nextInt();

                if (año < 1000 || año > 9999) {
                    System.out.println("AÑO NO VÁLIDO.");
                }

            } while (año < 1000 || año > 9999);
            /*
            boolean bisiesto = esBisiesto(año); // TAMBIÉN PODEMOS ALMACENAR EL VALOR DE LA FUNCIÓN EN UNA VARIABLE. 
             */
            if (esBisiesto(año) == true) {
                System.out.println("ES BISIESTO.");
            } else {
                System.out.println("NO ES BISIESTO.");
            }

            sc.nextLine(); // LIMPIAR EL BUFFER. 

            System.out.println("¿DESEA INTRODUCIR OTRO AÑO?");
            respuesta = sc.nextLine().charAt(0);

        } while (respuesta == 'S' || respuesta == 's'); // TAMBIÉN SERÍA VÁLIDA LA SIGUIENTE CONDICIÓN [while (respuesta != 'N' && respuesta != 'N')]. 
    }

    public static boolean esBisiesto(int a) {

        return (a % 4 == 0 && (a % 100 != 0 || a % 400 == 0)); // ESTO ES LO MISMO QUE LO DE ABAJO, YA QUE SI SE CUMPLE LA CONDICIÓN EL VALOR SERÁ TRUE. 
        /*
        if (a % 4 == 0 && (a % 100 != 0 || a % 400 == 0)) {
            return true;
        } else {
            return false;
        }
         */
    }

}
