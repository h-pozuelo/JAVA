/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) { // VOID SIGNIFICA QUE NO DEVUELVE NINGÚN VALOR. 
        // TODO code application logic here
        int num1, num2, suma;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA NÚMERO 1: ");
        num1 = sc.nextInt();

        System.out.println("INTRODUZCA NÚMERO 2: ");
        num2 = sc.nextInt();

        suma = sumar(num1, num2); // UTILIZAR EL DEBUG DESDE ESTA LÍNEA PARA COMPROBAR CUANDO ALMACENA VALORES EN LAS VARIABLES A Y B. 

        System.out.println("LA SUMA ES: " + suma);

    }

    public static int sumar(int a, int b) { // ES IGUAL DE VÁLIDO TANTO PUBLIC COMO PRIVATE. 

        int resultado;

        resultado = a + b;

        return resultado;

    }

}
