/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int N = 7, num;

        double a = (int) (Math.random() * 10); // Número entre 0-9
        double b = (int) (Math.random() * 10) + 1; // Número entre 1-10
        double c = (int) (Math.random() * 11); // Número entre 0-10

        Random r = new Random();
        N = r.nextInt(10); // Número entre 0-9 (Excluido el 10)
        N = r.nextInt(10) + 1; // Número entre 0-10
        System.out.println("NÚMERO ENTRE 0 Y 10: " + N);

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("INTRODUZCA UN NÚMERO: ");
        num = sc.nextInt();

        while (num != N) {

            if (num > N) {
                System.out.println("EL NÚMERO INTRODUCIDO ES MAYOR QUE N.");
            } else {
                System.out.println("EL NÚMERO INTRODUCIDO ES MENOR QUE N.");
            }

            System.out.println("INTRODUZCA UN NÚMERO: ");
            num = sc.nextInt();

        }

        System.out.println("¡¡HAS ACERTADO!!");
    }

}
