/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg11;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numCount = 0, num, parCount = 0, imparCount = 0, nuloCount = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            numCount += 1;

            System.out.println("INTRODUZCA " + numCount + "º NÚMERO: ");
            num = sc.nextInt();

            if (num % 2 == 0 && num != 0) {

                parCount += 1;

            } else if (num % 2 == 1) {

                imparCount += 1;

            } else {

                nuloCount += 1;

            }

        } while (numCount < 100);

        System.out.println("CANTIDAD DE NÚMEROS PARES: " + parCount);
        System.out.println("CANTIDAD DE NÚMEROS IMPARES: " + imparCount);
        System.out.println("CANTIDAD DE NÚMEROS NULOS: " + nuloCount);
    }

}
