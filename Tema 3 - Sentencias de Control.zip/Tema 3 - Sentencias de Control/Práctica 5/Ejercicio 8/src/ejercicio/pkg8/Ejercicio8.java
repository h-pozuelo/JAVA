/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg8;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int salario, salarioCount = 0, empleadoCount = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA SALARIO DEL EMPLEADO: ");
        salario = sc.nextInt();

        if (salario > 1000) {
            salarioCount += 1;
        }

        empleadoCount += 1;

        while (empleadoCount < 10) {

            System.out.println("INTRODUZCA SALARIO DEL EMPLEADO: ");
            salario = sc.nextInt();

            if (salario > 1000) {
                salarioCount += 1;
            }

            empleadoCount += 1;

        }

        System.out.println(salarioCount + " EMPLEADOS COBRAN MÁS DE 1000 €.");
    }

}
