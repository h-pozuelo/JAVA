/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num, suma = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("INTRODUZCA UN NÚMERO: ");
        num = sc.nextInt();

        while (num != 0) {
            suma += num;
            System.out.println("INTRODUZCA UN NÚMERO: ");
            num = sc.nextInt();
        }

        System.out.println("LA SUMA DE LOS NÚMEROS INTRODUCIDOS ES: " + suma);
    }

}
