/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg19;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num1, num2, numMayor, numMenor, numero;
        char orden;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA NÚMERO 1: ");
        num1 = sc.nextInt();

        System.out.println("INTRODUZCA NÚMERO 2: ");
        num2 = sc.nextInt();

        if (num1 > num2) {
            numMayor = num1;
            numMenor = num2;
        } else {
            numMayor = num2;
            numMenor = num1;
        }

        System.out.println("¿EN QUE ORDEN DESEA VISUALIZARLO?");
        sc.nextLine();
        orden = sc.nextLine().charAt(0);

        switch (orden) {
            case 'A':
            case 'a':
                for (numero = numMenor + 1; numero != numMayor; numero += 1) {
                    System.out.println(numero);
                }
                break;
            case 'D':
            case 'd':
                for (numero = numMayor - 1; numero != numMenor; numero -= 1) {
                    System.out.println(numero);
                }
                break;
        }
    }

}
