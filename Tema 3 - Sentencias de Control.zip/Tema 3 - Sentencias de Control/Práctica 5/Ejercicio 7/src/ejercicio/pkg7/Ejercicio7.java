/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num, suma, count = 0;
        double average;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        System.out.println("INTRODUZCA UN NÚMERO: ");
        num = sc.nextInt();
        suma = num;

        while (num >= 0) {
            System.out.println("INTRODUZCA UN NÚMERO: ");
            num = sc.nextInt();
            if (num >= 0) {
                suma += num;
            }
            count++;
        }

        average = suma / count;

        System.out.println("LA MEDIA DE LOS NÚMEROS INTRODUCIDOS ES: " + average);
    }

}
