/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg20;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numCount;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (numCount = 2; numCount < 100; numCount++) {
            if (numCount % 5 != 0) {
                System.out.println(numCount);
            }
        }
    }

}
