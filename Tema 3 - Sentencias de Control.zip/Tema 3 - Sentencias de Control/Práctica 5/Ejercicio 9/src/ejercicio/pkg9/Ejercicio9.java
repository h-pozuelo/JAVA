/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg9;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int edad, edadSuma = 0, alumnosCount = 0, edadCount = 0, alturaCount = 0;
        double altura, alturaSuma = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        while (alumnosCount < 5) {

            alumnosCount += 1;

            System.out.println("INTRODUZCA EDAD DEL ALUMNO: ");
            edad = sc.nextInt();

            edadSuma = edadSuma + edad;

            System.out.println("INTRODUZCA ALTURA DEL ALUMNO: ");
            altura = sc.nextDouble();

            alturaSuma = alturaSuma + altura;

            if (edad > 18) {
                edadCount += 1;
            }

            if (altura > 1.75) {
                alturaCount += 1;
            }

        }

        System.out.println("MEDIA DE EDAD: " + edadSuma / alumnosCount);
        System.out.println("MEDIA DE ALTURA: " + alturaSuma / alumnosCount);
        System.out.println("CANTIDAD DE ALUMNOS CON EDAD > 18: " + edadCount);
        System.out.println("CANTIDAD DE ALUMNOS CON ALTURA > 1.75: " + alturaCount);
    }

}
