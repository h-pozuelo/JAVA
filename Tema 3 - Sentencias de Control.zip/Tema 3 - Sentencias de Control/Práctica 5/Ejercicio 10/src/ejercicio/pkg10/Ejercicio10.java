/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg10;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int notaCount = 0, nota = 0, suspensosCount = 0, aprobadosCount = 0, notablesCount = 0, sobresalientesCount = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            notaCount += 1;

            System.out.println("INTRODUZCA " + notaCount + "ª NOTA: ");
            nota = sc.nextInt();

            while ((nota < 0 && nota != -1) || nota > 10) {

                System.out.println("NOTA NO VÁLIDA.");

                System.out.println("INTRODUZCA " + notaCount + "ª NOTA: ");
                nota = sc.nextInt();

            }

            if (nota >= 0 && nota < 5) {

                suspensosCount += 1;

            } else if (nota >= 5 && nota <= 10) {

                aprobadosCount += 1;

                if (nota >= 7 && nota < 8) {
                    notablesCount += 1;
                }

                if (nota >= 8) {
                    sobresalientesCount += 1;
                }

            }

        } while (nota != -1);

        System.out.println("CANTIDAD DE SUSPENSOS: " + suspensosCount);
        System.out.println("CANTIDAD DE APROBADOS: " + aprobadosCount);
        System.out.println("CANTIDAD DE NOTABLES: " + notablesCount);
        System.out.println("CANTIDAD DE SOBRESALIENTES: " + sobresalientesCount);
    }

}
