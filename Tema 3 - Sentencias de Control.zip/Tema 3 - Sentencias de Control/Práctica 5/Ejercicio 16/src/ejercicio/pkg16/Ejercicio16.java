/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg16;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int articuloCodigo, facturaSeiscientos = 0;
        double articuloCantidad = 0, articuloPrecio, facturaTotal = 0, articuloUno = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int articuloCount = 1; articuloCount <= 5; articuloCount += 1) {

            System.out.println("ARTÍCULO NÚMERO " + articuloCount + "º: ");

            System.out.println("INTRODUZCA CÓDIGO DE ARTÍCULO: ");
            articuloCodigo = sc.nextInt();

            System.out.println("INTRODUZCA CANTIDAD DE LITROS VENDIDOS: ");
            articuloCantidad = sc.nextDouble();

            if (articuloCount == 1) {
                articuloUno = articuloCantidad;
            }

            System.out.println("INTRODUZCA CANTIDAD DE EUROS POR LITRO: ");
            articuloPrecio = sc.nextDouble();

            facturaTotal = facturaTotal + (articuloCantidad * articuloPrecio);

            if ((articuloCantidad * articuloPrecio) > 600) {
                facturaSeiscientos += 1;
            }

        }

        System.out.println("FACTURACIÓN TOTAL: " + facturaTotal + " €");
        System.out.println("CANTIDAD DE LITROS VENDIDOS (ARTÍCULO NÚMERO 1º): " + articuloUno + " L");
        System.out.println("CANTIDAD DE FACTURAS > 600: " + facturaSeiscientos);
    }

}
