/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg18;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num, numCount, numMax = 0, numMin = 0;
        // int numMax = Integer.MIN_VALUE, numMin = Integer.MAX_VALUE;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (numCount = 1; numCount <= 5; numCount++) {

            System.out.println("INTRODUZCA NÚMERO " + numCount + ": ");
            num = sc.nextInt();

            if (numCount == 1) {
                numMax = num;
                numMin = num;
            } else if (num > numMax) {
                numMax = num;
            } else {
                numMin = num;
            }
            /*
            if (num > numMax) {
                numMax = num;
            }

            if (num < numMin) {
                numMin = num;
            }
             */
        }

        System.out.println("EL NÚMERO " + numMax + " ES EL MAYOR.");
        System.out.println("EL NÚMERO " + numMin + " ES EL MENOR.");
    }

}
