/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg17;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic herechar operador;
        int num1, num2;
        char operador, continuar;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("INTRODUZCA NÚMERO 1: ");
            num1 = sc.nextInt();

            System.out.println("INTRODUZCA NÚMERO 2: ");
            num2 = sc.nextInt();

            do {

                System.out.println("INTRODUZCA UN CARÁCTER: ");
                sc.nextLine();
                operador = sc.nextLine().charAt(0);

                if (operador != '+' && operador != '-' && operador != '*' && operador != '/') {
                    System.out.println("CARÁCTER INCORRECTO.");
                }

            } while (operador != '+' && operador != '-' && operador != '*' && operador != '/'); // (operador == '+' || operador == '-' || operador == '*' || operador == '/')

            if (operador == '+') {
                System.out.println(num1 + num2);
            } else if (operador == '-') {
                System.out.println(num1 - num2);
            } else if (operador == '*') {
                System.out.println(num1 * num2);
            } else {
                System.out.println(num1 / num2);
            }

            do {

                System.out.println("¿CONTINUAR?");
                continuar = sc.nextLine().charAt(0);

                if (continuar != 'S' && continuar != 's' && continuar != 'N' && continuar != 'n') {
                    System.out.println("CARÁCTER INCORRECTO.");
                }

            } while (continuar != 'S' && continuar != 's' && continuar != 'N' && continuar != 'n');

        } while (continuar != 'N' && continuar != 'n');
    }

}
