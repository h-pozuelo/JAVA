/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion, edad, importe, importeTotal = 0;
        final int tarifaReducida = 16, tarifaNormal = 25;
        char teatro;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("ANOTA OPCIÓN: \n1. COMPRAR ENTRADA. \n2. CERRAR TAQUILLA.");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:

                    System.out.println("ANOTA EDAD: ");
                    edad = sc.nextInt();

                    if (edad < 7 || edad > 65) {
                        importe = tarifaReducida;
                    } else {
                        importe = tarifaNormal;
                    }

                    if (edad >= 18) {

                        System.out.println("¿DESEA VER EL TEATRO?");
                        sc.nextLine();
                        teatro = sc.nextLine().charAt(0);

                        while (teatro != 'S' && teatro != 's' && teatro != 'N' && teatro != 'n') {

                            System.out.println("OPCIÓN INCORRECTA. VUELVA A INTENTARLO.");

                            System.out.println("¿DESEA VER EL TEATRO?");
                            sc.nextLine();
                            teatro = sc.nextLine().charAt(0);

                            if (teatro == 'S' || teatro == 's') {
                                importe += 3;
                            }

                        }

                    }

                    importeTotal = importeTotal + importe;

                    break;
                case 2:
                    System.out.println("TOTAL: " + importeTotal + " €");
                    break;
                default:
                    System.out.println("OPCIÓN INCORRECTA. VUELVA A INTENTARLO.");
            }

        } while (opcion != 2);
    }

}
