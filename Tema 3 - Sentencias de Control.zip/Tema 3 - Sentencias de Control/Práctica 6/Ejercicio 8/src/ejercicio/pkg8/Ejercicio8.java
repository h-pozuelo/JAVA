/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg8;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int dd, mm, aa, suma, numeroSuerte = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA DÍA DE NACIMIENTO: ");
        dd = sc.nextInt();

        System.out.println("INTRODUZCA MES DE NACIMIENTO: ");
        mm = sc.nextInt();

        System.out.println("INTRODUZCA AÑO DE NACIMIENTO: ");
        aa = sc.nextInt();

        System.out.println(dd + "/" + mm + "/" + aa);

        suma = dd + mm + aa;

        System.out.println(dd + "+" + mm + "+" + aa + "=" + suma);

        while (suma != 0) {

            numeroSuerte = numeroSuerte + (suma % 10);

            suma /= 10;

        }

        while (numeroSuerte != 0) {

            suma = suma + (numeroSuerte % 10);

            numeroSuerte /= 10;

        }

        System.out.println("TU NÚMERO DE LA SUERTE ES: " + suma);
    }

}
