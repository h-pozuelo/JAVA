/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeroSala, cantidadEntradas = 0, entradasSala1 = 0, entradasSala2 = 0, cantidadTotal, compraSuperior = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("¿NÚMERO DE SALA?");
        numeroSala = sc.nextInt();

        while (numeroSala != 0) {

            switch (numeroSala) {

                case 1:

                    System.out.println("¿CANTIDAD DE ENTRADAS?");
                    entradasSala1 = entradasSala1 + cantidadEntradas;

                    if (entradasSala1 > 10) {
                        compraSuperior++;
                    }

                    break;

                case 2:

                    System.out.println("¿CANTIDAD DE ENTRADAS?");
                    entradasSala2 = entradasSala2 + cantidadEntradas;

                    if (entradasSala2 > 10) {
                        compraSuperior++;
                    }

                    break;

                default:
                    System.out.println("NÚMERO DE SALA NO VÁLIDO.");

            }
            // ESTO NO ES CORRECTO YA QUE SI SALGO POR EL DEFAULT COGERÁ EL NÚMERO DE ENTRADAS DE LA VUELTA ANTERIOR. 
            /*
            if (entradasSala1 > 10 || entradasSala2 > 10) {
                compraSuperior += 1;
            }
             */
            // ESTO SI ES CORRECTO. 
            /*
            if ((numeroSala==1||numeroSala==2)&&(entradasSala1 > 10 || entradasSala2 > 10)) {
                compraSuperior += 1;
            }
             */
            System.out.println("¿NÚMERO DE SALA?");
            numeroSala = sc.nextInt();

        }

        cantidadTotal = entradasSala1 + entradasSala2;

        System.out.println("CANTIDAD TOTAL DE ENTRADAS: " + cantidadTotal);

        if (entradasSala1 > entradasSala2) {
            System.out.println("LA SALA 1 HA VENDIDO MÁS ENTRADAS QUE LA SALA 2.");
        }

        if (entradasSala1 < entradasSala2) {
            System.out.println("LA SALA 2 HA VENDIDO MÁS ENTRADAS QUE LA SALA 1.");
        }

        if (compraSuperior == 1) {
            System.out.println(compraSuperior + " PERSONA HA COMPRADO MÁS DE 10 ENTRADAS.");
        }

        if (compraSuperior > 1) {
            System.out.println(compraSuperior + " PERSONAS HAN COMPRADO MÁS DE 10 ENTRADAS.");
        }
        /*
        do {

            do {
                System.out.println("¿NÚMERO DE SALA?");
                numeroSala = sc.nextInt();
            } while (numeroSala != 1 && numeroSala != 2 && numeroSala != 0);

            if (numeroSala == 0) {
                break;
            }

            System.out.println("¿CANTIDAD DE ENTRADAS?");
            cantidadEntradas = sc.nextInt();

            if (numeroSala == 1) {
                entradasSala1 += cantidadEntradas;
            } else {
                entradasSala2 += cantidadEntradas;
            }

            if (cantidadEntradas > 10) {
                compraSuperior++;
            }

        } while (numeroSala != '0');

        cantidadTotal = entradasSala1 + entradasSala2;

        System.out.println("CANTIDAD TOTAL DE ENTRADAS: " + cantidadTotal);

        if (entradasSala1 > entradasSala2) {
            System.out.println("LA SALA 1 HA VENDIDO MÁS ENTRADAS QUE LA SALA 2.");
        }

        if (entradasSala1 < entradasSala2) {
            System.out.println("LA SALA 2 HA VENDIDO MÁS ENTRADAS QUE LA SALA 1.");
        }

        if (compraSuperior == 1) {
            System.out.println(compraSuperior + " PERSONA HA COMPRADO MÁS DE 10 ENTRADAS.");
        }

        if (compraSuperior > 1) {
            System.out.println(compraSuperior + " PERSONAS HAN COMPRADO MÁS DE 10 ENTRADAS.");
        }
         */
    }

}
