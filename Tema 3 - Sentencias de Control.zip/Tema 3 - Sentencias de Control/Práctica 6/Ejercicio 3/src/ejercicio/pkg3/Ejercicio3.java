/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int cantidadA = 0, cantidadB = 0, cantidadC = 0;
        double grosorFresa;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            do {

                System.out.println("INTRODUZCA GROSOR DE FRESA: ");
                grosorFresa = sc.nextDouble();

                if (grosorFresa < 1 && grosorFresa != 0) {
                    System.out.println("GROSOR NO VÁLIDO.");
                }

            } while (grosorFresa < 1 && grosorFresa != 0);

            if (grosorFresa >= 1 && grosorFresa < 3) {
                cantidadA += 1;
            }

            if (grosorFresa >= 3 && grosorFresa < 5) {
                cantidadB += 1;
            }

            if (grosorFresa >= 5) {
                cantidadC += 1;
            }

        } while (grosorFresa != 0);

        if (cantidadA == 0) {
            System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA A.");
        } else {
            System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA A: " + cantidadA);
        }

        if (cantidadB == 0) {
            System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA B.");
        } else {
            System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA B: " + cantidadB);
        }

        if (cantidadC == 0) {
            System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA C.");
        } else {
            System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA C: " + cantidadC);
        }

        /*
        int cantidadA = 0, cantidadB = 0, cantidadC = 0;
        char categoriaFresa;
        double grosorFresa = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA CATEGORÍA DE FRESA: ");
        categoriaFresa = sc.nextLine().charAt(0);

        if (categoriaFresa == '0') {

            if (cantidadA == 0) {
                System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA A.");
            } else {
                System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA A: " + cantidadA);
            }

            if (cantidadB == 0) {
                System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA B.");
            } else {
                System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA B: " + cantidadB);
            }

            if (cantidadC == 0) {
                System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA C.");
            } else {
                System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA C: " + cantidadC);
            }

            System.exit(0);

        }

        while (categoriaFresa != 'A' && categoriaFresa != 'a' && categoriaFresa != 'B' && categoriaFresa != 'b' && categoriaFresa != 'C' && categoriaFresa != 'c' && categoriaFresa != '0') {

            System.out.println("CATEGORÍA NO VÁLIDA.");

            System.out.println("INTRODUZCA CATEGORÍA DE FRESA: ");
            categoriaFresa = sc.nextLine().charAt(0);

        }

        System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
        grosorFresa = sc.nextInt();

        if (categoriaFresa == 'A' || categoriaFresa == 'a') {

            cantidadA += 1;

            while (grosorFresa < 1 || grosorFresa > 3) {

                System.out.println("GROSOR NO VÁLIDO.");

                System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
                grosorFresa = sc.nextInt();

            }
        } else if (categoriaFresa == 'B' || categoriaFresa == 'b') {

            cantidadB += 1;

            while (grosorFresa < 3 || grosorFresa > 5) {

                System.out.println("GROSOR NO VÁLIDO.");

                System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
                grosorFresa = sc.nextInt();

            }
        } else {

            cantidadC += 1;

            while (grosorFresa < 5) {

                System.out.println("GROSOR NO VÁLIDO.");

                System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
                grosorFresa = sc.nextInt();

            }
        }

        while (categoriaFresa != '0') {

            System.out.println("INTRODUZCA CATEGORÍA DE FRESA: ");
            sc.nextLine();
            categoriaFresa = sc.nextLine().charAt(0);

            if (categoriaFresa == '0') {

                if (cantidadA == 0) {
                    System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA A.");
                } else {
                    System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA A: " + cantidadA);
                }

                if (cantidadB == 0) {
                    System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA B.");
                } else {
                    System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA B: " + cantidadB);
                }

                if (cantidadC == 0) {
                    System.out.println("NO HA HABIDO FRESAS DE CATEGORÍA C.");
                } else {
                    System.out.println("CANTIDAD DE FRESAS DE CATEGORÍA C: " + cantidadC);
                }

                System.exit(0);

            }

            while (categoriaFresa != 'A' && categoriaFresa != 'a' && categoriaFresa != 'B' && categoriaFresa != 'b' && categoriaFresa != 'C' && categoriaFresa != 'c' && categoriaFresa != '0') {

                System.out.println("CATEGORÍA NO VÁLIDA.");

                System.out.println("INTRODUZCA CATEGORÍA DE FRESA: ");
                categoriaFresa = sc.nextLine().charAt(0);

            }

            System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
            grosorFresa = sc.nextInt();

            if (categoriaFresa == 'A' || categoriaFresa == 'a') {

                cantidadA += 1;

                while (grosorFresa < 1 || grosorFresa > 3) {

                    System.out.println("GROSOR NO VÁLIDO.");

                    System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
                    grosorFresa = sc.nextInt();

                }
            } else if (categoriaFresa == 'B' || categoriaFresa == 'b') {

                cantidadB += 1;

                while (grosorFresa < 3 || grosorFresa > 5) {

                    System.out.println("GROSOR NO VÁLIDO.");

                    System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
                    grosorFresa = sc.nextInt();

                }
            } else {

                cantidadC += 1;

                while (grosorFresa < 5) {

                    System.out.println("GROSOR NO VÁLIDO.");

                    System.out.println("INTRODUZCA EL GROSOR DE FRESA: ");
                    grosorFresa = sc.nextInt();

                }
            }
            
        }
         */
    }

}
