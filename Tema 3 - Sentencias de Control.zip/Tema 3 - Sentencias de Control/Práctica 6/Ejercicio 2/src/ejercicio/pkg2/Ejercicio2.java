/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num, numSuma = 0, ceroCount = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("INTRODUZCA NÚMERO: ");
            num = sc.nextInt();

            numSuma = numSuma + num;

            if (num == 0) {
                ceroCount += 1;
            }

        } while (numSuma <= 100);

        System.out.println("HAN SIDO INTRODUCIDOS " + ceroCount + " CEROS.");
    }

}
