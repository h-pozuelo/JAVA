/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numGrupo, cantidadAdultos, cantidadNiños, entradas = 0, entradasGrupo;
        char tarifaAdultos, tarifaNiños;
        double recaudacion = 0, importeAdultos = 0, importeNiños = 0;
        final double normalAdulto = 3, reducidaAdulto = 2, normalNiño = 2, reducidaNiño = 1.2;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (numGrupo = 0; recaudacion <= 100; numGrupo += 1) {

            System.out.println("INTRODUZCA CANTIDAD DE ADULTOS: ");
            cantidadAdultos = sc.nextInt();

            sc.nextLine();

            do {

                System.out.println("INTRODUZCA TARIFA DE ADULTOS: ");
                tarifaAdultos = sc.nextLine().charAt(0);

                if (tarifaAdultos != 'N' && tarifaAdultos != 'n' && tarifaAdultos != 'R' && tarifaAdultos != 'r') {
                    System.out.println("CARÁCTER NO VÁLIDO.");
                }

            } while (tarifaAdultos != 'N' && tarifaAdultos != 'n' && tarifaAdultos != 'R' && tarifaAdultos != 'r');

            if (tarifaAdultos == 'N' || tarifaAdultos == 'n') {
                importeAdultos = cantidadAdultos * normalAdulto;
            }

            if (tarifaAdultos == 'R' || tarifaAdultos == 'r') {
                importeAdultos = cantidadAdultos * reducidaAdulto;
            }

            System.out.println("INTRODUZCA CANTIDAD DE NIÑOS: ");
            cantidadNiños = sc.nextInt();

            sc.nextLine();

            do {

                System.out.println("INTRODUZCA TARIFA DE NIÑOS: ");
                tarifaNiños = sc.nextLine().charAt(0);

                if (tarifaNiños != 'N' && tarifaNiños != 'n' && tarifaNiños != 'R' && tarifaNiños != 'r') {
                    System.out.println("CARÁCTER NO VÁLIDO.");
                }

            } while (tarifaNiños != 'N' && tarifaNiños != 'n' && tarifaNiños != 'R' && tarifaNiños != 'r');

            if (tarifaNiños == 'N' || tarifaNiños == 'n') {
                importeNiños = cantidadNiños * normalNiño;
            }

            if (tarifaNiños == 'R' || tarifaNiños == 'r') {
                importeNiños = cantidadNiños * reducidaNiño;
            }

            if (numGrupo == 1) {

                entradasGrupo = numGrupo;

                entradas = cantidadAdultos + cantidadNiños;

            }

            if (numGrupo != 1 && entradas < (cantidadAdultos + cantidadNiños)) {

                entradasGrupo = numGrupo;

                entradas = cantidadAdultos + cantidadNiños;

            }

            recaudacion = recaudacion + (importeAdultos + importeNiños);

        }

        System.out.println("EL GRUPO " + numGrupo + " HA COMPRADO " + entradas + " ENTRADAS.");
    }

}
