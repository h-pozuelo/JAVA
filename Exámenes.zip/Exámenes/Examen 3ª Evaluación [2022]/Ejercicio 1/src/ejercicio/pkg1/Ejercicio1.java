/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import bbdd.BD_Proyectos;
import excepciones.ErrorBaseDatos;
import excepciones.ExcepcionLeerFichero;
import excepciones.ExcepcionTareaTerminada;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;
import modelos.Proyecto;
import modelos.Tarea;
import modelos.TareaPorTipo;
import modelos.TareaSimple;
import modelos.TareaUrgente;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static BD_Proyectos bd = new BD_Proyectos("proyectos");
    static DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/LL/yyyy");
    static Scanner sc = new Scanner(System.in);
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {

            Vector<Tarea> tareas = leerFicheroTareas(bd.obtenerNifs(), bd.obtenerTareasBD());

            do {

                System.out.println("\n--------------------------------------------------");

                for (Tarea tarea : tareas) {

                    System.out.println(tarea.toString());

                }

                System.out.println("--------------------------------------------------");

                System.out.println("TOTAL DE TAREAS SIMPLES FINALIZADAS: " + TareaSimple.getTotalFinalizadas());

                System.out.println("TOTAL DE TAREAS URGENTES FINALIZADAS: " + TareaUrgente.getTotalFinalizadas());

                System.out.println("--------------------------------------------------\n");

                opcion = menu();

                switch (opcion) {

                    case 1:

                        sc.nextLine();

                        try {

                            finalizarTarea(tareas);

                        } catch (ExcepcionTareaTerminada e) {

                            System.out.println(e.getMessage());

                        }

                        break;

                    case 2:

                        Collections.sort(tareas, new TareaPorTipo());

                        break;

                    case 3:

                        sc.nextLine();

                        cambiarUrgente(tareas);

                        break;

                }

            } while (opcion != 4);

            bd.importarTareas(tareas);

            String matriz[][] = generarMatriz(bd.obtenerNifs(), bd.obtenerProyectos(), bd.obtenerTareasBD());

            for (int i = 0; i < matriz.length; i += 1) {

                for (int j = 0; j < matriz[0].length; j += 1) {

                    System.out.print(matriz[i][j] + "\t");

                }

                System.out.print("\n");

            }

        } catch (ErrorBaseDatos | ExcepcionLeerFichero | IOException e) {

            System.out.println(e.getMessage());

        }

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. FINALIZAR UNA TAREA "
                    + "\n\t2. ORDENAR TODAS LAS TAREAS POR TIPO "
                    + "\n\t3. CONVERTIR EN URGENTE UNA TAREA NO FINALIZADA "
                    + "\n\t4. CERRAR EL PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 4) {

                System.out.println("LA OPCIÓN INDICADA NO ES VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 4);

        return opcion;

    }

    public static Vector<Tarea> leerFicheroTareas(String nifs[], Vector<Tarea> tareasBD) throws ErrorBaseDatos, ExcepcionLeerFichero, IOException {
        /*
        RETORNA LOS SIGUIENTES VALORES: 
            1. VECTOR<TAREA> 
            2. VECTOR<TAREA> VACÍO 
            3. EXCEPCIÓN 
         */
        Vector<Tarea> tareas = new Vector<Tarea>();

        Path file = Paths.get("tareas.txt");
        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null;

        try {

            reader = Files.newBufferedReader(file, charset);
            String line = null;

            while ((line = reader.readLine()) != null) {

                String datos[] = line.split(",");

                Proyecto proyecto = bd.obtenerProyecto(datos[0]);

                if (proyecto == null) { // VALIDAR QUE EL CÓDIGO DE PROYECTO EXISTA EN LA TABLA PROYECTOS DE LA BASE DE DATOS. 

                    System.out.println("EL PROYECTO CON CÓDIGO [" + datos[0] + "] NO SE ENCUENTRA EN LA BASE DE DATOS. ");
                    continue;

                } else if (proyecto.isCerrado()) { // VALIDAR QUE EL PROYECTO NO SE ENCUENTRE CERRADO EN ESTE MOMENTO. 

                    System.out.println("EL PROYECTO CON CÓDIGO [" + datos[0] + "] SE ENCUENTRA CERRADO EN ESTE MOMENTO. ");
                    continue;

                } else if (!datos[3].matches("[0-9]{1,8}[a-zA-Z]{1}")) { // VALIDAR QUE EL NIF CUMPLE CON EL FORMATO REQUERIDO. 

                    System.out.println("EL NIF DE EMPLEADO [" + datos[3] + "] NO CUMPLE CON EL FORMATO DE NIF REQUERIDO. ");
                    continue;

                }

                boolean encontrado = false;

                for (int i = 0; i < nifs.length; i += 1) {

                    if (nifs[i].equalsIgnoreCase(datos[3])) { // VALIDAR QUE EL NIF EXISTA EN LA TABLA EMPLEADOS DE LA BASE DE DATOS. 

                        encontrado = true;
                        break;

                    }

                }

                if (!encontrado) {

                    System.out.println("EL NIF DE EMPLEADO [" + datos[3] + "] NO SE ENCUENTRA EN LA BASE DE DATOS. ");
                    continue;

                }

                int numero = calcularNumeroTarea(tareasBD, tareas, datos[0]); // CALCULAR EL NÚMERO DE TAREA CORRESPONDIENTE TENIENDO EN CUENTA LAS TAREAS DEL VECTOR Y LAS TAREAS DE LA BASE DE DATOS. 

                if (datos.length == 4) {

                    tareas.add(new TareaSimple(datos[0], numero, datos[1], Integer.parseInt(datos[2]), datos[3]));

                } else {

                    try {

                        LocalDate fechaEntrega = LocalDate.parse(datos[4], formato);

                        if (LocalDate.now().plusWeeks(1).isBefore(fechaEntrega)) { // VALIDAR QUE LA FECHA DE ENTREGA NO SEA POSTERIOR A UNA SEMANA DE LA FECHA ACTUAL. 

                            System.out.println("LA TAREA URGENTE CON FECHA DE ENTREGA [" + datos[4] + "] ES POSTERIOR A UNA SEMANA DE LA FECHA ACTUAL. ");
                            continue;

                        }

                        tareas.add(new TareaUrgente(fechaEntrega, datos[0], numero, datos[1], Integer.parseInt(datos[2]), datos[3]));

                    } catch (DateTimeParseException e) { // VALIDAR QUE LA FECHA DE ENTREGA CUMPLE CON EL FORMATO REQUERIDO. 

                        System.out.println("LA TAREA URGENTE CON FECHA DE ENTREGA [" + datos[4] + "] NO CUMPLE CON EL FORMATO DE FECHA REQUERIDO. ");
                        continue;

                    }

                }

            }

            if (reader != null) {
                reader.close();
            }

            return tareas;

        } catch (IOException e) {

            if (reader != null) {
                reader.close();
            }

            throw new ExcepcionLeerFichero("CONTACTE CON SISTEMAS: NO ES POSIBLE LEER EL FICHERO. ");

        }

    }

    public static int calcularNumeroTarea(Vector<Tarea> tareasBD, Vector<Tarea> tareas, String codproyecto) {
        /*
        RETORNA LOS SIGUIENTES VALORES: 
            1. INT (> 0) 
         */
        int numero = 0;

        for (Tarea tarea : tareas) {

            if (tarea.getCodproyecto().equalsIgnoreCase(codproyecto) && tarea.getNumero() > numero) {

                numero = tarea.getNumero();

            }

        }

        for (Tarea tarea : tareasBD) {

            if (tarea.getCodproyecto().equalsIgnoreCase(codproyecto) && tarea.getNumero() > numero) {

                numero = tarea.getNumero();

            }

        }

        return (numero + 1);

    }

    public static void finalizarTarea(Vector<Tarea> tareas) throws ExcepcionTareaTerminada {
        /*
        RETORNA LOS SIGUIENTES VALORES: 
            1. EXCEPCIÓN 
         */
        System.out.println("INDIQUE EL CÓDIGO DE PROYECTO: ");
        String codproyecto = sc.nextLine();

        System.out.println("INDIQUE EL NÚMERO DE PROYECTO: ");
        int numero = sc.nextInt();

        for (Tarea tarea : tareas) {

            if (tarea.getCodproyecto().equalsIgnoreCase(codproyecto) && tarea.getNumero() == numero) {

                if (tarea.isTerminada()) {

                    throw new ExcepcionTareaTerminada("LA TAREA [" + tarea.getCodproyecto() + "] [" + tarea.getNumero() + "] SE ENCUENTRA TERMINADA EN ESTE MOMENTO. ");

                }

                tarea.setTerminada(true);

                System.out.println("INDIQUE EL NÚMERO DE HORAS QUE HA DURADO LA TAREA: ");
                int horas = sc.nextInt();

                System.out.println("COSTE EXTRA: " + tarea.finalizar(horas) + " € ");

                return;

            }

        }

        System.out.println("EL CÓDIGO (O NÚMERO) DE PROYECTO INDICADO NO SE ENCUENTRA EN EL VECTOR DE TAREAS. ");

    }

    public static void cambiarUrgente(Vector<Tarea> tareas) {

        System.out.println("INDIQUE EL CÓDIGO DE PROYECTO: ");
        String codproyecto = sc.nextLine();

        System.out.println("INDIQUE EL NÚMERO DE PROYECTO: ");
        int numero = sc.nextInt();

        for (Tarea tarea : tareas) {

            if (!(tarea instanceof TareaUrgente) && !tarea.isTerminada() && (tarea.getCodproyecto().equalsIgnoreCase(codproyecto) && tarea.getNumero() == numero)) {

                sc.nextLine();

                try {

                    System.out.println("INDIQUE LA FECHA DE ENTREGA PARA LA TAREA URGENTE: ");
                    LocalDate fechaEntrega = LocalDate.parse(sc.nextLine(), formato);

                    tareas.add(new TareaUrgente(fechaEntrega, tarea.getCodproyecto(), tarea.getNumero(), tarea.getDescripcion(), tarea.getHorasestimadas(), tarea.isTerminada(), tarea.getEmpleado()));

                    tareas.remove(tarea);

                    return;

                } catch (DateTimeParseException e) {

                    System.out.println("LA FECHA DE ENTREGA NO CUMPLE CON EL FORMATO DE FECHA REQUERIDO. ");

                    return;

                }

            }

        }

        System.out.println("SE HA PRODUCIDO UNO DE LOS SIGUIENTES ERRORES: "
                + "\n1. LA TAREA [" + codproyecto.toUpperCase() + "] [" + numero + "] ES UNA TAREA URGENTE. "
                + "\n2. LA TAREA [" + codproyecto.toUpperCase() + "] [" + numero + "] SE ENCUENTRA TERMINADA EN ESTE MOMENTO. "
                + "\n3. EL CÓDIGO (O NÚMERO) DE PROYECTO INDICADO NO SE ENCUENTRA EN EL VECTOR DE TAREAS. ");

    }

    public static String[][] generarMatriz(String nifs[], Vector<Proyecto> proyectos, Vector<Tarea> tareasBD) {

        String matriz[][] = new String[(nifs.length + 1)][(proyectos.size() + 1)]; // DECLARO UNA MATRIZ CON UNA ALTURA DEL TAMAÑO DE LA LISTA "NIFS" [+1] Y CON UNA LONGITUD DEL TAMAÑO DEL VECTOR "PROYECTOS" [+1]. (SI NO PUSIERA EL [+1] NO SE MOSTRARIAN LOS ENCABEZADOS) 

        for (int i = 0; i <= nifs.length; i += 1) { // LA VARIABLE "i" HACE REFERENCIA A CADA UNA DE LAS FILAS. 

            for (int j = 0; j <= proyectos.size(); j += 1) { // LA VARIABLE "j" HACE REFERENCIA A CADA UNA DE LAS COLUMNAS. 

                matriz[i][j] = "[ ]"; // PONEMOS CADA UNA DE LAS CELDAS DE LA MATRIZ VACÍAS. 

                if (i == 0 && j == 0) {

                    matriz[i][j] = "";

                } else if (i == 0 && j != 0) { // PONEMOS EL CÓDIGO DE PROYECTO EN CADA UNA DE LAS CELDAS DE LA PRIMERA FILA. (EXCLUIMOS LA PRIMERA CELDA QUE ESTÁ EN BLANCO) 

                    matriz[i][j] = proyectos.get(j - 1).getCodigo(); // AL DECLARAR LA MATRIZ CON UNA LONGITUD DEL TAMAÑO DEL VECTOR "PROYECTOS" [+1] ES NECESARIO INDICAR (j - 1) AL MOMENTO DE OBTENER EL CÓDIGO DE PROYECTO CORRESPONDIENTE. 

                } else if (i != 0 && j == 0) { // PONEMOS EL NIF DE EMPLEADO EN CADA UNA DE LAS CELDAS DE LA PRIMERA COLUMNA. (EXCLUIMOS LA PRIMERA CELDA QUE ESTÁ EN BLANCO) 

                    matriz[i][j] = nifs[i - 1]; // AL DECLARAR LA MATRIZ CON UNA ALTURA DEL TAMAÑO DE LA LISTA "NIFS" [+1] ES NECESARIO INDICAR (i - 1) AL MOMENTO DE OBTENER EL NIF DE EMPLEADO CORRESPONDIENTE. 

                } else {

                    for (int k = 0; k < tareasBD.size(); k += 1) {

                        String codproyecto = tareasBD.get(k).getCodproyecto();

                        String empleado = tareasBD.get(k).getEmpleado();

                        boolean isTerminada = tareasBD.get(k).isTerminada();

                        if ((codproyecto.equalsIgnoreCase(matriz[0][j]) && empleado.equalsIgnoreCase(matriz[i][0])) && !isTerminada) {

                            matriz[i][j] = "[X]";

                            break;

                        }

                    }

                }

            }

        }

        return matriz;

    }

}
