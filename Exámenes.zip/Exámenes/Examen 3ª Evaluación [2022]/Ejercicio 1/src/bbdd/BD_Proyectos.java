/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

import excepciones.ErrorBaseDatos;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import modelos.Proyecto;
import modelos.Tarea;
import modelos.TareaSimple;
import modelos.TareaUrgente;

/**
 *
 * @author Hugo
 */
public class BD_Proyectos extends BD_Conector {

    private static Statement s;
    private static ResultSet reg;
    private static PreparedStatement ps;

    public BD_Proyectos(String bbdd) {
        super(bbdd);
    }

    public String[] obtenerNifs() throws ErrorBaseDatos {

        String nifs[] = null;
        String cadenaSQL = "SELECT COUNT(nif) FROM empleados";

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                nifs = new String[reg.getInt(1)];
                cadenaSQL = "SELECT nif FROM empleados";
                reg = s.executeQuery(cadenaSQL);
                for (int i = 0; reg.next(); i += 1) {
                    nifs[i] = reg.getString("nif");
                }
            }
            s.close();
            this.cerrar();

            return nifs;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("CONTACTE CON SISTEMAS: NO ES POSIBLE OBTENER LOS NIFS DE LOS EMPLEADOS. ");

        }

    }

    public Proyecto obtenerProyecto(String codigo) throws ErrorBaseDatos {

        Proyecto proyecto = null;
        String cadenaSQL = "SELECT * FROM proyectos WHERE codigo = '" + codigo + "'";

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                proyecto = new Proyecto(reg.getString("codigo"), reg.getString("Nombre"), reg.getBoolean("cerrado"));
            }
            s.close();
            this.cerrar();

            return proyecto;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("CONTACTE CON SISTEMAS: NO ES POSIBLE OBTENER EL PROYECTO. ");

        }

    }

    public Vector<Tarea> obtenerTareasBD() throws ErrorBaseDatos {

        Vector<Tarea> tareasBD = new Vector<Tarea>();
        String cadenaSQL = "SELECT * FROM tareas";

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                if (reg.getDate(5) == null) {
                    tareasBD.add(new TareaSimple(reg.getString(1), reg.getInt(2), reg.getString(3), reg.getInt(4), reg.getBoolean(6), reg.getString(7)));
                } else {
                    tareasBD.add(new TareaUrgente(reg.getDate(5).toLocalDate(), reg.getString(1), reg.getInt(2), reg.getString(3), reg.getInt(4), reg.getBoolean(6), reg.getString(7)));
                }
            }
            s.close();
            this.cerrar();

            return tareasBD;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("CONTACTE CON SISTEMAS: NO ES POSIBLE OBTENER LAS TAREAS. ");

        }

    }

    public int importarTareas(Vector<Tarea> tareas) throws ErrorBaseDatos {

        int filas = 0;
        String cadenaSQL = "INSERT INTO tareas VALUES(?, ?, ?, ?, ?, ?, ?)";

        try {

            this.abrir();
            ps = c.prepareStatement(cadenaSQL);
            for (Tarea tarea : tareas) {

                ps.setString(1, tarea.getCodproyecto());

                ps.setInt(2, tarea.getNumero());

                ps.setString(3, tarea.getDescripcion());

                ps.setInt(4, tarea.getHorasestimadas());

                if (tarea instanceof TareaUrgente tareaUrgente) {

                    ps.setDate(5, java.sql.Date.valueOf(tareaUrgente.getFechaEntrega()));

                } else {

                    ps.setDate(5, null);

                }

                ps.setBoolean(6, tarea.isTerminada());

                ps.setString(7, tarea.getEmpleado());

                filas += ps.executeUpdate();

            }
            ps.close();
            this.cerrar();

            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("CONTACTE CON SISTEMAS: NO ES POSIBLE IMPORTAR LAS TAREAS. ");

        }

    }

    public Vector<Proyecto> obtenerProyectos() throws ErrorBaseDatos {

        Vector<Proyecto> proyectos = new Vector<Proyecto>();
        String cadenaSQL = "SELECT * FROM proyectos";

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                proyectos.add(new Proyecto(reg.getString("codigo"), reg.getString("Nombre"), reg.getBoolean("cerrado")));
            }
            s.close();
            this.cerrar();

            return proyectos;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("CONTACTE CON SISTEMAS: NO ES POSIBLE OBTENER LOS PROYECTOS. ");

        }

    }

}
