/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Hugo
 */
public class TareaUrgente extends Tarea {

    private LocalDate fechaEntrega;
    private static int totalFinalizadas;

    public TareaUrgente(LocalDate fechaEntrega, String codproyecto, int numero, String descripcion, int horasestimadas, boolean terminada, String empleado) {
        super(codproyecto, numero, descripcion, horasestimadas, terminada, empleado);
        this.fechaEntrega = fechaEntrega;
    }

    public TareaUrgente(LocalDate fechaEntrega, String codproyecto, int numero, String descripcion, int horasestimadas, String empleado) {
        super(codproyecto, numero, descripcion, horasestimadas, empleado);
        this.fechaEntrega = fechaEntrega;
    }

    public LocalDate getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(LocalDate fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public static int getTotalFinalizadas() {
        return totalFinalizadas;
    }

    public static void setTotalFinalizadas(int totalFinalizadas) {
        TareaUrgente.totalFinalizadas = totalFinalizadas;
    }

    @Override
    public String toString() {
        return super.toString() + ", fechaEntrega=" + fechaEntrega + '}';
    }

    public double finalizar(int horas) {

        this.totalFinalizadas += 1;

        double extra = 0;

        horas -= horasestimadas;

        if (horas > 0) {

            extra = extra + (horas * 50);

        }

        int diasRetraso = (int) ChronoUnit.DAYS.between(this.fechaEntrega, LocalDate.now());

        if (diasRetraso > 0) {

            return extra + (diasRetraso * 100);

        }

        return extra;

    }

}
