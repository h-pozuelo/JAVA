/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.util.Comparator;

/**
 *
 * @author Hugo
 */
public class TareaPorTipo implements Comparator<Tarea> {

    @Override
    public int compare(Tarea arg0, Tarea arg1) { // COMPARA LA TAREA CON POSICIÓN [ X ] CON LA TAREA CON POSICIÓN [ X + 1 ]. 
        /*
        RETORNA LOS SIGUIENTES VALORES: 
            1. -1 [SE POSICIONA ENCIMA] 
            2. 0 [MANTIENE SU POSICIÓN] 
            3. 1 [SE POSICIONA DEBAJO] 
         */
        if (arg0.getClass().getSimpleName().equalsIgnoreCase(arg1.getClass().getSimpleName())) { // ¿ES EL TIPO DE LA TAREA [ X ] IGUAL AL TIPO DE LA TAREA [ X + 1 ]? 

            if (arg0.getHorasestimadas() == arg1.getHorasestimadas()) { // ¿SON LAS HORAS ESTIMADAS DE LA TAREA [ X ] IGUALES A LAS HORAS ESTIMADAS DE LA TAREA [ X + 1 ]? 

                return 0;

            } else if (arg0.getHorasestimadas() > arg1.getHorasestimadas()) { // ¿SON LAS HORAS ESTIMADAS DE LA TAREA [ X ] MAYORES A LAS HORAS ESTIMADAS DE LA TAREA [ X + 1 ]? 

                return -1;

            } else { // LAS HORAS ESTIMADAS DE LA TAREA [ X ] SON MENORES A LAS HORAS ESTIMADAS DE LA TAREA [ X + 1 ]. 

                return 1;

            }

        } else if (arg0 instanceof TareaUrgente) { // ¿ES DE TIPO URGENTE EL TIPO DE LA TAREA [ X ]? 

            return -1;

        } else { // EL TIPO DE LA TAREA [ X ] ES DE TIPO SIMPLE. 

            return 1;

        }

    }

}
