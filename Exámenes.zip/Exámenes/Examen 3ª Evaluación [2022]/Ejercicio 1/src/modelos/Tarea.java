/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Hugo
 */
public abstract class Tarea {

    private String codproyecto;
    private int numero;
    private String descripcion;
    protected int horasestimadas;
    private boolean terminada;
    private String empleado;

    public Tarea(String codproyecto, int numero, String descripcion, int horasestimadas, boolean terminada, String empleado) {
        this.codproyecto = codproyecto;
        this.numero = numero;
        this.descripcion = descripcion;
        this.horasestimadas = horasestimadas;
        this.terminada = terminada;
        this.empleado = empleado;
    }

    public Tarea(String codproyecto, int numero, String descripcion, int horasestimadas, String empleado) {
        this.codproyecto = codproyecto;
        this.numero = numero;
        this.descripcion = descripcion;
        this.horasestimadas = horasestimadas;
        this.terminada = false;
        this.empleado = empleado;
    }

    public String getCodproyecto() {
        return codproyecto;
    }

    public void setCodproyecto(String codproyecto) {
        this.codproyecto = codproyecto;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getHorasestimadas() {
        return horasestimadas;
    }

    public void setHorasestimadas(int horasestimadas) {
        this.horasestimadas = horasestimadas;
    }

    public boolean isTerminada() {
        return terminada;
    }

    public void setTerminada(boolean terminada) {
        this.terminada = terminada;
    }

    public String getEmpleado() {
        return empleado;
    }

    public void setEmpleado(String empleado) {
        this.empleado = empleado;
    }

    @Override
    public String toString() {
        return "Tarea{" + "codproyecto=" + codproyecto + ", numero=" + numero + ", descripcion=" + descripcion + ", horasestimadas=" + horasestimadas + ", terminada=" + terminada + ", empleado=" + empleado;
    }

    public abstract double finalizar(int horas);

}
