/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Hugo
 */
public class TareaSimple extends Tarea {

    private static int totalFinalizadas;

    public TareaSimple(String codproyecto, int numero, String descripcion, int horasestimadas, boolean terminada, String empleado) {
        super(codproyecto, numero, descripcion, horasestimadas, terminada, empleado);
    }

    public TareaSimple(String codproyecto, int numero, String descripcion, int horasestimadas, String empleado) {
        super(codproyecto, numero, descripcion, horasestimadas, empleado);
    }

    public static int getTotalFinalizadas() {
        return totalFinalizadas;
    }

    public static void setTotalFinalizadas(int totalFinalizadas) {
        TareaSimple.totalFinalizadas = totalFinalizadas;
    }

    @Override
    public String toString() {
        return super.toString() + '}';
    }

    public double finalizar(int horas) {

        this.totalFinalizadas += 1;

        if (horas - this.horasestimadas <= 0) {

            return 0;

        }

        return (horas - this.horasestimadas) * 50;

    }

}
