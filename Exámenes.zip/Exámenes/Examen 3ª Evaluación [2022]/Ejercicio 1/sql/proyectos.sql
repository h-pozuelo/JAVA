-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 25-05-2022 a las 00:32:03
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyectos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--

CREATE TABLE `empleados` (
  `nif` varchar(9) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`nif`, `nombre`, `apellidos`) VALUES
('11111H', 'Andrés', 'Segovia'),
('12121212J', 'Luisa', 'Muñoz'),
('23T', 'Lourdes', 'Rovira'),
('432345M', 'Julia', 'Lorenzo'),
('51673266V', 'Juan', 'Sanz');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE `proyectos` (
  `codigo` varchar(5) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `cerrado` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`codigo`, `Nombre`, `cerrado`) VALUES
('CR12', 'Comida rápida', 0),
('FU11', 'Fonicular', 0),
('PP345', 'Parking público', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tareas`
--

CREATE TABLE `tareas` (
  `codproyecto` varchar(5) NOT NULL,
  `número` int(11) NOT NULL,
  `descripción` varchar(20) NOT NULL,
  `horasestimadas` int(11) NOT NULL,
  `fechaEntrega` date DEFAULT NULL,
  `terminada` int(11) NOT NULL,
  `empleado` varchar(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tareas`
--

INSERT INTO `tareas` (`codproyecto`, `número`, `descripción`, `horasestimadas`, `fechaEntrega`, `terminada`, `empleado`) VALUES
('CR12', 1, 'casos de uso', 15, '2022-05-16', 0, '23T'),
('CR12', 2, 'pruebas', 4, NULL, 0, '51673266V'),
('CR12', 3, 'Requisitos funcional', 12, '2022-05-26', 1, '11111H'),
('PP345', 1, 'diseño datos', 20, '2022-05-29', 1, '23T'),
('PP345', 2, 'diagrama clases', 10, '2022-05-30', 1, '432345M'),
('PP345', 3, 'Codificación clases', 30, NULL, 0, '51673266V');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`nif`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`codigo`);

--
-- Indices de la tabla `tareas`
--
ALTER TABLE `tareas`
  ADD PRIMARY KEY (`codproyecto`,`número`),
  ADD KEY `empleado` (`empleado`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tareas`
--
ALTER TABLE `tareas`
  ADD CONSTRAINT `tareas_ibfk_1` FOREIGN KEY (`codproyecto`) REFERENCES `proyectos` (`codigo`),
  ADD CONSTRAINT `tareas_ibfk_2` FOREIGN KEY (`empleado`) REFERENCES `empleados` (`nif`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
