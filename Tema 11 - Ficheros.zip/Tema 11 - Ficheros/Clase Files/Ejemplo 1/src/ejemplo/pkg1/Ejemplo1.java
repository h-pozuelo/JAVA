/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*; // NECESARIO PARA REPLACE_EXISTING 

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        DEBEMOS VALIDAR QUE EL FICHERO EXISTE 
         */
        Path p1 = Paths.get("C:/Users/Hugo/Downloads/EjemploBorrar.txt");

        if (!Files.exists(p1)) {

            System.out.println("ERROR RUTA");

        }
        /*
        INTENTAMOS BORRAR EL FICHERO O DIRECTORIO 
         */
        try {

            Files.delete(p1);

        } catch (NoSuchFileException x) {

            System.err.format("%s: NO EXISTE EL FICHERO O DIRECTORIO. \n", p1);

        } catch (DirectoryNotEmptyException x) {

            System.err.format("%s: NO ESTÁ VACÍO. \n", p1);

        } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

            System.err.format("%s: ERROR DE PERMISOS. \n", p1);

        }
        /*
        BORRA EL FICHERO PERO EN CASO DE NO EXISTIR NO LANZA UNA EXCEPCIÓN 
        SI TENEMOS VARIOS PROCESOS (HILOS) BORRANDO FICHEROS NO DEBEMOS LANZAR UNA EXCEPCIÓN PORQUE OTRO HILO YA LO BORRÓ 
         */
        try {

            Files.deleteIfExists(p1);

        } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

            System.err.format("%s: ERROR DE PERMISOS. \n", p1);

        }
        /*
        COPIA EL FICHERO "ORIGEN.TXT" EN LA RUTA ABSOLUTA ESPECIFICADA CON NOMBRE "DESTINO.TXT"
        SI EL FICHERO YA EXISTE LANZA LA EXCEPCIÓN FileAlreadyExists 
        SI QUEREMOS QUE REALICE LA COPIA AUNQUE EXISTA DEBEMOS USAR Files.copy(p6, p5, REPLACE_EXISTING); 
         */
        Path p5 = Paths.get("C:/Users/Hugo/Downloads/Destino.txt");

        Path p6 = Paths.get("C:/Users/Hugo/Downloads/Origen.txt");

        try {

            Files.copy(p6, p5);

        } catch (NoSuchFileException x) {

            System.err.format("%s: NO EXISTE. \n", x.getMessage());

        } catch (FileAlreadyExistsException x) {

            System.err.format("%s: YA EXISTE. \n", x.getMessage());

        } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

            System.err.format("%s: ERROR DE PERMISOS. \n", p1);

        }
        /*
        MOVER UN FICHERO O UNA CARPETA A UN DIRECTORIO DIFERENTE 
         */
        Path p7 = Paths.get("C:/Users/Hugo/Downloads/Origen/Origen.txt");

        Path p8 = Paths.get("C:/Users/Hugo/Downloads/Origen.txt");

        try {

            Files.move(p8, p7, REPLACE_EXISTING);

        } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

            System.err.format("%s: ERROR DE PERMISOS. \n", p1);

        }
        /*
        MOSTRAR TODO EL CONTENIDO DE UN DIRECTORIO 
         */
        if (Files.isDirectory(Paths.get("../../.."))) { // PONIENDO UNICAMENTE "." LISTA EL CONTENIDO DE LA CARPETA DE TRABAJO DEL PROYECTO 

            try {

                DirectoryStream<Path> stream = Files.newDirectoryStream(Paths.get("../../..")); // PONIENDO UNICAMENTE "." LISTA EL CONTENIDO DE LA CARPETA DE TRABAJO DEL PROYECTO 

                for (Path path : stream) {

                    System.out.println(path.getFileName());

                }

            } catch (IOException e) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

                System.err.format("%s: ERROR DE PERMISOS. \n", p1);

            }

        }

    }

}
