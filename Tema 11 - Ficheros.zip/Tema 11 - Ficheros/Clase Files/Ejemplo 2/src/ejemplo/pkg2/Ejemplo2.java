/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg2;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*; // NECESARIO PARA REPLACE_EXISTING 

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    static Scanner sc = new Scanner(System.in);
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    informacionFichero();

                    break;

                case 2:

                    borrarFichero();

                    break;

                case 3:

                    contenidoDirectorio();

                    break;

            }

        } while (opcion != 4);

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. MOSTRAR LA INFORMACIÓN DE UN FICHERO "
                    + "\n\t2. BORRAR UN FICHERO "
                    + "\n\t3. LISTAR EL CONTENIDO DE UN DIRECTORIO "
                    + "\n\t4. FINALIZAR EJECUCIÓN ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 4) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 4);

        return opcion;

    }

    public static void informacionFichero() {

        sc.nextLine();

        System.out.println("INTRODUZCA UNA RUTA: ");
        String ruta = sc.nextLine();

        System.out.println("INTRODUZCA NOMBRE DE UN FICHERO: ");
        String fichero = sc.nextLine();

        Path ruta1 = Paths.get(ruta + "/" + fichero);

        System.out.println(ruta1.toString());

        infoPath(ruta1);

    }

    // MÉTODOS DE LA CLASE PATH 
    public static void infoPath(Path p) {

        if (Files.isDirectory(p)) {

            System.out.println("Files.isDirectory(Path): ES UN DIRECTORIO. ");

        }

        if (Files.isRegularFile(p)) {

            System.out.println("Files.isRegularFile(Path): ES UN FICHERO. ");

        }

        System.out.println("path.toString(): " + p.toString());

        System.out.println("path.getFileName(): " + p.getFileName());

        System.out.println("path.getName(0): " + p.getName(0));

        System.out.println("path.getNameCount(): " + p.getNameCount());

        System.out.println("path.subpath(0, 2): " + p.subpath(0, 2));

        System.out.println("path.getParent(): " + p.getParent());

        System.out.println("path.getRoot(): " + p.getRoot());

        System.out.println("path.toAbsolutePath(): " + p.toAbsolutePath());

        try {

            System.out.println("path.toRealPath(): " + p.toRealPath());

        } catch (IOException e) {

            System.out.println("ERROR NO EXISTE EL FICHERO. ");

        }

    }

    public static void borrarFichero() {

        sc.nextLine();

        System.out.println("INTRODUZCA UNA RUTA: ");
        String ruta = sc.nextLine();

        System.out.println("INTRODUZCA NOMBRE DE UN FICHERO: ");
        String fichero = sc.nextLine();

        Path ruta2 = Paths.get(ruta + "/" + fichero);

        if (!Files.exists(ruta2)) {

            System.err.format("LA RUTA INDICADA NO EXISTE. ");

        } else {

            if (!Files.isRegularFile(ruta2)) {

                System.err.format("NO HAS INDICADO UN FICHERO. ");

            } else {

                try {

                    Files.delete(ruta2);

                    System.out.println("FICHERO ELIMINADO CON ÉXITO. ");

                } catch (NoSuchFileException x) { // NO VA A ENTRAR NUNCA POR AQUÍ DADO QUE YA HE VALIDADO QUE SEA UN FICHERO MÁS ARRIBA 

                    System.err.format("%s: EL FICHERO NO EXISTE. \n", ruta2);

                } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

                    System.err.format("%s: ERROR DE PERMISOS. \n", ruta2);

                }

            }

        }

    }

    public static void contenidoDirectorio() {

        sc.nextLine();

        System.out.println("INTRODUZCA UNA RUTA: ");
        String ruta = sc.nextLine();

        Path ruta3 = Paths.get(ruta);

        if (!Files.isDirectory(ruta3)) {

            System.err.format("NO HAS INDICADO UN DIRECTORIO O EL DIRECTORIO NO EXISTE. ");

            try {

                Files.createDirectory(ruta3);

                System.out.println("DIRECTORIO CREADO CON ÉXITO. ");

            } catch (IOException x) {

                System.err.format("NO TIENES PERMISOS SUFICIENTES PARA CREAR EL DIRECTORIO. \n");

            }

        } else {

            listarContenido(ruta3);

        }

    }

    public static void listarContenido(Path ruta3) {

        try {

            DirectoryStream<Path> stream = Files.newDirectoryStream(ruta3);

            for (Path path : stream) {

                System.out.println(path.getFileName());

                if (Files.isDirectory(path)) {

                    listarContenido(path);

                }

            }

        } catch (IOException e) { // POSIBLES PROBLEMAS CON LOS PERMISOS

            System.err.format("%s: ERROR DE PERMISOS. \n", ruta3);

        }

    }

}
