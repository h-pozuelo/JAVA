/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Path file = Paths.get("entrada.txt");
        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 

        try {

            reader = Files.newBufferedReader(file, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                System.out.println(line);

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

    }

}
