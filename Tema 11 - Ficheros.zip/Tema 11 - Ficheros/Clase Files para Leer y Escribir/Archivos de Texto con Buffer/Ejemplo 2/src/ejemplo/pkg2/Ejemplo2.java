/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg2;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.nio.file.OpenOption;
import static java.nio.file.StandardOpenOption.*; // PAQUETE IMPRESCINDIBLE PARA HACER USO DE LAS OpenOptions [WRITE] [APPEND] [TRUNCATE_EXISTING] [CREATE_NEW] [CREATE] [DELETE_ON_CLOSE] 

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String linea;
        Scanner sc = new Scanner(System.in);
        Path file = Paths.get("salida.txt"); // UBICACIÓN DEL FICHERO A ESCRIBIR 
        Charset charset = Charset.forName("UTF-8"); // CODIFICACIÓN DEL FICHERO 
        /*
        CREAMOS UN BufferedWriter DE java.nio DE FORMA EFICIENTE UTILIZANDO Files DE java.nio 
         */
        try {
            /*
            CREA EL FICHERO SI NO EXISTE (SI EXISTE BORRA EL CONTENIDO DEL FICHERO) 
            BufferedWriter writer = Files.newBufferedWriter(file, charset);
             */
            BufferedWriter writer = Files.newBufferedWriter(file, charset, APPEND); // [APPEND] PERMITE AÑADIR DATOS AL FINAL DEL FICHERO (SIN SOBREESCRIBIR LO ANTERIOR) 

            do {

                System.out.println("INTRODUZCA LÍNEA: (FIN PARA SALIR) ");
                linea = sc.nextLine();

                if (!linea.equalsIgnoreCase("FIN")) {

                    writer.write(linea); // VA ESCRIBIENDO SOBRE EL FICHERO LÍNEA A LÍNEA HASTA ANOTAR "FIN" 
                    writer.newLine(); // SALTO DE LÍNEA PARA CUANDO PRESIONAMOS LA TECLA [ENTER] 

                }

            } while (!linea.equalsIgnoreCase("FIN"));

            writer.close();

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        }

    }

}
