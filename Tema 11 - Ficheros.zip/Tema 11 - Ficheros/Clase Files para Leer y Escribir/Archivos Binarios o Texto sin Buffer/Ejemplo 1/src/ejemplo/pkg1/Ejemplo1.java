/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Path entrada = Paths.get("osos.jpg");
        Path salida = Paths.get("osos2.jpg");
        /*
        ARRAY DE BYTES PARA I/O (LEER/ESCRIBIR) TODOS LOS BYTES DEL FICHERO 
         */
        InputStream istream = null; // SE DECLARA EL OBJETO 
        OutputStream ostream = null; // SE DECLARA EL OBJETO 
        int c; // VARIABLE EN LA QUE SE IRÁ ALMACENANDO (EN CADA VUELTA DEL BUCLE) CADA UNO DE LOS BYTES QUE CONTIENE EL FICHERO DE ENTRADA 

        try {
            /*
            InputStream Y OutputStream (PERTENECIENTE A java.nio) PERMITE TRABAJAR BYTE A BYTE SOBRE EL FICHERO 
            LOS GENERAMOS DE FORMA EFICIENTE UTILIZANDO java.nio 
             */
            istream = Files.newInputStream(entrada); // SE CREA EL OBJETO 
            ostream = Files.newOutputStream(salida); // SE CREA EL OBJETO 

            while ((c = istream.read()) != -1) { // CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
                /*
                ESCRIBIMOS TODOS LOS BYTES EN EL FICHERO DE SALIDA 
                DESPUES DE EJECUTAR SE COMPRUEBA QUE ES IGUAL A LA ENTRADA 
                 */
                ostream.write(c); // LA FUNCIÓN write(c) VUELCA (EN CADA VUELTA DEL BUCLE) EL CONTENIDO DE LA VARIABLE c EN EL FICHERO DE SALIDA 

            }

            istream.close(); // SE CIERRA EL OBJETO 
            ostream.close(); // SE CIERRA EL OBJETO (SI NO SE CIERRA EL OBJETO PODRÍAN QUEDAR BYTES SUELTOS EN EL FICHERO DE SALIDA) 

        } catch (IOException io) {

            System.err.println(io);

        }

    }

}
