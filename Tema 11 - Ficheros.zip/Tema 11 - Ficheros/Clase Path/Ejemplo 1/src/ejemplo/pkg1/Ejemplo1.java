/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.nio.file.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        CREAR UN PATH A PARTIR DE UNA CADENA, USAMOS LA BARRA /  o \\ 
         */
        Path ruta1 = Paths.get("C:\\Users\\Hugo\\Downloads");
        // Path ruta1=Paths.get("C:/Users/Hugo/Downloads");

        infoPath(ruta1);

        Path ruta2 = Paths.get("E:\\Users\\Hugo\\Documents\\Programación\\Tema 11 - Ficheros\\Clase Path\\Ejemplo 1\\src\\ejemplo\\pkg1\\Ejemplo1.java");

        infoPath(ruta2);
        /*
        CÓMO OBTENER UN PATH A PARTIR DE DATOS ANOTADOS DE TECLADO
         */
        System.out.println("INTRODUZCA UNA RUTA: ");
        String ruta = sc.nextLine();

        System.out.println("INTRODUZCA NOMBRE DE UN FICHERO: ");
        String archivo = sc.nextLine();

        Path ruta3 = Paths.get(ruta + "/" + archivo);

        System.out.println(ruta3.toString());

        infoPath(ruta3);

    }

    // MÉTODOS DE LA CLASE PATH 
    public static void infoPath(Path p) {

        System.out.println("-----------" + p.toString());

        System.out.println("getFileName:" + p.getFileName());

        System.out.println("getName(0):" + p.getName(0));

        System.out.println("getNameCount:" + p.getNameCount());

        System.out.println("subpath(0,2):" + p.subpath(0, 2));

        System.out.println("getParent:" + p.getParent());

        System.out.println("getRoot:" + p.getRoot());

        System.out.println("Path absoluto:" + p.toAbsolutePath());

        try {

            System.out.println("realPath:" + p.toRealPath());

        } catch (IOException e) {

            System.out.println("Error no existe el fichero");

        }

    }

}
