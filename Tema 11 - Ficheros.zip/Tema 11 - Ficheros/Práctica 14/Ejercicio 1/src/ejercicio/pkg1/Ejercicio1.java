/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*; // NECESARIO PARA REPLACE_EXISTING 

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        buscarFichero(leerFichero());

    }

    public static Path leerFichero() {

        Scanner sc = new Scanner(System.in);

        System.out.println("INDIQUE DIRECTORIO EN EL QUE SE ENCUENTRA EL FICHERO: ");
        String directorio = sc.nextLine();

        System.out.println("INDIQUE EL NOMBRE DEL FICHERO: ");
        String fichero = sc.nextLine();

        return Paths.get(directorio + "/" + fichero);

    }

    public static void buscarFichero(Path ruta) {

        if (!Files.isRegularFile(ruta)) {

            System.err.format("[%s] EL FICHERO INDICADO NO EXISTE. \n", ruta);

        } else {

            try {

                mostrarRuta(ruta.toRealPath());

            } catch (IOException e) {

                System.err.format("[%s] EL FICHERO INDICADO NO EXISTE. \n", ruta);

            }

        }

    }

    public static void mostrarRuta(Path ruta) {

        System.out.println(ruta.getRoot());

        try {

            for (int i = 0;; i += 1) {

                System.out.println(ruta.subpath(i, i + 1));

            }

        } catch (IllegalArgumentException e) {

            System.out.println("FIN DEL PROGRAMA. ");

        }

    }

}
