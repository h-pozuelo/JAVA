/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg12;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        System.out.println("INTRODUZCA UNA PALABRA: ");
        String palabra = sc.nextLine();

        comprobarLinea(buscarFichero(), palabra);

    }

    public static Path buscarFichero() {

        Path ruta = null;
        Scanner sc = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA LA RUTA REAL DEL FICHERO CORRESPONDIENTE: ");
            String fichero = sc.nextLine();

            try {

                ruta = Paths.get(fichero).toRealPath();

                if (!Files.isRegularFile(ruta)) {

                    System.err.println("LA RUTA INTRODUCIDA NO CORRESPONDE A NINGÚN FICHERO. ");

                } else {

                    quit = true;

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INTRODUCIDA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static void comprobarLinea(Path ruta, String palabra) throws IOException {

        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 
        String palabras[];

        try {

            reader = Files.newBufferedReader(ruta, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                palabras = line.split(" ");

                for (int i = 0; i < palabras.length; i += 1) {

                    if (palabras[i].equalsIgnoreCase(palabra)) {

                        escribirLinea(ruta, line);

                        break;

                    }

                }

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

    }

    public static void escribirLinea(Path ruta, String linea) {

        Path file = Paths.get(ruta.getParent() + "/salida.txt"); // UBICACIÓN DEL FICHERO A ESCRIBIR 
        Charset charset = Charset.forName("UTF-8"); // CODIFICACIÓN DEL FICHERO 
        /*
        FUNCIÓN PARA CREAR UN FICHERO VACÍO A PARTIR DE UNA UBICACIÓN ESPECIFICADA 
         */
        try {

            File fichero = new File(file.toString());
            fichero.createNewFile();

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        }
        /*
        CREAMOS UN BufferedWriter DE java.nio DE FORMA EFICIENTE UTILIZANDO Files DE java.nio 
         */
        try {
            /*
            CREA EL FICHERO SI NO EXISTE (SI EXISTE BORRA EL CONTENIDO DEL FICHERO) 
            BufferedWriter writer = Files.newBufferedWriter(file, charset);
             */
            BufferedWriter writer = Files.newBufferedWriter(file, charset, APPEND); // [APPEND] PERMITE AÑADIR DATOS AL FINAL DEL FICHERO (SIN SOBREESCRIBIR LO ANTERIOR) 

            writer.write(linea); // VA ESCRIBIENDO SOBRE EL FICHERO LÍNEA A LÍNEA HASTA ANOTAR "FIN" 
            writer.newLine(); // SALTO DE LÍNEA PARA CUANDO PRESIONAMOS LA TECLA [ENTER] 

            writer.close();

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        }

    }

}
