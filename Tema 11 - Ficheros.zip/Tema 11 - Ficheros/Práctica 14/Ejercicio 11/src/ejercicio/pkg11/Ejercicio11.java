/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg11;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejercicio11 {

    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    encrypt(buscarFichero());

                    break;

                case 2:

                    decrypt(buscarFichero(), buscarFichero());

                    break;

            }

        } while (opcion != 3);

    }

    public static int menu() {

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. ENCRIPTAR UN FICHERO DE TEXTO "
                    + "\n\t2. DESENCRIPTAR UN FICHERO DE TEXTO "
                    + "\n\t3. FINALIZAR PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 3) {

                System.err.println("LA OPCIÓN INDICADA NO ES VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 3);

        return opcion;

    }

    public static Path buscarFichero() {

        Path ruta = null;
        Scanner sc = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA LA RUTA REAL DEL FICHERO CORRESPONDIENTE: ");
            String fichero = sc.nextLine();

            try {

                ruta = Paths.get(fichero).toRealPath();

                if (Files.isRegularFile(ruta)) {

                    quit = true;

                } else {

                    System.err.println("LA RUTA INTRODUCIDA NO CORRESPONDE A NINGÚN FICHERO. ");

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INTRODUCIDA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static void encrypt(Path decrypted) {

        Path encrypted1 = Paths.get(decrypted.getParent() + "/encrypted1.txt");
        Path encrypted2 = Paths.get(decrypted.getParent() + "/encrypted2.txt");

        InputStream istream = null;
        OutputStream ostream1 = null;
        OutputStream ostream2 = null;
        int codigoCaracter;

        try {

            istream = Files.newInputStream(decrypted);
            ostream1 = Files.newOutputStream(encrypted1);
            ostream2 = Files.newOutputStream(encrypted2);

            boolean interruptor = false;

            while ((codigoCaracter = istream.read()) != -1) {

                if (!interruptor) {

                    ostream1.write(codigoCaracter);

                    interruptor = true;

                } else {

                    ostream2.write(codigoCaracter);

                    interruptor = false;

                }

            }

            istream.close();
            ostream1.close();
            ostream2.close();

        } catch (IOException e) {

            System.out.println(e);

        }

    }

    public static void decrypt(Path encrypted1, Path encrypted2) {

        Path decrypted = Paths.get(encrypted1.getParent() + "/decrypted.txt");

        InputStream istream1 = null;
        InputStream istream2 = null;
        OutputStream ostream = null;

        try {

            istream1 = Files.newInputStream(encrypted1);
            istream2 = Files.newInputStream(encrypted2);
            ostream = Files.newOutputStream(decrypted);
            int codigoCaracter1 = 0;
            int codigoCaracter2 = 0;

            boolean continuar = true;

            for (int i = 0; continuar; i += 1) {

                if (i % 2 == 0 && (codigoCaracter1 = istream1.read()) != -1) {

                    ostream.write(codigoCaracter1);

                }

                if (i % 2 != 0 && (codigoCaracter2 = istream2.read()) != -1) {

                    ostream.write(codigoCaracter2);

                }

                if (codigoCaracter1 == -1 && codigoCaracter2 == -1) {

                    continuar = false;

                }

            }

            istream1.close();
            istream2.close();
            ostream.close();

        } catch (IOException e) {

            System.err.println(e);

        }

    }

}
