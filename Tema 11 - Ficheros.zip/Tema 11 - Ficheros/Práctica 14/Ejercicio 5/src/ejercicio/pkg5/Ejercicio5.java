/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg5;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*; // NECESARIO PARA REPLACE_EXISTING 

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        borrarDirectorio(leerDirectorio());

    }

    public static Path leerDirectorio() {

        Scanner sc = new Scanner(System.in);
        Path ruta = null;
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA LA RUTA COMPLETA DEL DIRECTORIO: ");
            String directorio = sc.nextLine();

            try {

                ruta = Paths.get(directorio).toRealPath();

                if (!Files.isDirectory(ruta)) {

                    System.err.println("LA RUTA INTRODUCIDA NO COINCIDE CON NINGÚN DIRECTORIO. ");

                } else {

                    quit = true;

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INTRODUCIDA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static void borrarDirectorio(Path ruta) {

        Scanner sc = new Scanner(System.in);

        try {

            Files.delete(ruta);

        } catch (IOException e) { // SI EL DIRECTORIO CONTIENE ALGO LANZARÁ LA EXCEPCIÓN 

            System.out.println("¿DESEA LLEVAR A CABO LA OPERACIÓN? "
                    + "\n\t1. SI "
                    + "\n\t2. NO ");
            int respuesta = sc.nextInt();

            if (respuesta == 1) {

                try {

                    DirectoryStream<Path> stream = Files.newDirectoryStream(ruta);

                    for (Path path : stream) {

                        Files.delete(path);

                    }

                    Files.delete(ruta);

                } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS

                    System.err.format("%s: ERROR DE PERMISOS. \n", ruta);

                }

            }

        }

    }

}
