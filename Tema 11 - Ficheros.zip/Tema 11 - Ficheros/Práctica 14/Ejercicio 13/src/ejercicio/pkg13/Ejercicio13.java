/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg13;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        String datos[];
        Vector<Alumno> alumnos = new Vector<Alumno>();
        Path fichero = Paths.get("alumnos.txt");
        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 

        try {

            reader = Files.newBufferedReader(fichero, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                System.out.println(line);

                datos = line.split(","); // LA FUNCIÓN split() TRANSFORMA UNA CADENA DE TEXTO EN UN ARRAY DE TIPO String (TENIENDO EN CUENTA LOS SEPARADORES ESPECIFICADOS ",") 

                alumnos.add(new Alumno(datos[0], datos[1], datos[2], datos[3])); // DADO QUE ESTAMOS PASANDO DATOS DE TIPO String ENTRARÁ POR EL 2º CONSTRUCTOR DE LA CLASE ALUMNO 

            }

            burbuja(alumnos, alumnos.size());

            System.out.println(alumnos);

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

    }

    public static void burbuja(Vector<Alumno> v, int TAM) { // SE PASA A LA FUNCIÓN UN VECTOR Y EL TAMAÑO DEL VECTOR QUE QUIERO ORDENAR. 

        int j, k;
        Alumno aux;

        for (j = 1; j < TAM; j += 1) {

            for (k = 0; k < TAM - j; k += 1) {

                // DESCENDENTE 
                if (v.get(k).getNota() < v.get(k + 1).getNota()) {

                    aux = v.get(k);

                    v.set(k, v.get(k + 1));

                    v.set(k + 1, aux);

                }

            }

        }

    }

}
