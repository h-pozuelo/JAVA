/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg13;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Hugo
 */
public class Alumno {

    private String nombre, apellido;
    private double nota;
    private LocalDate fechaNacimiento;

    public Alumno(String nombre, String apellido, double nota, LocalDate fechaNacimiento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nota = nota;
        this.fechaNacimiento = fechaNacimiento;
    }

    public Alumno(String nombre, String apellido, String nota, String fechaNacimiento) {
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("dd/LL/yyyy");
        this.nombre = nombre;
        this.apellido = apellido;
        this.nota = Double.parseDouble(nota);
        this.fechaNacimiento = LocalDate.parse(fechaNacimiento, patron);
    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", apellido=" + apellido + ", nota=" + nota + ", fechaNacimiento=" + fechaNacimiento + '}';
    }

    public double getNota() {
        return nota;
    }

}
