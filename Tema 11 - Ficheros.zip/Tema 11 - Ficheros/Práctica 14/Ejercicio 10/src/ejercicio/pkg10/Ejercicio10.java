/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg10;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejercicio10 {

    static final char vocales[] = {'a', 'e', 'i', 'o', 'u'};

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        crearFichero(leerFichero());

    }

    public static Path leerFichero() {

        Path ruta = null;
        Scanner sc = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA LA RUTA REAL DEL FICHERO CORRESPONDIENTE: ");
            String fichero = sc.nextLine();

            try {

                ruta = Paths.get(fichero).toRealPath();

                if (Files.isRegularFile(ruta)) {

                    quit = true;

                } else {

                    System.err.println("LA RUTA INTRODUCIDA NO CORRESPONDE A UN FICHERO. ");

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INTRODUCIDA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static void crearFichero(Path ruta) {

        Path origen = ruta;
        Path destino = Paths.get(ruta.getParent() + "/Sin Vocales - " + ruta.getFileName());
        /*
        ARRAY DE BYTES PARA I/O (LEER/ESCRIBIR) TODOS LOS BYTES DEL FICHERO 
         */
        InputStream istream = null; // SE DECLARA EL OBJETO 
        OutputStream ostream = null; // SE DECLARA EL OBJETO 
        int ascii;// VARIABLE EN LA QUE SE IRÁ ALMACENANDO (EN CADA VUELTA DEL BUCLE) CADA UNO DE LOS BYTES QUE CONTIENE EL FICHERO DE ENTRADA 

        try {
            /*
            InputStream Y OutputStream (PERTENECIENTE A java.nio) PERMITE TRABAJAR BYTE A BYTE SOBRE EL FICHERO 
            LOS GENERAMOS DE FORMA EFICIENTE UTILIZANDO java.nio 
             */
            istream = Files.newInputStream(origen); // SE CREA EL OBJETO 
            ostream = Files.newOutputStream(destino); // SE CREA EL OBJETO 

            while ((ascii = istream.read()) != -1) { // CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
                /*
                ESCRIBIMOS TODOS LOS BYTES EN EL FICHERO DE SALIDA 
                DESPUES DE EJECUTAR SE COMPRUEBA QUE ES IGUAL A LA ENTRADA 
                 */
                boolean esVocal = false;

                for (int i = 0; i < 5; i += 1) {

                    if ((ascii == Character.toUpperCase(vocales[i])) || (ascii == Character.toLowerCase(vocales[i]))) {

                        esVocal = true;

                        break;

                    }

                }

                if (!esVocal) {

                    ostream.write(ascii); // LA FUNCIÓN write(c) VUELCA (EN CADA VUELTA DEL BUCLE) EL CONTENIDO DE LA VARIABLE c EN EL FICHERO DE SALIDA 

                }

            }

            istream.close(); // SE CIERRA EL OBJETO 
            ostream.close(); // SE CIERRA EL OBJETO (SI NO SE CIERRA EL OBJETO PODRÍAN QUEDAR BYTES SUELTOS EN EL FICHERO DE SALIDA) 

        } catch (IOException io) {

            System.err.println(io);

        }

    }

}
