/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*; // NECESARIO PARA REPLACE_EXISTING 

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Path origen = existeFichero();
        Path destino = validarDestino();

        copiarFichero(origen, destino);

    }

    public static Path existeFichero() {

        Path ruta = null;
        boolean quit = false;

        while (!quit) {

            try {

                ruta = leerFichero();

                if (Files.isRegularFile(ruta)) {

                    quit = true;

                } else {

                    System.err.format("EL FICHERO INDICADO NO EXISTE. \n");

                }

            } catch (IOException e) {

                System.err.format("LA RUTA INDICADA NO EXISTE. \n");

            }

        }

        return ruta;

    }

    public static Path leerFichero() throws IOException {

        Scanner sc = new Scanner(System.in);

        System.out.println("INDIQUE DIRECTORIO EN EL QUE SE ENCUENTRA EL FICHERO: ");
        String directorio = sc.nextLine();

        System.out.println("INDIQUE EL NOMBRE DEL FICHERO: ");
        String fichero = sc.nextLine();

        return Paths.get(directorio + "/" + fichero).toRealPath();

    }

    public static Path validarDestino() {

        Scanner sc = new Scanner(System.in);
        boolean quit = false;
        Path ruta = null;

        while (!quit) {

            System.out.println("INDIQUE DIRECTORIO DE DESTINO EN EL QUE DESEA COPIAR EL FICHERO: ");
            String directorio = sc.nextLine();

            try {

                ruta = Paths.get(directorio).toRealPath();

                quit = true;

            } catch (IOException e) {

                System.err.format("LA RUTA INDICADA NO EXISTE. \n");

            }

        }

        System.out.println("INDIQUE EL NOMBRE DEL FICHERO: ");
        String fichero = sc.nextLine();

        return Paths.get(ruta + "/" + fichero);

    }

    public static void copiarFichero(Path origen, Path destino) {

        try {

            Files.copy(origen, destino);

        } catch (FileAlreadyExistsException e) {

            Scanner sc = new Scanner(System.in);

            System.err.format("EL FICHERO INDICADO YA EXISTE EN EL DESTINO. \n");

            System.out.println("¿DESEA SOBRESCRIBIR EL FICHERO DE DESTINO? "
                    + "\n\t1. SI "
                    + "\n\t2. NO ");
            int respuesta = sc.nextInt();

            if (respuesta == 1) {

                try {

                    Files.copy(origen, destino, REPLACE_EXISTING);;

                } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

                    System.err.format("NO CUMPLES CON LOS PERMISOS NECESARIOS PARA REALIZAR LA OPERACIÓN. \n");

                }

            }

        } catch (IOException e) { // POSIBLES PROBLEMAS CON LOS PERMISOS 

            System.err.format("NO CUMPLES CON LOS PERMISOS NECESARIOS PARA REALIZAR LA OPERACIÓN. \n");

        }

    }

}
