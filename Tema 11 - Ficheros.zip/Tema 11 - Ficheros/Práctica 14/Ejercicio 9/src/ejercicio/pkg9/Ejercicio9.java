/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg9;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        listarFicheros(leerDirectorio());

    }

    public static Path leerDirectorio() {

        Path ruta = null;
        Scanner sc = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA LA RUTA REAL DEL DIRECTORIO CORRESPONDIENTE: ");
            String directorio = sc.nextLine();

            try {

                ruta = Paths.get(directorio).toRealPath();

                if (Files.isDirectory(ruta)) {

                    quit = true;

                } else {

                    System.err.println("LA RUTA INTRODUCIDA NO CORRESPONDE A UN DIRECTORIO. ");

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INTRODUCIDA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static void listarFicheros(Path ruta) {

        try {

            DirectoryStream<Path> stream = Files.newDirectoryStream(ruta);

            for (Path path : stream) {

                if (Files.isRegularFile(path)) {

                    System.out.println(path.getFileName());

                    leerFichero(path);

                }

            }

        } catch (IOException x) { // POSIBLES PROBLEMAS CON LOS PERMISOS

            System.err.format("%s: ERROR DE PERMISOS. \n", ruta);

        }

    }

    public static void leerFichero(Path ruta) throws IOException {

        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 

        try {

            reader = Files.newBufferedReader(ruta, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                System.out.println("\u001B[33m" + line + "\u001B[0m");

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

    }

}
