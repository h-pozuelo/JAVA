/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg15;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import java.util.Locale;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Vector<Cuenta> cuentas = new Vector<Cuenta>(3);

        String fichero = "cuentas.txt";
        importarCuentas(fichero, cuentas);

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int opcion;

        do {

            opcion = menu(sc);

            switch (opcion) {

                case 1:

                    int identificador;

                    do {

                        System.out.println("INDIQUE IDENTIFICADOR DE LA CUENTA: ");
                        identificador = sc.nextInt();

                        if (validarIdentificador(cuentas, identificador) != -1) {

                            System.out.println("EL IDENTIFICADOR INTRODUCIDO YA SE ENCUENTRA EN USO. ");

                        }

                    } while (validarIdentificador(cuentas, identificador) != -1);

                    int tipoCuenta;

                    do {

                        System.out.println("INDIQUE TIPO DE CUENTA: \n"
                                + "\t1. TIPO DE CUENTA NORMAL. \n"
                                + "\t2. TIPO DE CUENTA CUENTÓN. ");
                        tipoCuenta = sc.nextInt();

                        if (tipoCuenta < 1 || tipoCuenta > 2) {

                            System.out.println("TIPO DE CUENTA NO VÁLIDO. ");

                        }

                    } while (tipoCuenta < 1 || tipoCuenta > 2);

                    String titulares[] = new String[3];
                    int totalTitulares = 0;

                    for (; totalTitulares < titulares.length;) {

                        sc.nextLine();

                        String nif;

                        do {

                            System.out.println("INTRODUZCA NIF DE TITULAR " + (totalTitulares + 1) + ":");
                            nif = sc.nextLine();

                        } while (!validarDNI(nif));

                        titulares[totalTitulares] = nif;

                        totalTitulares += 1;

                        if (totalTitulares < titulares.length) {

                            int respuesta;

                            do {

                                System.out.println("¿DESEA AGREGAR OTRO TITULAR? \n"
                                        + "\t1. SI. \n"
                                        + "\t2. NO. ");
                                respuesta = sc.nextInt();

                                if (respuesta < 1 || respuesta > 2) {

                                    System.out.println("RESPUESTA NO VÁLIDA. ");

                                }

                            } while (respuesta < 1 || respuesta > 2);

                            if (respuesta == 2) {

                                break;

                            }

                        }

                    }

                    double saldo;

                    do {

                        System.out.println("INTRODUZCA CANTIDAD DE SALDO: ");
                        saldo = sc.nextDouble();

                        if (saldo < 0 || (saldo < 600 && tipoCuenta == 2)) {

                            System.out.println("CANTIDAD DE SALDO NO VÁLIDA. ");

                        }

                    } while (saldo < 0 || (saldo < 600 && tipoCuenta == 2));

                    if (tipoCuenta != 2) {

                        cuentas.add(new Cuenta(identificador, titulares, totalTitulares, saldo));

                    } else {

                        cuentas.add(new Cuenton(identificador, titulares, totalTitulares, saldo));

                    }

                    break;

                case 2:

                    if (cuentas.size() > 0) {

                        String dni;

                        sc.nextLine();

                        do {

                            System.out.println("INTRODUZCA NIF DE TITULAR: ");
                            dni = sc.nextLine();

                        } while (!validarDNI(dni));

                        for (int i = 0; i < cuentas.size(); i += 1) {

                            if (buscarTitular(cuentas, i, dni)) {

                                cuentas.remove(i);

                            }

                        }

                    }

                    break;

                case 3:

                    if (cuentas.size() > 0) {

                        int dias;

                        do {

                            System.out.println("INTRODUZCA NÚMERO DE DÍAS: ");
                            dias = sc.nextInt();

                            if (dias < 0) {

                                System.out.println("INTRODUZCA UNA CANTIDAD VÁLIDA. ");

                            }

                        } while (dias < 0);

                        for (int i = 0; i < cuentas.size(); i += 1) {

                            double intereses = cuentas.get(i).getSaldo() * cuentas.get(i).getInteres() * dias / 365;

                            cuentas.get(i).setSaldo(cuentas.get(i).getSaldo() + (int) (intereses));

                            System.out.println("INFORMACIÓN DE LA CUENTA: [" + cuentas.get(i).toString() + "] INTERESES PRODUCIDOS: " + (int) (intereses) + " €");

                        }

                    }

                    break;

                case 4:

                    generarSorteo(cuentas);

                    break;

            }

        } while (opcion != 5);

        exportarCuentas(fichero, cuentas);

    }

    public static int validarIdentificador(Vector<Cuenta> cuentas, int identificador) {

        for (int i = 0; i < cuentas.size(); i += 1) {

            if (cuentas.get(i).getIdentificador() == identificador) {

                return i;

            }

        }

        return -1;

    }

    public static void importarCuentas(String fichero, Vector<Cuenta> cuentas) throws IOException {

        Path file = Paths.get(fichero).toRealPath();
        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 

        try {

            reader = Files.newBufferedReader(file, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                String datos[] = line.split(",");

                String titulares[] = new String[3];
                int totalTitulares = 0;

                for (int i = 3; i < datos.length; i += 1) {

                    titulares[totalTitulares] = datos[i];
                    totalTitulares++;

                }

                if (Integer.parseInt(datos[2]) == 1) {

                    cuentas.add(new Cuenta(Integer.parseInt(datos[0]), titulares, totalTitulares, Double.parseDouble(datos[1])));

                } else {

                    cuentas.add(new Cuenton(Integer.parseInt(datos[0]), titulares, totalTitulares, Double.parseDouble(datos[1])));

                }

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

    }

    public static void exportarCuentas(String fichero, Vector<Cuenta> cuentas) throws IOException {

        String linea;
        Path file = Paths.get(fichero).toRealPath(); // UBICACIÓN DEL FICHERO A ESCRIBIR 
        Charset charset = Charset.forName("UTF-8"); // CODIFICACIÓN DEL FICHERO 
        /*
        CREAMOS UN BufferedWriter DE java.nio DE FORMA EFICIENTE UTILIZANDO Files DE java.nio 
         */
        try {
            /*
            CREA EL FICHERO SI NO EXISTE (SI EXISTE BORRA EL CONTENIDO DEL FICHERO) 
            BufferedWriter writer = Files.newBufferedWriter(file, charset);
             */
            BufferedWriter writer = Files.newBufferedWriter(file);
            writer.write("");
            writer.flush();
            writer.close();

            writer = Files.newBufferedWriter(file, charset, APPEND); // [APPEND] PERMITE AÑADIR DATOS AL FINAL DEL FICHERO (SIN SOBREESCRIBIR LO ANTERIOR) 

            for (int i = 0; i < cuentas.size(); i += 1) {

                int tipoCuenta;

                if (cuentas.get(i) instanceof Cuenta) {

                    tipoCuenta = 1;

                } else {

                    tipoCuenta = 2;

                }

                String titulares = "";

                for (int j = 0; j < cuentas.get(i).getTotalTitulares(); j += 1) {

                    titulares += "," + cuentas.get(i).getTitulares()[j];

                }

                writer.write(cuentas.get(i).getIdentificador() + "," + cuentas.get(i).getSaldo() + "," + tipoCuenta + titulares); // VA ESCRIBIENDO SOBRE EL FICHERO LÍNEA A LÍNEA HASTA ANOTAR "FIN" 
                writer.newLine(); // SALTO DE LÍNEA PARA CUANDO PRESIONAMOS LA TECLA [ENTER] 

            }

            writer.close();

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        }

    }

    private static int menu(Scanner sc) {

        int opcion;

        do {

            System.out.println("INDIQUE UNA OPCIÓN: \n"
                    + "\t1. CREAR UNA CUENTA. \n"
                    + "\t2. CANCELAR CUENTAS DE UN TITULAR. \n"
                    + "\t3. CALCULAR INTERESES DE TODAS LAS CUENTAS. \n"
                    + "\t4. SORTEAR UN VIAJE ENTRE TODAS LAS CUENTAS DE TIPO CUENTÓN. \n"
                    + "\t5. SALIR DEL PROGRAMA. ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 5) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 5);

        return opcion;

    }

    private static boolean tipoCuenton(double sueldo) {

        if (sueldo < 600) {

            return false;

        }

        return true;

    }

    private static boolean validarDNI(String dni) {

        if (dni.length() != 9) {

            System.out.println("TAMAÑO REQUERIDO DE 9 CARACTERES. ");

            return false;

        }

        for (int i = 0; i < dni.length() - 1; i += 1) {

            if (!Character.isDigit(dni.charAt(i))) {

                System.out.println("LOS OCHO PRIMEROS CARACTERES HAN DE SER DÍGITOS. ");

                return false;

            }

        }

        if (!Character.isLetter(dni.charAt(dni.length() - 1))) {

            System.out.println("EL ÚLTIMO CARACTER HA DE SER UNA LETRA. ");

            return false;

        }

        return true;

    }

    public static boolean buscarTitular(Vector<Cuenta> cuentas, int identificador, String dni) {

        String titulares[] = cuentas.get(identificador).getTitulares();

        for (int i = 0; i < cuentas.get(identificador).getTotalTitulares(); i += 1) {

            if (dni.equalsIgnoreCase(titulares[i])) {

                return true;

            }

        }

        return false;

    }

    private static void generarSorteo(Vector<Cuenta> cuentas) {
        /*
        // [HERENCIAEMPLEADO]
        
        // MOSTRAR TODOS LOS JEFES (CADA JEFE TIENE ASIGNADO UN AYUDANTE) 
        
        System.out.println("JEFES: ");
        for (int i = 0; i < 3; i += 1) {
            if (plantilla[i] instanceof Jefe) {
                System.out.println(plantilla[i].toString());
            }
        }

        // MOSTRAR TODOS LOS AYUDANTES 
        
        
        // TENIENDO EN CUENTA QUE EL ARRAY PLANTILLA ES DE TIPO EMPLEADO 
        // ES NECESARIO REALIZAR UN CASTING (NO CONFUNDIR CON PARSE) DEL 
        // ARRAY PLANTILLA Y TRANSFORMARLO EN UN ARRAY DE TIPO JEFE PARA 
        // PODER ASÍ EJECUTAR LAS FUNCIONES PROPIAS DE UN JEFE. 
        
        System.out.println("AYUDANTES: ");
        for (int i = 0; i < 3; i += 1) {
            if (plantilla[i] instanceof Jefe) {
                ((Jefe) (plantilla[i])).getAyudante();
            }
        }
         */
        int totalCuenton = 0;

        int posicion = 0;

        for (int i = 0; i < cuentas.size(); i += 1) {

            if (cuentas.get(i) instanceof Cuenton) {

                totalCuenton += 1;

                posicion = i;

            }

        }

        if (totalCuenton != 0) {

            int ganador = (int) (Math.random() * (totalCuenton - 1 + 1) + 1);

            int j = 0;

            for (int i = 0; i <= posicion; i += 1) { // LA VARIABLE POSICIÓN HACE REFERENCIA A LA CELDA DE LA ÚLTIMA CUENTA DE TIPO CUENTÓN QUE SE HA ENCONTRADO. 

                if (cuentas.get(i) instanceof Cuenton) {

                    j += 1;

                    if (j == ganador) {

                        System.out.println("EL GANADOR HA SIDO [" + cuentas.get(i).toString() + "].");

                    }

                }

            }

        } else {

            System.out.println("NO SE HA PODIDO REALIZAR EL SORTEO. ");

        }

    }

}
