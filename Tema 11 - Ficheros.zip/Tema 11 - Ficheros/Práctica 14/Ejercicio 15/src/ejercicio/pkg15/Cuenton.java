/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg15;

/**
 *
 * @author Hugo
 */
public class Cuenton extends Cuenta {

    public Cuenton(int identificador, String[] titulares, int totalTitulares, double saldo) {
        super(identificador, titulares, totalTitulares, saldo);
        this.interes = 4;
    }

}
