/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg15;

import java.util.Arrays;

/**
 *
 * @author Hugo
 */
public class Cuenta {

    protected int interes = 3;
    private int identificador;
    private String[] titulares = new String[3];
    private int totalTitulares;
    private double saldo;

    public Cuenta(int identificador, String[] titulares, int totalTitulares, double saldo) {
        this.identificador = identificador;
        this.titulares = titulares;
        this.totalTitulares = totalTitulares;
        this.saldo = saldo;
    }

    public int getIdentificador() {
        return identificador;
    }

    public int getInteres() {
        return interes;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String[] getTitulares() {
        return titulares;
    }

    public int getTotalTitulares() {
        return totalTitulares;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "interes=" + interes + ", identificador=" + identificador + ", titulares=" + Arrays.toString(titulares) + ", totalTitulares=" + totalTitulares + ", saldo=" + saldo + '}';
    }

}
