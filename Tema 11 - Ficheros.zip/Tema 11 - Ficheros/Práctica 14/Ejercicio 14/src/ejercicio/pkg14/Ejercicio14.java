/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg14;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejercicio14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        System.out.println("INTRODUZCA UNA PALABRA: ");
        String palabra = sc.nextLine();

        leerFichero(buscarFichero(), palabra, crearFichero());

    }

    public static Path buscarFichero() {

        Path ruta = null;
        Scanner sc = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA LA RUTA REAL DEL FICHERO CORRESPONDIENTE: ");
            String fichero = sc.nextLine();

            try {

                ruta = Paths.get(fichero).toRealPath();

                if (Files.isRegularFile(ruta)) {

                    quit = true;

                } else {

                    System.err.println("LA RUTA INTRODUCIDA NO CORRESPONDE A NINGÚN FICHERO. ");

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INTRODUCIDA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static Path crearFichero() {

        Path ruta = null;
        Scanner sc = new Scanner(System.in);
        boolean quit = false;

        while (!quit) {

            System.out.println("¿COMO DESEA NOMBRAR AL FICHERO DE SALIDA?");
            String fichero = sc.nextLine();

            System.out.println("INDIQUE EL NOMBRE DEL DIRECTORIO EN DONDE ALMACENAR EL FICHERO DE SALIDA: ");
            String directorio = sc.nextLine();

            try {

                Path path = Paths.get(directorio).toRealPath();

                if (Files.isDirectory(path)) {

                    ruta = Paths.get(directorio + "/" + fichero); // SI PIDO LA RUTA REAL DEL FICHERO LANZARÁ LA EXCEPCIÓN IOException DADO QUE AÚN NO HA SIDO CREADO 

                    if (!existeFichero(ruta)) {

                        try {

                            File file = new File(ruta.toString());
                            file.createNewFile();

                        } catch (IOException x) {

                            System.err.format("IOException: %s%n", x);

                        }

                        quit = true;

                    } else {

                        System.err.println("DICHO NOMBRE DE FICHERO YA SE ENCUENTRA EN USO. ");

                    }

                } else {

                    System.err.println("LA RUTA INDICADA NO CORRESPONDE A NINGÚN DIRECTORIO. ");

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INDICADA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static boolean existeFichero(Path ruta) {

        try {

            ruta.toRealPath();

        } catch (IOException e) {

            return false;

        }

        return true;

    }

    public static void leerFichero(Path origen, String palabra, Path destino) throws IOException {

        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 
        String palabras[];

        try {

            reader = Files.newBufferedReader(origen, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {
                /*
                LA FUNCIÓN .replaceAll() UNICAMENTE REEMPLAZA AQUELLAS PALABRAS QUE COINCIDAN LITERALMENTE CON EL VALOR QUE LE HEMOS PASADO 
                 */
                // escribirFichero(destino, line.replaceAll(palabra, ""));
                /*
                HACIENDO USO DE LA EXPRESIÓN REGULAR "(?i)" EN LA FUNCIÓN .replaceAll() REEMPLAZARÁ AQUELLAS PALABRAS QUE COINCIDAN (SIN SER IDÉNTICAS) CON EL VALOR QUE LE HEMOS PASADO 
                 */
                // escribirFichero(destino, line.replaceAll("(?i)" + palabra, ""));

                String cadena = "";
                palabras = line.split(" ");

                for (int i = 0; i < palabras.length; i += 1) {

                    if (!palabras[i].equalsIgnoreCase(palabra)) {

                        cadena += palabras[i] + " ";

                    }

                }

                escribirFichero(destino, cadena);

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally { // UNA VEZ FINALICE LA EJECUCIÓN (CON O SIN EXCEPCIÓN) ENTRARÁ OBLIGATORIAMENTE POR EL "finally" 

            if (reader != null) {

                reader.close();

            }

        }

    }

    public static void escribirFichero(Path ruta, String line) {

        Charset charset = Charset.forName("UTF-8"); // CODIFICACIÓN DEL FICHERO 
        /*
        CREAMOS UN BufferedWriter DE java.nio DE FORMA EFICIENTE UTILIZANDO Files DE java.nio 
         */
        try {
            /*
            CREA EL FICHERO SI NO EXISTE (SI EXISTE BORRA EL CONTENIDO DEL FICHERO) 
            BufferedWriter writer = Files.newBufferedWriter(file, charset);
             */
            BufferedWriter writer = Files.newBufferedWriter(ruta, charset, APPEND); // [APPEND] PERMITE AÑADIR DATOS AL FINAL DEL FICHERO (SIN SOBREESCRIBIR LO ANTERIOR) 
            /*
            BufferedWriter writer = Files.newBufferedWriter(ruta, charset); // SI NO SE DECLARA NINGUNA OPCIÓN POR DEFECTO UTILIZA [CREATE] + [TRUNCATE_EXISTING] + [WRITE] (CREANDO UN FICHERO VACÍO SI NO EXISTE) 
             */
            writer.write(line); // VA ESCRIBIENDO SOBRE EL FICHERO LÍNEA A LÍNEA HASTA ANOTAR "FIN" 
            writer.newLine(); // SALTO DE LÍNEA PARA CUANDO PRESIONAMOS LA TECLA [ENTER] 
            /*
            writer.write(line + "\n"); // TAMBIÉN ES VÁLIDO REALIZAR UN SALTO DE LÍNEA DE LA MANERA TRADICIONAL CON "\n" 
             */
            writer.close();

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        }

    }

}
