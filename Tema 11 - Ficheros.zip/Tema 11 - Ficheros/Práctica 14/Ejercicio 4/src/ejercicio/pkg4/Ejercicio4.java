/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.nio.file.*;
import java.io.*;
import java.util.*;
import static java.nio.file.StandardCopyOption.*; // NECESARIO PARA REPLACE_EXISTING 

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Scanner sc = new Scanner(System.in);

        System.out.println("¿POR CUAL CARACTER DEBEN COMENZAR LOS NOMBRES DE LOS FICHEROS?");
        char caracter = sc.nextLine().charAt(0);

        borrarFicheros(leerDirectorio(), caracter);

    }

    public static Path leerDirectorio() {

        Scanner sc = new Scanner(System.in);
        boolean quit = false;
        Path ruta = null;

        while (!quit) {

            System.out.println("INTRODUZCA RUTA ABSOLUTA DEL DIRECTORIO: ");
            String directorio = sc.nextLine();

            try {

                ruta = Paths.get(directorio).toRealPath();

                if (!Files.isDirectory(ruta)) {

                    System.err.println("DEBE INTRODUCIR UN DIRECTORIO VÁLIDO. ");

                } else {

                    quit = true;

                }

            } catch (IOException e) {

                System.err.println("LA RUTA INDICADA NO EXISTE. ");

            }

        }

        return ruta;

    }

    public static void borrarFicheros(Path ruta, char caracter) {

        try {

            DirectoryStream<Path> stream = Files.newDirectoryStream(ruta);

            for (Path path : stream) {

                if (Files.isRegularFile(path) && Character.toLowerCase(path.getFileName().toString().charAt(0)) == Character.toLowerCase(caracter)) {

                    Files.delete(path);

                }

                if (Files.isDirectory(path)) {

                    borrarFicheros(path, caracter);

                }

            }

        } catch (IOException e) { // POSIBLES PROBLEMAS CON LOS PERMISOS

            System.err.format("%s: ERROR DE PERMISOS. \n", ruta);

        }

    }

}
