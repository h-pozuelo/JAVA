/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg8;

import java.util.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author Hugo
 */
public class Ejercicio8 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Path entrada = Paths.get("entrada.txt");
        InputStream istream = null;
        int c, contador = 0;

        System.out.println("INDIQUE EL CARACTER: ");
        char caracter = sc.nextLine().charAt(0);

        try {

            istream = Files.newInputStream(entrada);

            while ((c = istream.read()) != -1) {
                /*
                LA VARIABLE c CONTIENE EL CÓDIGO ASCII DEL BYTE LEIDO 
                LA VARIABLE caracter CONTIENE EL CARACTER A LOCALIZAR 
                 */
                if ((c == Character.toLowerCase(caracter)) || (c == Character.toUpperCase(caracter))) { // COMPARA EL CÓDIGO ASCII VOLCADO EN LA VARIABLE c CON EL CARACTER A LOCALIZAR 

                    contador += 1;

                }

            }

            istream.close();

        } catch (IOException e) {

            System.err.println("ERROR DE PERMISOS. ");

        }

        System.out.println("EL CARACTER " + caracter + " SE REPITE UN TOTAL DE " + contador + " VECES. ");

    }

}
