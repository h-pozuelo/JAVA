/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numero = -1;

        // FORMA 1: DECLARACIÓN DEL VECTOR 
        Vector<Integer> numeros = new Vector<Integer>();
        /*
        // FORMA 2: DECLARACIÓN DEL VECTOR 
        Vector<Integer> numeros;

        // FORMA 2A: CREACIÓN DEL VECTOR 
        numeros = new Vector<>();

        // FORMA 2B: CRAECIÓN DEL VECTOR 
        numeros = new Vector();
         */
        // System.out.println("EL MÁXIMO ENTERO ES: " + Integer.MAX_VALUE);
        while (numero != 0) {

            System.out.println("INTRODUZCA NÚMERO: ");
            numero = sc.nextInt();

            if (numero == 0) {

                break;

            }

            // FORMA 1: INSERCIÓN ORDENADA DE NÚMEROS EN UN VECTOR 
            int j = 0;

            for (; j < numeros.size(); j += 1) {

                // FORMA 1A: COMPARAR 2 VALORES CONVIRTIENDO EL OBJETO Integer EN TIPO DE DATO BÁSICO Int 
                if (numeros.get(j).intValue() > numero) {

                    break;

                }
                /*
                // FORMA 1B: COMPARAR 2 VALORES SIN CONVERTIR EL OBJETO Integer EN TIPO DE DATO BÁSICO Int 
                if (numeros.get(j) > numero) {

                    break;

                }
                 */
            }

            // FORMA 1: AGREGAR A UN VECTOR TIPO DE DATO BÁSICO Int CONVIRTIÉNDOLO EN UN OBJETO Integer 
            numeros.add(j, new Integer(numero));
            /*
            // FORMA 2: AGREGAR A UN VECTOR TIPO DE DATO BÁSICO Int SIN CONVERTIRLO EN UN OBJETO Integer 
            numeros.add(j, numero);
             */
 /*
            // FORMA 2: INSERCIÓN ORDENADA DE NÚMEROS EN UN VECTOR 
            boolean insertado = false;

            for (int i = 0; i < numeros.size(); i += 1) {

                if (numeros.get(i).intValue() > numero) {

                    numeros.add(new Integer(numero), i);
                    insertado = true;
                    break;

                }

            }

            if (!insertado) {

                numeros.add(new Integer(numero));

            }
             */
        }

        System.out.println(numeros);

        System.out.println("INDIQUE NÚMERO PARA BUSCAR: ");
        numero = sc.nextInt();

        // FORMA 1A: LOCALIZACIÓN DE UN NÚMERO EN UN VECTOR CON indexOf() 
        int posicion = numeros.indexOf(new Integer(numero));
        /*
        // FORMA 1B: LOCALIZACIÓN DE UN NÚMERO EN UN VECTOR CON indexOf() 
        int posicion = numeros.indexOf(numero);
         */
        if (posicion == -1) {

            System.out.println("NO SE ENCUENTRA EN LA LISTA. ");

        } else {

            System.out.println("SI SE ENCUENTRA EN LA LISTA. ");

        }
        /*
        // FORMA 2: LOCALIZACIÓN DE UN NÚMERO EN UN VECTOR 
        boolean encontrado = false;

        for (int i = 0; i < numeros.size(); i += 1) {

            // FORMA 2A: LOCALIZACIÓN DE UN NÚMERO EN UN VECTOR CON compareTo() 
            if (numeros.get(i).compareTo(new Integer(numero)) == 0) {

                System.out.println("SI SE ENCUENTRA EN LA LISTA. ");
                encontrado = true;
                break;

            }

            // FORMA 2B: LOCALIZACIÓN DE UN NÚMERO EN UN VECTOR CON intValue() 
            if (numeros.get(i).intValue() == numero) {

                System.out.println("SI SE ENCUENTRA EN LA LISTA. ");
                encontrado = true;
                break;

            }

        }

        if (!encontrado) {

            System.out.println("NO SE ENCUENTRA EN LA LISTA. ");

        }
         */
        // FORMA 1: BORRADO DE UN NÚMERO EN UN VECTOR 
        System.out.println("INDIQUE NÚMERO A BORRAR: ");
        numero = sc.nextInt();

        // FORMA 1A: BORRADO DE UN NÚMERO ESPECÍFICO EN UN VECTOR 
        boolean borrado = numeros.remove((Integer) numero); // RETORNA [ true / false ] EN FUNCIÓN DE SI SE HA BORRADO EL OBJETO Integer DEL VECTOR 
        /*
        // FORMA 1B: BORRADO DE UNA CELDA ESPECÍFICA EN UN VECTOR 
        Integer remove = numeros.remove(numero); // RETORNA [Integer] AL BORRAR EL OBJETO Integer CON POSICIÓN Int DEL VECTOR 
         */
        if (borrado) {

            System.out.println("SI SE HA PODIDO BORRAR EL ELEMENTO. ");

        } else {

            System.out.println("NO SE HA PODIDO BORRAR EL ELEMENTO. ");

        }

    }

}
