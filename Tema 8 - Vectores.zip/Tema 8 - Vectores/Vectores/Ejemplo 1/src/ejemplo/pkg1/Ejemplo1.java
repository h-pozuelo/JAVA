/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // ---------------------------------------------------------------------
        // CREAR UN VECTOR: 
        // ---------------------------------------------------------------------
        Vector<String> cadenas = new Vector<String>();
        // ---------------------------------------------------------------------
        // TAMAÑO: 
        // ---------------------------------------------------------------------
        System.out.println("CANTIDAD DE ELEMENTOS: " + cadenas.size());

        System.out.println(cadenas);
        // ---------------------------------------------------------------------
        // AÑADIR UN ELEMENTO: 
        // ---------------------------------------------------------------------
        cadenas.add("HOLA"); // CELDA [0] 
        cadenas.add("OTRA"); // CELDA [1] 
        cadenas.add("ÚLTIMO"); // CELDA [2] 

        System.out.println(cadenas);

        cadenas.add(2, "PENÚLTIMO"); // CELDA [2] 

        System.out.println(cadenas);

        cadenas.add(0, "PRIMERO"); // CELDA [0] 

        System.out.println(cadenas);
        /*
        cadenas.add(10, "DIEZ"); // EXCEPCIÓN 
         */
        System.out.println("CANTIDAD DE ELEMENTOS: " + cadenas.size());
        // ---------------------------------------------------------------------
        // OBTENER UN ELEMENTO: 
        // ---------------------------------------------------------------------
        System.out.println("ELEMENTO DE LA POSICIÓN 0 (PRIMERO): " + cadenas.get(0));

        System.out.println("ELEMENTO DE LA POSICIÓN 3 (PENÚLTIMO): " + cadenas.get(3));

        System.out.println("ELEMENTO DE LA POSICIÓN 4 (ÚLTIMO): " + cadenas.get(cadenas.size() - 1));

        for (int i = 0; i < cadenas.size(); i += 1) {

            System.out.println(cadenas.get(i));

        }
        // ---------------------------------------------------------------------
        // MODIFICAR UN ELEMENTO: 
        // ---------------------------------------------------------------------
        cadenas.set(0, "NUEVO");

        System.out.println("VECTOR DESPUÉS DE MODIFICAR EL PRIMER ELEMENTO: " + cadenas);
        // ---------------------------------------------------------------------
        // BORRAR UN ELEMENTO: 
        // ---------------------------------------------------------------------
        cadenas.remove(0);
        /*
        cadenas.remove(10); // EXCEPCIÓN 
         */
        System.out.println("VECTOR DESPUÉS DE BORRAR EL PRIMER ELEMENTO: " + cadenas);

        cadenas.remove("OTRA"); // UTILIZA EL MÉTODO equals !OBLIGATORIO REDEFINIRLO¡ 

        System.out.println("VECTOR DESPUÉS DE BORRAR LA CADENA OTRA: " + cadenas);

        if (!cadenas.remove("OTRA")) {

            System.out.println("NO EXISTE LA CADENA OTRA. ");

        } else {

            System.out.println("VECTOR DESPUÉS DE BORRAR LA CADENA OTRA: " + cadenas);

        }
        // ---------------------------------------------------------------------
        // BUSCAR UN ELEMENTO: 
        // ---------------------------------------------------------------------
        int posicion = cadenas.indexOf("PENÚLTIMO");

        if (posicion == -1) {

            System.out.println("ELEMENTO NO ENCONTRADO. ");

        } else {

            System.out.println("ELEMENTO ENCONTRADO EN LA POSICIÓN: " + posicion);

        }

    }

}
