/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Comun extends Atraccion {

    public Comun(String nombre, int numeroPlazas, double costePorMinuto) {
        super(nombre, numeroPlazas, costePorMinuto);
        this.precioPorPersona = 2;
    }

    @Override
    public String toString() {
        return "Tipo de atraccion = Comun" + super.toString();
    }

}
