/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    static Vector<Atraccion> atracciones = new Vector();
    static Scanner sc = new Scanner(System.in);
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    altaAtraccion();

                    break;

                case 2:

                    montarPersona();

                    break;

                case 3:

                    abrirAtraccion();

                    break;

                case 4:

                    pararAtraccion();

                    break;

                case 5:

                    ponerEnFuncionamiento();

                    break;

                case 6:

                    for (int i = 0; i < atracciones.size(); i += 1) {

                        System.out.println(atracciones.get(i).toString());

                    }

                    break;

                case 7:

                    double maxRecaudado = 0;
                    int atraccionMaxRecaudado = -1;

                    for (int i = 0; i < atracciones.size(); i += 1) {

                        if (atracciones.get(i) instanceof Especial) {

                            double recaudado = atracciones.get(i).getTotalRecaudadoPorAtraccion();

                            if (recaudado >= maxRecaudado) {

                                maxRecaudado = recaudado;

                                atraccionMaxRecaudado = i;

                            }

                        }

                    }

                    if (atraccionMaxRecaudado != -1) {

                        System.out.println(atracciones.get(atraccionMaxRecaudado).toString());

                    } else {

                        System.out.println("NO EXISTE NINGUNA ATRACCIÓN DE TIPO ESPECIAL. ");

                    }

                    break;

            }

        } while (opcion != 8);

    }

    private static void abrirAtraccion() {

        sc.nextLine();

        System.out.println("INDIQUE NOMBRE DE LA ATRACCIÓN: ");
        String nombre = sc.nextLine();

        int atraccion = buscarAtraccion(nombre);

        if (atraccion != -1) {

            switch (atracciones.get(atraccion).abrirAtraccion()) {

                case 1:

                    System.out.println("ATRACCIÓN ABIERTA CON ÉXITO. ");

                    break;

                case 2:

                    System.out.println("LA ATRACCIÓN YA SE ENCUENTRA ABIERTA. ");

                    break;

            }

        } else {

            System.out.println("NO SE HA ENCONTRADO DICHA ATRACCIÓN. ");

        }

    }

    private static void pararAtraccion() {

        sc.nextLine();

        System.out.println("INDIQUE NOMBRE DE LA ATRACCIÓN: ");
        String nombre = sc.nextLine();

        int atraccion = buscarAtraccion(nombre);

        if (atraccion != -1) {

            switch (atracciones.get(atraccion).pararAtraccion()) {

                case 1:

                    System.out.println("ATRACCIÓN DETENIDA CON ÉXITO. ");

                    break;

                case 2:

                    System.out.println("LA ATRACCIÓN YA SE ENCUENTRA DETENIDA. ");

                    break;

            }

        } else {

            System.out.println("NO SE HA ENCONTRADO DICHA ATRACCIÓN. ");

        }

    }

    private static void ponerEnFuncionamiento() {

        sc.nextLine();

        System.out.println("INDIQUE NOMBRE DE LA ATRACCIÓN: ");
        String nombre = sc.nextLine();

        int atraccion = buscarAtraccion(nombre);

        if (atraccion != -1) {

            switch (atracciones.get(atraccion).ponerEnFuncionamiento()) {

                case 1:

                    System.out.println("ATRACCIÓN PUESTA EN FUNCIONAMIENTO CON ÉXITO. ");

                    break;

                case 2:

                    System.out.println("LA ATRACCIÓN YA SE ENCUENTRA EN FUNCIONAMIENTO. ");

                    break;

            }

        } else {

            System.out.println("NO SE HA ENCONTRADO DICHA ATRACCIÓN. ");

        }

    }

    private static void altaAtraccion() {

        String nombre;
        int tipoAtraccion = 0;
        int numeroPlazas = 0;
        double costePorMinuto = 0;

        while (tipoAtraccion < 1 || tipoAtraccion > 2) {

            System.out.println("INDIQUE TIPO DE ATRACCIÓN: "
                    + "\n\t1. TODOS LOS PÚBLICOS "
                    + "\n\t2. ESPECIAL ");
            tipoAtraccion = sc.nextInt();

            if (tipoAtraccion < 1 || tipoAtraccion > 2) {

                System.out.println("TIPO DE ATRACCIÓN NO VÁLIDO. ");

            }

        }

        System.out.println("INTRODUZCA NOMBRE DE ATRACCIÓN: ");
        sc.nextLine();
        nombre = sc.nextLine();

        while (numeroPlazas <= 0) {

            System.out.println("INDIQUE NÚMERO DE PLAZAS PARA LA ATRACCIÓN " + nombre.toUpperCase() + ":");
            numeroPlazas = sc.nextInt();

            if (numeroPlazas <= 0) {

                System.out.println("NÚMERO DE PLAZAS NO VÁLIDO. ");

            }

        }

        while (costePorMinuto <= 0) {

            System.out.println("ANOTA COSTE POR MINUTO PARA LA ATRACCIÓN " + nombre.toUpperCase() + ":");
            costePorMinuto = sc.nextDouble();

            if (costePorMinuto <= 0) {

                System.out.println("COSTE POR MINUTO NO VÁLIDO. ");

            }

        }

        switch (tipoAtraccion) {

            case 1:

                atracciones.add(new Comun(nombre, numeroPlazas, costePorMinuto));

                break;

            case 2:

                System.out.println("INTRODUZCA EDAD REQUERIDA: ");
                int edadRequerida = sc.nextInt();

                System.out.println("INTRODUZCA ALTURA REQUERIDA: ");
                double alturaRequerida = sc.nextDouble();

                atracciones.add(new Especial(nombre, numeroPlazas, costePorMinuto, edadRequerida, alturaRequerida));

                break;

        }

    }

    private static void montarPersona() {

        if (atracciones.size() == 0) {

            System.out.println("PRIMERO DEBE DAR DE ALTA UNA ATRACCIÓN. ");

        } else {

            Random r = new Random();

            int atraccion = r.nextInt(atracciones.size()); // GENERARÁ UN NÚMERO DE ENTRE LA LONGITUD ESPECIFICADA. SI PONGO r.nextInt(10) GENERARÁ UN NÚMERO ENTRE [ 0 - 9 ]. 

            if (atracciones.get(atraccion).getTotalPersonas() < atracciones.get(atraccion).getNumeroPlazas()) {

                if (atracciones.get(atraccion).isAcceso() && !atracciones.get(atraccion).isEstado()) {

                    if (atracciones.get(atraccion) instanceof Comun) {

                        atracciones.get(atraccion).montarPersona(new Persona());

                    }

                    if (atracciones.get(atraccion) instanceof Especial) {

                        System.out.println("INTRODUZCA EDAD: ");
                        int edad = sc.nextInt();

                        if (edad >= ((Especial) atracciones.get(atraccion)).getEdadRequerida()) {

                            System.out.println("INTRODUZCA ALTURA: ");
                            double altura = sc.nextDouble();

                            if (altura >= ((Especial) atracciones.get(atraccion)).getAlturaRequerida()) {

                                atracciones.get(atraccion).montarPersona(new Persona(edad, altura));

                            } else {

                                System.out.println("ES NECESARIO MEDIR " + ((Especial) atracciones.get(atraccion)).getAlturaRequerida() + " METROS PARA PODER MONSTARSE EN " + atracciones.get(atraccion).getNombre().toUpperCase() + ".");

                            }

                        } else {

                            System.out.println("ES NECESARIO TENER " + ((Especial) atracciones.get(atraccion)).getEdadRequerida() + " AÑOS PARA PODER MONSTARSE EN " + atracciones.get(atraccion).getNombre().toUpperCase() + ".");

                        }

                    }

                } else {

                    System.out.println("PARA PODER MONTARSE EN LA ATRACCIÓN ESTA DEBE DE ESTAR ABIERTA Y PARADA. ");

                }

            } else {

                System.out.println("NO EXISTEN PLAZAS DISPONIBLES PARA LA ATRACCIÓN " + atracciones.get(atraccion).getNombre().toUpperCase() + ".");

            }

        }

    }

    private static int buscarAtraccion(String nombre) {

        for (int i = 0; i < atracciones.size(); i += 1) {

            if (atracciones.get(i).getNombre().equalsIgnoreCase(nombre)) {

                return i;

            }

        }

        return -1;

    }

    private static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. DAR DE ALTA UNA ATRACCIÓN "
                    + "\n\t2. MONTAR UNA PERSONA EN UNA ATRACCIÓN "
                    + "\n\t3. ABRIR UNA ATRACCIÓN "
                    + "\n\t4. PARAR UNA ATRACCIÓN "
                    + "\n\t5. PONER EN FUNCIONAMIENTO UNA ATRACCIÓN "
                    + "\n\t6. MOSTRAR LA INFORMACIÓN DE TODAS LAS ATRACCIONES "
                    + "\n\t7. BUSCAR LA ATRACCIÓN ESPECIAL QUE MÁS HAYA RECAUDADO "
                    + "\n\t8. SALIR DEL PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 8) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 8);

        return opcion;

    }

}
