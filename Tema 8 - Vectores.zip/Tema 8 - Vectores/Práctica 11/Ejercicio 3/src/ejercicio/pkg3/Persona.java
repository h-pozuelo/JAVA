/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Persona {

    private int edad;
    private double altura;

    public Persona() {
    }

    public Persona(int edad, double altura) {
        this.edad = edad;
        this.altura = altura;
    }

}
