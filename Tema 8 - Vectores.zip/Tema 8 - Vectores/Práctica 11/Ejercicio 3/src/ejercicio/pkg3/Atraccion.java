/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Atraccion {

    private String nombre;
    private int numeroPlazas;
    private double costePorMinuto;
    protected double precioPorPersona;
    protected boolean acceso = false; // false [CERRADA] (SI NO SE PUEDE MONTAR GENTE) O true [ABIERTA] (SI PUEDE MONTAR GENTE) 
    protected boolean estado = false; // false [PARADA] (SI NO SE MUEVE) O true [FUNCIONANDO] (SI ESTÁ YA EN MOVIMIENTO) 
    protected double totalRecaudadoPorAtraccion;
    protected static double totalRecaudadoParque;
    private Persona[] personas;
    private int totalPersonas = 0;

    public Atraccion(String nombre, int numeroPlazas, double costePorMinuto) {
        this.nombre = nombre;
        this.numeroPlazas = numeroPlazas;
        this.costePorMinuto = costePorMinuto;
        this.personas = new Persona[numeroPlazas];
    }

    public String getNombre() {
        return nombre;
    }

    public int getNumeroPlazas() {
        return numeroPlazas;
    }

    public Persona[] getPersonas() {
        return personas;
    }

    public int getTotalPersonas() {
        return totalPersonas;
    }

    public boolean isAcceso() {
        return acceso;
    }

    public boolean isEstado() {
        return estado;
    }

    public void montarPersona(Persona persona) {

        personas[totalPersonas] = persona;

        totalPersonas += 1;

        totalRecaudadoPorAtraccion += precioPorPersona;

        totalRecaudadoParque += precioPorPersona;

    }

    public int abrirAtraccion() {

        if (!acceso) {

            acceso = true;

            return 1;

        }

        return 2;

    }

    public int pararAtraccion() {

        if (estado) {

            estado = false;

            return 1;

        }

        return 2;

    }

    public int ponerEnFuncionamiento() {

        if (!estado) {

            estado = true;

            return 1;

        }

        return 2;

    }

    public double getTotalRecaudadoPorAtraccion() {
        return totalRecaudadoPorAtraccion;
    }

    @Override
    public String toString() {
        return "\n\tAtraccion = "
                + "\n\t\tNombre = " + nombre
                + "\n\t\tNumero de plazas = " + numeroPlazas
                + "\n\t\tCoste por minuto = " + costePorMinuto
                + "\n\t\tPrecio por persona = " + precioPorPersona
                + "\n\t\tAcceso = " + acceso
                + "\n\t\tEstado = " + estado
                + "\n\t\tTotal recaudado por atraccion = " + totalRecaudadoPorAtraccion
                + "\n\t\tTotal recaudado parque = " + totalRecaudadoParque
                + "\n\t\tTotal personas = " + totalPersonas;
    }

}
