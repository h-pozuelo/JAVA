/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Especial extends Atraccion {

    private int edadRequerida;
    private double alturaRequerida;

    public Especial(String nombre, int numeroPlazas, double costePorMinuto, int edadRequerida, double alturaRequerida) {
        super(nombre, numeroPlazas, costePorMinuto);
        this.edadRequerida = edadRequerida;
        this.alturaRequerida = alturaRequerida;
        this.precioPorPersona = 3;
    }

    public int getEdadRequerida() {
        return edadRequerida;
    }

    public double getAlturaRequerida() {
        return alturaRequerida;
    }

    @Override
    public String toString() {
        return "Tipo de atraccion = Especial"
                + "\nEdad requerida = " + edadRequerida
                + "\nAltura requerida = " + alturaRequerida
                + super.toString();
    }

}
