/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Externo extends Empleado {

    private String procedencia;

    public Externo(String procedencia, int identificador, String nombre, String dni, Direccion direccion, String telefono) {
        super(identificador, nombre, dni, direccion, telefono);
        this.procedencia = procedencia;
        this.precioHora = 22;
    }

    @Override
    public String toString() {
        return "Externo{" + "procedencia=" + procedencia + ", empleado=" + super.toString() + '}';
    }

    public double pagar() {

        this.salario = this.cantidadHoras * this.precioHora;

        this.cantidadHoras = 0;

        return this.salario;

    }

}
