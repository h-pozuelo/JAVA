/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static Vector<Alumno> alumnos = new Vector<Alumno>();
    static Scanner sc = new Scanner(System.in);
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        do {

            switch (menu()) {

                case 1:

                    sc.nextLine();

                    System.out.println("INTRODUZCA NOMBRE: ");
                    String nombre = sc.nextLine();

                    double nota;

                    do {

                        System.out.println("INTRODUZCA NOTA: ");
                        nota = sc.nextDouble();

                        if (nota < 0 || nota > 10) {

                            System.out.println("NOTA NO VÁLIDA.");

                        }

                    } while (nota < 0 || nota > 10);

                    altaAlumno(new Alumno(nombre, nota));

                    break;

                case 2:

                    sc.nextLine();

                    System.out.println("INTRODUZCA NOMBRE: ");
                    nombre = sc.nextLine();

                    modificarNota(nombre);

                    break;

                case 3:

                    sc.nextLine();

                    System.out.println("INTRODUZCA NOMBRE: ");
                    nombre = sc.nextLine();

                    modificarNombre(nombre);

                    break;

                case 4:

                    sc.nextLine();

                    System.out.println("INTRODUZCA NOMBRE: ");
                    nombre = sc.nextLine();

                    bajaAlumno(nombre);

                    break;

            }

        } while (opcion != 5);

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. DAR DE ALTA UN ALUMNO "
                    + "\n\t2. MODIFICAR LA NOTA DE UN ALUMNO "
                    + "\n\t3. MODIFICAR EL NOMBRE DE UN ALUMNO "
                    + "\n\t4. DAR DE BAJA UN ALUMNO "
                    + "\n\t5. SALIR DEL PROGRAMA ");

            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 5) {

                System.out.println("OPCIÓN NO VÁLIDA.");

            }

        } while (opcion < 1 || opcion > 5);

        return opcion;

    }

    private static int buscarAlumno(String nombre) {

        return alumnos.indexOf(new Alumno(nombre, 0));
        /*
        for (int i = 0; i < alumnos.size(); i += 1) {

            if (nombre.equalsIgnoreCase(alumnos.get(i).getNombre())) {

                return i;

            }

        }

        return -1;
         */
    }

    private static void altaAlumno(Alumno alumno) {

        if (buscarAlumno(alumno.getNombre()) == -1) {

            alumnos.add(alumno);

            System.out.println("ALTA DE ALUMNO REALIZADA CON ÉXITO.");

        } else {

            System.out.println("YA EXISTE UN ALUMNO CON DICHO NOMBRE.");

        }

    }

    private static void bajaAlumno(String nombre) {

        if (buscarAlumno(nombre) != -1) {

            alumnos.remove(buscarAlumno(nombre));

            System.out.println("BAJA DE ALUMNO REALIZADA CON ÉXITO.");

        } else {

            System.out.println("NO EXISTE UN ALUMNO CON DICHO NOMBRE.");

        }

    }

    private static void modificarNota(String nombre) {

        int posicion = buscarAlumno(nombre);

        if (posicion != -1) {

            double nota;

            do {

                System.out.println("INTRODUZCA NUEVA NOTA: ");
                nota = sc.nextDouble();

                if (nota < 0 || nota > 10) {

                    System.out.println("NOTA NO VÁLIDA.");

                }

            } while (nota < 0 || nota > 10);

            // alumnos.set(posicion, new Alumno(nombre, nota));
            alumnos.get(posicion).setNota(nota);

            System.out.println("NOTA MODIFICADA CON ÉXITO.");

        } else {

            System.out.println("NO EXISTE UN ALUMNO CON DICHO NOMBRE.");

        }

    }

    private static void modificarNombre(String nombre) {

        int posicion = buscarAlumno(nombre);

        if (posicion != -1) {

            System.out.println("INTRODUZCA NUEVO NOMBRE: ");
            String nombreNuevo = sc.nextLine();

            alumnos.get(posicion).setNombre(nombreNuevo);

            System.out.println("NOMBRE MODIFICADO CON ÉXITO.");

        } else {

            System.out.println("NO EXISTE UN ALUMNO CON DICHO NOMBRE.");

        }

    }

}
