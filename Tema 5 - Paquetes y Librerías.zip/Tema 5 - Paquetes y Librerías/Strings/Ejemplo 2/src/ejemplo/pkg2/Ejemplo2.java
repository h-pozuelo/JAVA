/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String uno = "hola";
        String dos = uno.toUpperCase();

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("UNO: " + uno);

        System.out.println("DOS: " + dos);

        uno = uno.toUpperCase(); // TRANSFORMAR EN MAYÚSCULAS. 

        System.out.println("UNO: " + uno);

        dos = dos.toLowerCase(); // TRANSFORMAR EN MINÚSCULAS. 

        System.out.println("DOS: " + dos);

        uno = uno.replace('H', 'B'); // REEMPLAZAR UN CARACTER ESPECÍFICO. 

        System.out.println("UNO: " + uno);

        uno = uno.replaceAll("BOLA", "HOLA ¿QUE PASA?"); // REEMPLAZAR UNA CADENA DE CARACTERES. 

        System.out.println("UNO: " + uno);

    }

}
