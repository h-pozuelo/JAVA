/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        char letra;
        String ciudadEuropea;
        int numCount = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("INTRODUZCA LETRA: ");
        letra = sc.nextLine().charAt(0);

        letra = Character.toUpperCase(letra);

        do {

            System.out.println("INTRODUZCA NOMBRE DE CIUDAD EUROPEA: ");
            System.out.println("[0] SALIR");
            ciudadEuropea = sc.nextLine();

            ciudadEuropea = ciudadEuropea.toUpperCase();

            if (ciudadEuropea.charAt(0) != '0') {

                if (ciudadEuropea.charAt(0) == letra) {

                    numCount += 1;

                }

            }

        } while (ciudadEuropea.charAt(0) != '0');

        System.out.println("CANTIDAD DE CIUDADES QUE COMIENZAN POR LA LETRA " + letra + " = " + numCount + ".");

    }

}
