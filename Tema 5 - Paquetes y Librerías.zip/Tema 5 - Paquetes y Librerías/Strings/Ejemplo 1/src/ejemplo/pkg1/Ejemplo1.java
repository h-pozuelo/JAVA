/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String cadena = "PEPE";
        String otra, resultado;
        boolean validarCodigo;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        System.out.println("CADENA DE CARACTERES: " + cadena);

        System.out.println("ANOTA CADENA DE CARACTERES: ");
        otra = sc.nextLine();

        System.out.println("CADENA DE CARACTERES: " + otra);

        resultado = cadena + " " + otra; // CONCATENAR CADENAS DE CARACTERES. 

        System.out.println("RESULTADO: " + resultado);

        System.out.println("EL TAMAÑO DE LA CADENA DE CARACTERES ES DE: " + resultado.length()); // COMIENZA A CONTAR DESDE LA POSICIÓN 0 POR LO QUE EL ÚLTIMO CARACTER ESTARÁ EN LA POSICIÓN resultado.length() -1. 

        System.out.println("EL PRIMER CARACTER DE LA CADENA DE CARACTERES ES: " + resultado.charAt(0)); // OBTENER EL PRIMER CARACTER DE LA CADENA DE CARACTERES. 

        System.out.println("EL ÚLTIMO CARACTER DE LA CADENA DE CARACTERES ES: " + resultado.charAt(resultado.length() - 1)); // OBTENER EL ÚLTIMO CARACTER DE LA CADENA DE CARACTERES. 

        for (int i = 0; i < resultado.length(); i++) { // RECORRE CADA UNO DE LOS CARACTERES MOSTRÁNDOLOS DE MANERA DESCENDENTE. 
            System.out.println(resultado.charAt(i)); // SI REEMPLAZO println POR print SE MUESTRA LA CADENA DE CARACTERES SIN SALTOS DE LÍNEA. 
        }

        for (int i = resultado.length() - 1; i >= 0; i--) { // RECORRE CADA UNO DE LOS CARACTERES MOSTRÁNDOLOS DE MANERA ASCENDENTE. 
            System.out.println(resultado.charAt(i));
        }

        do {

            System.out.println("ANOTA CÓDIGO: [UNA LETRA Y TRES DIGITOS]");
            cadena = sc.nextLine();

            validarCodigo = validarCodigo(cadena);

            if (!validarCodigo) {
                System.out.println("CÓDIGO NO VÁLIDO.");
            }

        } while (!validarCodigo);

        otra = "B123";

        if (otra.equalsIgnoreCase(cadena)) {

            System.out.println("SON IGUALES.");

        } else {

            System.out.println("SON DISTINTAS.");

            System.out.println("CADENA DE CARACTERES ORDENADAS: ");

            if (cadena.compareTo(otra) < 0) {

                System.out.println(cadena + " " + otra);

            } else {

                System.out.println(otra + " " + cadena);

            }

        }

    }

    public static boolean validarCodigo(String codigo) {

        if (codigo.length() != 4) {
            return false;
        }

        if (!Character.isLetter(codigo.charAt(0))) {
            return false;
        }
        /*
        char letra = Character.toUpperCase(codigo.charAt(0));

        if ((letra < 'A' || letra > 'Z') && letra != 'Ñ') {
            return false;
        }
         */
        for (int i = 1; i <= codigo.length() - 1; i++) {

            if (codigo.charAt(i) < '0' || codigo.charAt(i) > '9') {

                return false;

            }

        }

        return true;

    }

}
