/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String palabra, cadenaCaracteres = "";

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            palabra = sc.nextLine();

            cadenaCaracteres = cadenaCaracteres + palabra.toUpperCase();

        } while (!palabra.equalsIgnoreCase("fin"));

        System.out.println(cadenaCaracteres);

    }

}
