/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio6 {

    static Plaza plazas[] = new Plaza[5];
    static int opcion;
    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    ocuparPlaza();

                    break;

                case 2:

                    liberarPlaza();

                    break;

                case 3:

                    System.out.println("TOTAL RECAUDADO: " + totalRecaudado() + " €");

                    break;

            }

        } while (opcion != 4);

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. OCUPAR UNA PLAZA DE GARAJE "
                    + "\n\t2. LIBERAR UNA PLAZA DE GARAJE "
                    + "\n\t3. CALCULAR GANANCIAS TOTALES "
                    + "\n\t4. SALIR DEL PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 4) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 4);

        return opcion;

    }

    public static void ocuparPlaza() {

        System.out.println("INTRODUZCA MATRÍCULA DEL VEHÍCULO: ");
        sc.nextLine();
        String matricula = sc.nextLine();

        try {

            for (int i = 0;; i += 1) {

                if (plazas[i] == null || !plazas[i].isOcupada()) {

                    plazas[i] = new Plaza(matricula);

                    break;

                }

            }

        } catch (ArrayIndexOutOfBoundsException e) {

            System.out.println("CAPACIDAD MÁXIMA DE VEHÍCULOS ALCANZADA. ");

        }

    }

    public static void liberarPlaza() {

        System.out.println("INTRODUZCA NÚMERO DE PLAZA A LIBERAR: [ 1 - 5 ] ");
        int numPlaza = sc.nextInt();

        try {

            System.out.println("TOTAL: " + plazas[numPlaza - 1].calcularImporte() + " €");

        } catch (NullPointerException e) {

            System.out.println("LA PLAZA DE GARAJE INDICADA NO ESTÁ OCUPADA. ");

        } catch (ArrayIndexOutOfBoundsException e) {

            System.out.println("LA PLAZA DE GARAJE INDICADA NO EXISTE. ");

        }

    }

    public static double totalRecaudado() {

        return Plaza.getTotalRecaudado();

    }

}
