/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg6;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Hugo
 */
public class Plaza {

    private String matricula = null;
    private LocalDateTime horaLlegada = null;
    private boolean ocupada = false;
    private static double totalRecaudado = 0;

    public Plaza(String matricula) {
        this.matricula = matricula;
        this.horaLlegada = LocalDateTime.now();
        this.ocupada = true;
    }

    public double calcularImporte() {

        LocalDateTime horaSalida = LocalDateTime.now();
        double importe = 0;

        importe = Math.abs(ChronoUnit.SECONDS.between(horaLlegada, horaSalida) * 0.01);

        this.matricula = null;
        this.horaLlegada = null;
        this.ocupada = false;

        this.totalRecaudado += importe;

        return importe;

    }

    public boolean isOcupada() {
        return ocupada;
    }

    public static double getTotalRecaudado() {
        return totalRecaudado;
    }

}
