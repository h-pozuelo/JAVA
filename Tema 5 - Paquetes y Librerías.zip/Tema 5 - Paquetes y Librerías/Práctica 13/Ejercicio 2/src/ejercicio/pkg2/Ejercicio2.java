/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    static Scanner sc = new Scanner(System.in);
    static boolean quit = false;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LocalDate fecha = null;
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        while (!quit) {

            System.out.println("INTRODUZCA FECHA EN FORMATO [dd/mm/aaaa]: ");
            String fechaIntroducida = sc.nextLine();

            try {

                fecha = LocalDate.parse(fechaIntroducida, patron);

                quit = true;

            } catch (DateTimeParseException e) {

                System.out.println("LA FECHA NO CUMPLE CON EL PATRÓN ESTABLECIDO. ");

            }

        }

        System.out.println("INTRODUZCA NÚMERO DE DÍAS: ");
        int numDias = sc.nextInt();

        System.out.println(patron.format(fecha.plusDays(numDias)));

    }

}
