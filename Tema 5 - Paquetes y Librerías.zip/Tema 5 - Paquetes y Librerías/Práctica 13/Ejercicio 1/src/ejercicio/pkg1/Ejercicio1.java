/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Vector<LocalDate> fechas = new Vector<LocalDate>(3);
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        for (int i = 0; i < 3; i += 1) {

            LocalDate fecha = leerFecha(formatoFecha);

            fechas.add(fecha);

        }

        Collections.sort(fechas);

        for (int i = 0; i < fechas.size(); i += 1) {

            System.out.println(formatoFecha.format(fechas.get(i)));

        }

    }

    public static LocalDate leerFecha(DateTimeFormatter patron) {

        LocalDate fecha = null;
        boolean correcto = false;

        while (!correcto) {

            System.out.println("INTRODUZCA FECHA EN FORMATO [dd-mm-aaaa]: ");
            String fechaIntroducida = sc.nextLine();

            try {

                fecha = LocalDate.parse(fechaIntroducida, patron);

                correcto = true;

            } catch (DateTimeParseException e) {

                System.out.println("LA FECHA INTRODUCIDA NO TIENE EL FORMATO [dd-mm-aaaa]. ");

            }

        }

        return fecha;

    }

}
