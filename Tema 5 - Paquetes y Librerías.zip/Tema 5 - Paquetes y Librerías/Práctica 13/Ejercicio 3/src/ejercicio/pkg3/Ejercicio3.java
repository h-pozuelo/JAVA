/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LocalDate fecha1 = leerFecha(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        LocalDate fecha2 = leerFecha(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

        long dias = Math.abs(ChronoUnit.DAYS.between(fecha1, fecha2));

        System.out.println(dias);

        if (fecha1.isBefore(fecha2)) {

            System.out.println(ChronoUnit.DAYS.between(fecha1, fecha2));

        } else {

            System.out.println(ChronoUnit.DAYS.between(fecha2, fecha1));

        }

    }

    public static LocalDate leerFecha(DateTimeFormatter patron) {

        LocalDate fecha = null;
        boolean quit = false;

        while (!quit) {

            System.out.println("INTRODUZCA FECHA EN FORMATO [dd/mm/aaaa]: ");
            String fechaIntroducida = sc.nextLine();

            try {

                fecha = LocalDate.parse(fechaIntroducida, patron);

                quit = true;

            } catch (DateTimeParseException e) {

                System.out.println("LA FECHA NO CUMPLE CON EL PATRÓN ESTABLECIDO. ");

            }

        }

        return fecha;

    }

}
