/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.time.LocalTime;
import java.util.Random;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    static Random r = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LocalTime hora = LocalTime.now().plusSeconds(1);
        int cantidadSeises = 0;

        for (; LocalTime.now().isBefore(hora);) {

            if ((r.nextInt(7 - 1) + 1) == 6) {

                cantidadSeises++;

            }

        }

        System.out.println(cantidadSeises);

    }

}
