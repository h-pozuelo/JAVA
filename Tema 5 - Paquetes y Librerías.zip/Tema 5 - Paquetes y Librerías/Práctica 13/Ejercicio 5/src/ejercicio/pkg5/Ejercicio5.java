/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg5;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.TextStyle;
import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LocalDate fecha = null;
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("dd-LL-yyyy");
        boolean quit = false;

        while (!quit) {

            System.out.println("INDIQUE SU FECHA DE NACIMIENTO EN FORMATO [dd-mm-aaaa]: ");
            String fechaNacimiento = sc.nextLine();

            try {

                fecha = LocalDate.parse(fechaNacimiento, patron);

                quit = true;

            } catch (DateTimeParseException e) {

                System.out.println("LA FECHA NO CUMPLE CON EL PATRÓN ESTABLECIDO. ");

            }

        }

        System.out.println("USTED NACIO UN " + fecha.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault()).toUpperCase() + ".");

    }

}
