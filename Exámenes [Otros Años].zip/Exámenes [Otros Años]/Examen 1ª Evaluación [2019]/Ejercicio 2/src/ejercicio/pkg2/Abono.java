/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Abono {

    private String nombreTitular;
    private int edad;
    private String codigo;
    private boolean familiaNumerosa;
    private static int numCount;
    private boolean tasaCrear = true;
    private int viajesDisponibles;
    private static double ingresosTotales;
    private int cargarBonoCount;

    public Abono(String nombreTitular, int edad, boolean familiaNumerosa) {
        this.nombreTitular = nombreTitular;
        this.edad = edad;
        this.familiaNumerosa = familiaNumerosa;
    }

    public void generarCodigo() {

        numCount += 1;

        char tipoAbono;

        if (this.familiaNumerosa == true) {

            tipoAbono = 'F';

        } else if (this.edad < 25) {

            tipoAbono = 'J';

        } else {

            tipoAbono = 'N';

        }

        String nombre = this.nombreTitular.toUpperCase();

        this.codigo = tipoAbono + nombre.substring(0, 3) + numCount;

    }

    @Override
    public String toString() {
        return "Abono{" + "nombreTitular=" + nombreTitular + ", edad=" + edad + ", codigo=" + codigo + ", familiaNumerosa=" + familiaNumerosa + ", tasaCrear=" + tasaCrear + ", viajesDisponibles=" + viajesDisponibles + ", cargarBonoCount=" + cargarBonoCount + '}';
    }

    public double cargarBono() {

        cargarBonoCount += 1;

        double importe;

        if (this.familiaNumerosa == true) {

            importe = 10;

        } else if (this.edad < 25) {

            importe = 15;

            this.viajesDisponibles = 40;

        } else {

            importe = 18;

            this.viajesDisponibles = 10;

        }

        if (tasaCrear == true) {

            tasaCrear = false;

            importe += 2;

        }

        ingresosTotales += importe;

        return importe;

    }

    public boolean hacerViaje() {

        if (this.familiaNumerosa == true) {

            return true;

        } else {

            if (this.viajesDisponibles > 0) {

                this.viajesDisponibles -= 1;

                return true;

            } else {

                return false;

            }

        }

    }

    public static String masViajes(Abono a1, Abono a2) { // MÉTODO PÚBLICO (PARA PODER SER ACCEDIDO DESDE EL MAIN) Y ESTÁTICO (PARA PODER COMPARAR OBJETOS DE LA CLASE). [Abono.masViajes(a1, a2);] 

        if (a1.viajesDisponibles > a2.viajesDisponibles) {

            return a1.codigo;

        } else if (a1.viajesDisponibles < a2.viajesDisponibles) {

            return a2.codigo;

        } else {

            return "IGUALES.";

        }

    }

    public String masViajes(Abono a) { // [a1.masViajes(a2);] == [this.viajesDisponibles(a.viajesDisponibles);] 

        if (this.viajesDisponibles > a.viajesDisponibles) {

            return this.codigo;

        } else if (this.viajesDisponibles < a.viajesDisponibles) {

            return a.codigo;

        } else {

            return "IGUALES.";

        }

    }

    public static double getIngresosTotales() {
        return ingresosTotales;
    }

    public int getCargarBonoCount() {
        return cargarBonoCount;
    }

}
