/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int respuesta, abonoTransporte, viajeRealizado;

        Abono a1 = new Abono("HUGO POZUELO MARTÍNEZ", 20, true);
        Abono a2 = new Abono("DAVID POZUELO MARTÍNEZ", 23, false);

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        // MOSTRAR INFORMACIÓN DEL ABONO 1. 
        a1.generarCodigo();
        System.out.println(a1.toString());

        // MOSTRAR INFORMACIÓN DEL ABONO 2. 
        a2.generarCodigo();
        System.out.println(a2.toString());

        // RECARGAR TARJETA DE TRANSPORTE. 
        do {

            System.out.println("¿DESEA RECARGAR SU TARJETA DE TRANSPORTE?");
            System.out.println("[1] SÍ.");
            System.out.println("[2] NO.");
            respuesta = sc.nextInt();

            if (respuesta != 2) {

                do {

                    System.out.println("INTRODUZCA SU TARJETA DE TRANSPORTE: ");
                    System.out.println("[1] " + a1.toString());
                    System.out.println("[2] " + a2.toString());
                    abonoTransporte = sc.nextInt();

                    switch (abonoTransporte) {

                        case 1:
                            a1.cargarBono();
                            break;

                        case 2:
                            a2.cargarBono();
                            break;

                        default:
                            System.out.println("CARÁCTER NO VÁLIDO.");
                            break;

                    }

                } while (abonoTransporte != 1 && abonoTransporte != 2);

            }

        } while (respuesta != 2);

        // REALIZAR UN VIAJE. 
        do {

            System.out.println("¿DESEA REALIZAR UN VIAJE?");
            System.out.println("[1] SÍ.");
            System.out.println("[2] NO.");
            respuesta = sc.nextInt();

            if (respuesta != 2) {

                do {

                    System.out.println("INTRODUZCA SU TARJETA DE TRANSPORTE: ");
                    System.out.println("[1] " + a1.toString());
                    System.out.println("[2] " + a2.toString());
                    viajeRealizado = sc.nextInt();

                    switch (viajeRealizado) {

                        case 1:
                            a1.hacerViaje();
                            break;

                        case 2:
                            a2.hacerViaje();
                            break;

                        default:
                            System.out.println("CARÁCTER NO VÁLIDO.");
                            break;

                    }

                } while (viajeRealizado != 1 && viajeRealizado != 2);

            }

        } while (respuesta != 2);

        // COMPARAR CANTIDAD DE VIAJES DISPONIBLES ENTRE EL ABONO 1 Y EL ABONO 2. 
        System.out.println(Abono.masViajes(a1, a2)); // [MÉTODO 1] 

        System.out.println(a1.masViajes(a2)); // [MÉTODO 2] 

        // MOSTRAR CANTIDAD DE RECARGAS REALIZADAS EN EL ABONO 1. 
        System.out.println(a1.toString());

        System.out.println("CANTIDAD DE RECARGAS REALIZADAS EN EL ABONO 1: " + a1.getCargarBonoCount());

        // MOSTRAR CANTIDAD DE RECARGAS REALIZADAS EN EL ABONO 2. 
        System.out.println(a2.toString());

        System.out.println("CANTIDAD DE RECARGAS REALIZADAS EN EL ABONO 2: " + a2.getCargarBonoCount());

        // MOSTRAR INGRESOS TOTALES DE LA COMPAÑÍA. 
        System.out.println("INGRESOS TOTALES: " + Abono.getIngresosTotales() + " €");

    }

}
