/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String telefono, tamañoPizza;
        int cantidadPizzasTotal = 0, cantidadPizzas, cantidadMedianas = 0, cantidadFamiliares = 0, extras;
        boolean correcto, salir = false;
        char ingredientePizza;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            extras = cantidadMedianas = cantidadFamiliares = 0;

            do {

                System.out.println("INTRODUZCA NÚMERO DE TELÉFONO: [0 SALIR]");
                telefono = sc.nextLine();

                correcto = validarTelefono(telefono);

                if (!correcto) {

                    if (telefono.equals("0") && cantidadPizzasTotal > 10) {

                        salir = true;

                        break;

                    } else {

                        System.out.println("NÚMERO DE TELÉFONO INVÁLIDO.");

                    }

                }

            } while (!correcto);

            if (!salir) {

                do {

                    System.out.println("¿CUANTAS PIZZAS DESEA?");
                    cantidadPizzas = sc.nextInt();

                    if (cantidadPizzas <= 0) {
                        System.out.println("CANTIDAD NO VÁLIDA.");
                    }

                } while (cantidadPizzas <= 0);

                cantidadPizzasTotal += cantidadPizzas;

                sc.nextLine(); // SE LIMPIA EL BUFFER DESPUÉS DE LEER UN NÚMERO SI A CONTINUACIÓN SE LEE UN CARÁCTER O CADENA DE CARACTERES. 

                for (int i = 1; i <= cantidadPizzas; i += 1) {

                    do {

                        System.out.println("ESCOJA TAMAÑO DE PIZZA: [MEDIANA O FAMILIAR]");
                        tamañoPizza = sc.nextLine();

                        correcto = validarPizza(tamañoPizza);

                        if (!correcto) {
                            System.out.println("TAMAÑO NO VÁLIDO.");
                        }

                    } while (!correcto);

                    if (tamañoPizza.equalsIgnoreCase("mediana")) {

                        cantidadMedianas += 1;

                    } else {

                        cantidadFamiliares += 1;

                    }

                    int cantidadIngredientes = 0;

                    do {

                        cantidadIngredientes += 1;

                        do {

                            System.out.println("ESCOJA INGREDIENTE DE PIZZA: [P/A/C/E]");
                            ingredientePizza = sc.nextLine().charAt(0);

                            ingredientePizza = Character.toUpperCase(ingredientePizza);

                            if (ingredientePizza != 'P' && ingredientePizza != 'A' && ingredientePizza != 'C' && ingredientePizza != 'E') {
                                System.out.println("INGREDIENTE NO VÁLIDO.");
                            }

                        } while (ingredientePizza != 'P' && ingredientePizza != 'A' && ingredientePizza != 'C' && ingredientePizza != 'E');

                        char otroIngrediente;

                        if (cantidadIngredientes < 4) {

                            System.out.println("¿DESEA OTRO INGREDIENTE?");
                            otroIngrediente = sc.nextLine().charAt(0);

                            if (otroIngrediente == 'N' || otroIngrediente == 'n') {
                                break;
                            }

                        }

                    } while (cantidadIngredientes < 4);

                    if (cantidadIngredientes > 2) {
                        extras = extras + (cantidadIngredientes - 2);
                    }

                }

                System.out.println("IMPORTE: " + calcularPrecio(cantidadMedianas, cantidadFamiliares, extras) + " €");

            }

        } while (!salir); // SOLO SALGO DEL BUCLE CUANDO SE INTRODUCE 0 HABIENDO VENDIDO MÁS DE 10 PIZZAS EN TOTAL. 

    }

    public static boolean validarTelefono(String telefono) {

        if (telefono.length() != 9) {
            return false;
        }

        if (telefono.charAt(0) != '9' && telefono.charAt(0) != '6') {
            return false;
        }

        for (int i = 0; i < telefono.length(); i += 1) {
            // Character.isDigit()
            if (telefono.charAt(i) < '0' || telefono.charAt(i) > '9') {
                return false;
            }
        }

        return true;

    }

    public static boolean validarPizza(String tamañoPizza) {

        if (tamañoPizza.equalsIgnoreCase("mediana") || tamañoPizza.equalsIgnoreCase("familiar")) {
            return true;
        }

        return false;

    }

    public static double calcularPrecio(int cantidadMedianas, int cantidadFamiliares, int cantidadIngredientes) {

        double precio;

        precio = (cantidadMedianas / 3) * 24 + (cantidadMedianas % 3) * 12 + (cantidadFamiliares / 2) * 28 + (cantidadFamiliares % 2) * 18 + cantidadIngredientes;

        return precio;

    }

}
