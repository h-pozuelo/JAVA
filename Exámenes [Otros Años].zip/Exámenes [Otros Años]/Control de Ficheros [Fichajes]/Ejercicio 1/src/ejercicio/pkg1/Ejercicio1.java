/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Path carpeta = crearCarpeta();
        Path fichajes = Paths.get("fichajes.txt");
        Path incidencias = crearFichero(carpeta, "incidencias");

        leerFichajes(carpeta, fichajes, incidencias);

        System.out.println(mostrarEmpleado(carpeta));

    }

    public static Path crearCarpeta() {

        String nombreCarpeta = "empleados";
        Path carpeta;

        try {

            carpeta = Paths.get(nombreCarpeta).toRealPath();

            if (!Files.isDirectory(carpeta)) { // VERIFICA QUE carpeta ES UN DIRECTORIO 

                throw new IOException(); // SI carpeta NO ES UN DIRECTORIO LANZARÁ LA EXCEPCIÓN IOException 

            }

        } catch (IOException e) { // LANZA LA EXCEPCIÓN IOException EN CASO DE QUE carpeta NO EXISTA CUANDO EJECUTAMOS EL MÉTODO .toRealPath() 

            System.out.println("EL NOMBRE DE LA CARPETA INDICADA NO EXISTE O NO ES UN DIRECTORIO. ");

            new File(nombreCarpeta).mkdir(); // Files.createDirectory(Paths.get(nombreCarpeta));

            carpeta = Paths.get(nombreCarpeta);

            System.out.println("CARPETA CREADA CON ÉXITO. ");

        }

        vaciarCarpeta(carpeta);

        return carpeta;

    }

    public static void vaciarCarpeta(Path carpeta) {

        try {

            DirectoryStream<Path> stream = Files.newDirectoryStream(carpeta);

            for (Path path : stream) {

                if (Files.isRegularFile(path) && (conExpresionRegular(path) || path.getFileName().toString().equalsIgnoreCase("incidencias.txt"))) {

                    Files.delete(path);

                }

            }

        } catch (IOException e) { // POSIBLES PROBLEMAS CON LOS PERMISOS

            System.err.format("%s: ERROR DE PERMISOS. \n", carpeta);

        }

    }

    public static boolean nombreFichero(Path fichero) {
        /*
        String nombre = fichero.getFileName().toString();
        int pos = nombre.indexOf('.');

        if (pos == -1) { // EL MÉTODO .indexOf() DEVOLVERÁ -1 SI NO ENCUENTRA EL VALOR PASADO 

            return false;

        } else {

            String n = nombre.substring(0, pos);

            if (isNumber(n) && nombre.endsWith(".txt")) {

                return true;

            } else {

                return false;

            }

        }
         */
        String nombreFichero = fichero.getFileName().toString();
        String tipo = nombreFichero.substring(nombreFichero.length() - 4, nombreFichero.length());

        if (tipo.equalsIgnoreCase(".txt")) {

            String nombre = nombreFichero.substring(0, nombreFichero.length() - 4);

            for (int i = 0; i < nombre.length(); i += 1) {

                if (!Character.isDigit(nombre.charAt(i))) {

                    return false;

                }

            }

            return true;

        }

        return false;

    }

    public static boolean conExpresionRegular(Path fichero) {

        String regex = "\\d+\\.txt";
        String nombreFichero = fichero.getFileName().toString();

        return Pattern.matches(regex, nombreFichero);

    }

    public static void leerFichajes(Path carpeta, Path fichajes, Path incidencias) throws IOException {

        int numLinea = 0;

        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/LL/yyyy");
        DateTimeFormatter formatoHora = DateTimeFormatter.ofPattern("H:m");

        Path file = fichajes.toRealPath();
        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 

        try {

            reader = Files.newBufferedReader(file, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                numLinea += 1;

                String datos[] = line.split(",");

                try {

                    LocalDate fecha = validarFecha(datos[1], formatoFecha);
                    LocalTime horaEntrada = validarHora(datos[2], formatoHora);
                    LocalTime horaSalida = validarHora(datos[3], formatoHora);

                    LocalTime jornada = validarJornada(horaEntrada, horaSalida, formatoHora);

                    String linea = "[" + fecha.format(formatoFecha) + "] " + jornada;

                    Path rutaFichero = crearFichero(carpeta, datos[0]);

                    escribirFichero(rutaFichero, linea);

                } catch (ExcepcionFecha e) {

                    escribirFichero(incidencias, "[" + numLinea + "] LA FECHA INTRODUCIDA NO ES CORRECTA. POR FAVOR, CUMPLA CON EL PATRÓN ESTABLECIDO (\"dd/LL/yyyy\").");

                } catch (ExcepcionHora e) {

                    escribirFichero(incidencias, "[" + numLinea + "] LA HORA INTRODUCIDA NO ES CORRECTA. POR FAVOR, CUMPLA CON EL PATRÓN ESTABLECIDO (\"H:m\").");

                } catch (ExcepcionJornada e) {

                    escribirFichero(incidencias, "[" + numLinea + "] LA HORA DE ENTRADA NO PUEDE SER POSTERIOR A LA HORA DE SALIDA.");

                }

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

    }

    public static LocalDate validarFecha(String dato, DateTimeFormatter formato) throws ExcepcionFecha {

        try {

            return LocalDate.parse(dato, formato);

        } catch (DateTimeParseException e) {

            throw new ExcepcionFecha();

        }

    }

    public static LocalTime validarHora(String dato, DateTimeFormatter formato) throws ExcepcionHora {

        try {

            return LocalTime.parse(dato, formato);

        } catch (DateTimeParseException e) {

            throw new ExcepcionHora();

        }

    }

    public static LocalTime validarJornada(LocalTime horaEntrada, LocalTime horaSalida, DateTimeFormatter formato) throws ExcepcionJornada {

        if (horaEntrada.isAfter(horaSalida)) {

            throw new ExcepcionJornada();

        } else {

            int horas = (int) (ChronoUnit.HOURS.between(horaEntrada, horaSalida));
            int minutos = ((int) (ChronoUnit.MINUTES.between(horaEntrada, horaSalida))) - (horas * 60);

            return LocalTime.parse(horas + ":" + minutos, formato);

        }

    }

    public static Path crearFichero(Path carpeta, String identificador) throws IOException {

        File file = new File(carpeta.toRealPath().toString() + "/" + identificador + ".txt");

        file.createNewFile();

        return file.toPath();
        /*
        Path ruta = Paths.get(carpeta.toRealPath() + "/" + identificador + ".txt");

        Files.createFile(ruta);

        return ruta;
         */
    }

    public static void escribirFichero(Path rutaFichero, String linea) { // EN newBufferedWriter CON LAS OPCIONES [CREATE] + [WRITE] + [APPEND] CREA UN FICHERO VACÍO ADEMÁS DE PERMITIR AÑADIR DATOS AL FINAL DEL FICHERO 

        Charset charset = Charset.forName("UTF-8"); // CODIFICACIÓN DEL FICHERO 
        /*
        CREAMOS UN BufferedWriter DE java.nio DE FORMA EFICIENTE UTILIZANDO Files DE java.nio 
         */
        try {
            /*
            CREA EL FICHERO SI NO EXISTE (SI EXISTE BORRA EL CONTENIDO DEL FICHERO) 
            BufferedWriter writer = Files.newBufferedWriter(file, charset);
             */
            BufferedWriter writer = Files.newBufferedWriter(rutaFichero, charset, APPEND); // [APPEND] PERMITE AÑADIR DATOS AL FINAL DEL FICHERO (SIN SOBREESCRIBIR LO ANTERIOR) 

            writer.write(linea); // VA ESCRIBIENDO SOBRE EL FICHERO LÍNEA A LÍNEA HASTA ANOTAR "FIN" 
            writer.newLine(); // SALTO DE LÍNEA PARA CUANDO PRESIONAMOS LA TECLA [ENTER] 

            writer.close();

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        }

    }

    public static String mostrarEmpleado(Path empleados) {

        int empleadoMax = -1;
        int jornadaMax = -1;

        try {

            DirectoryStream<Path> stream = Files.newDirectoryStream(empleados.toRealPath());

            for (Path path : stream) {

                if (Files.isRegularFile(path) && (conExpresionRegular(path))) {

                    int empleado = Integer.parseInt(path.getFileName().toString().substring(0, path.getFileName().toString().length() - 4));
                    int jornada = leerEmpleado(path);

                    if (jornada > jornadaMax) {

                        empleadoMax = empleado;
                        jornadaMax = jornada;

                    }

                }

            }

        } catch (IOException e) { // POSIBLES PROBLEMAS CON LOS PERMISOS

            System.err.format("%s: ERROR DE PERMISOS. \n", empleados);

        }

        return "EMPLEADO QUE MÁS TIEMPO HA TRABAJADO: "
                + "\n\tID: " + empleadoMax
                + "\n\tMINUTOS: " + jornadaMax;

    }

    public static int leerEmpleado(Path empleado) throws IOException {

        Path file = empleado.toRealPath();
        Charset charset = Charset.forName("UTF-8");
        BufferedReader reader = null; // DECLARAMOS UN BufferedReader DE java.nio 

        int jornada = 0;

        try {

            reader = Files.newBufferedReader(file, charset); // CREAMOS UN BufferedReader DE java.nio 
            String line = null;
            /*
            LA FUNCIÓN readLine() PERMITE LEER EL FICHERO DE ENTRADA LÍNEA A LÍNEA (EN VEZ DE CARACTER A CARACTER) 
            CUANDO TERMINA DE LEER EL CÓDIGO DEL FICHERO DE ENTRADA LA FUNCIÓN read() DEVUELVE -1 
             */
            while ((line = reader.readLine()) != null) {

                String datos[] = line.split(" ");

                jornada += (Integer.parseInt(datos[1].split(":")[0]) * 60) + Integer.parseInt(datos[1].split(":")[1]);

            }

        } catch (IOException x) {

            System.err.format("IOException: %s%n", x);

        } finally {

            if (reader != null) {

                reader.close();

            }

        }

        return jornada;

    }

}
