/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = new int[10];

        int numero, posicion = 0;
        char respuesta = ' ';

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            do {

                System.out.println("INTRODUZCA UN NÚMERO: ");
                numero = sc.nextInt();

                if (numero < 1 || numero > 10) {

                    System.out.println("NÚMERO NO VÁLIDO. ");

                } else if (numeros[numero - 1] != 0) {

                    System.out.println("EL NÚMERO YA HA SIDO INTRODUCIDO. ");

                } else {

                    numeros[numero - 1] = numero;

                    posicion += 1;

                }

            } while (numero < 1 || numero > 10);

            if (posicion < numeros.length) {

                sc.nextLine();

                do {

                    System.out.println("¿DESEA INTRODUCIR OTRO NÚMERO? (S/N)");
                    respuesta = sc.nextLine().charAt(0);

                    if (Character.toUpperCase(respuesta) != 'S' && Character.toUpperCase(respuesta) != 'N') {

                        System.out.println("RESPUESTA NO VÁLIDA. ");

                    }

                } while (Character.toUpperCase(respuesta) != 'S' && Character.toUpperCase(respuesta) != 'N');

            }

        } while (Character.toUpperCase(respuesta) != 'N' && posicion < numeros.length);

    }

}
