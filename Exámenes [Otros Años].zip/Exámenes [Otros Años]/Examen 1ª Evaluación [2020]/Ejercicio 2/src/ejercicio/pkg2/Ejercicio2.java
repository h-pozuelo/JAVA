/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int abrirCabina;
        char tipoVehiculo;
        double recorridoVehiculo;

        Cabina c1 = new Cabina(1);
        Cabina c2 = new Cabina(2);

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        // ABRIR O CERRAR LA CABINA 1. 
        do {

            System.out.println("¿DESEA ABRIR LA CABINA 1?");
            System.out.println("[0] NO ABRIR.");
            System.out.println("[1] SÍ ABRIR.");
            abrirCabina = sc.nextInt();

            if (abrirCabina != 0 && abrirCabina != 1) {
                System.out.println("CARÁCTER NO VÁLIDO.");
            }

        } while (abrirCabina != 0 && abrirCabina != 1);

        c1.abrirCabina(abrirCabina);

        // ABRIR O CERRAR LA CABINA 2. 
        do {

            System.out.println("¿DESEA ABRIR LA CABINA 2?");
            System.out.println("[0] NO ABRIR.");
            System.out.println("[1] SÍ ABRIR.");
            abrirCabina = sc.nextInt();

            if (abrirCabina != 0 && abrirCabina != 1) {
                System.out.println("CARÁCTER NO VÁLIDO.");
            }

        } while (abrirCabina != 0 && abrirCabina != 1);

        c2.abrirCabina(abrirCabina);

        // PAGAR VEHÍCULO EN CABINA 1. 
        if (c1.isCabinaOperativa() == false) {

            System.out.println("CABINA NO OPERATIVA.");

        } else {

            sc.nextLine();

            char respuesta;

            do {

                do {

                    System.out.println("INTRODUZCA TIPO DE VEHÍCULO: ");
                    tipoVehiculo = sc.nextLine().charAt(0);

                    tipoVehiculo = Character.toUpperCase(tipoVehiculo);

                    if (tipoVehiculo != 'A' && tipoVehiculo != 'C' && tipoVehiculo != 'M') {
                        System.out.println("TIPO DE VEHÍCULO NO VÁLIDO.");
                    }

                } while (tipoVehiculo != 'A' && tipoVehiculo != 'C' && tipoVehiculo != 'M');

                do {

                    System.out.println("INTRODUZCA KILÓMETROS RECORRIDOS: ");
                    recorridoVehiculo = sc.nextDouble();

                    if (recorridoVehiculo <= 0) {
                        System.out.println("CANTIDAD NO VÁLIDA.");
                    }

                } while (recorridoVehiculo <= 0);

                System.out.println("IMPORTE TOTAL: " + c1.pagarVehiculo(tipoVehiculo, recorridoVehiculo) + " €");

                sc.nextLine();

                do {

                    System.out.println("¿DESEA SEGUIR OPERANDO?");
                    respuesta = sc.nextLine().charAt(0);

                    respuesta = Character.toUpperCase(respuesta);

                    if (respuesta != 'S' && respuesta != 'N') {
                        System.out.println("CARÁCTER NO VÁLIDO.");
                    }

                } while (respuesta != 'S' && respuesta != 'N');

            } while (respuesta != 'N');

        }

        // PAGAR VEHÍCULO EN CABINA 2. 
        if (c2.isCabinaOperativa() == false) {

            System.out.println("CABINA NO OPERATIVA.");

        } else {

            char respuesta;

            do {

                do {

                    System.out.println("INTRODUZCA TIPO DE VEHÍCULO: ");
                    tipoVehiculo = sc.nextLine().charAt(0);

                    tipoVehiculo = Character.toUpperCase(tipoVehiculo);

                    if (tipoVehiculo != 'A' && tipoVehiculo != 'C' && tipoVehiculo != 'M') {
                        System.out.println("TIPO DE VEHÍCULO NO VÁLIDO.");
                    }

                } while (tipoVehiculo != 'A' && tipoVehiculo != 'C' && tipoVehiculo != 'M');

                do {

                    System.out.println("INTRODUZCA KILÓMETROS RECORRIDOS: ");
                    recorridoVehiculo = sc.nextDouble();

                    if (recorridoVehiculo <= 0) {
                        System.out.println("CANTIDAD NO VÁLIDA.");
                    }

                } while (recorridoVehiculo <= 0);

                System.out.println("IMPORTE TOTAL: " + c2.pagarVehiculo(tipoVehiculo, recorridoVehiculo) + " €");

                sc.nextLine();

                do {

                    System.out.println("¿DESEA SEGUIR OPERANDO?");
                    respuesta = sc.nextLine().charAt(0);

                    respuesta = Character.toUpperCase(respuesta);

                    if (respuesta != 'S' && respuesta != 'N') {
                        System.out.println("CARÁCTER NO VÁLIDO.");
                    }

                } while (respuesta != 'S' && respuesta != 'N');

            } while (respuesta != 'N');

        }

        // ABRIR O CERRAR LA CABINA 1. 
        do {

            System.out.println("¿DESEA ABRIR LA CABINA 1?");
            System.out.println("[0] NO ABRIR.");
            System.out.println("[1] SÍ ABRIR.");
            abrirCabina = sc.nextInt();

            if (abrirCabina != 0 && abrirCabina != 1) {
                System.out.println("CARÁCTER NO VÁLIDO.");
            }

        } while (abrirCabina != 0 && abrirCabina != 1);

        c1.abrirCabina(abrirCabina);

        // ABRIR O CERRAR LA CABINA 2. 
        do {

            System.out.println("¿DESEA ABRIR LA CABINA 2?");
            System.out.println("[0] NO ABRIR.");
            System.out.println("[1] SÍ ABRIR.");
            abrirCabina = sc.nextInt();

            if (abrirCabina != 0 && abrirCabina != 1) {
                System.out.println("CARÁCTER NO VÁLIDO.");
            }

        } while (abrirCabina != 0 && abrirCabina != 1);

        c2.abrirCabina(abrirCabina);

        // MOSTRAR CUANTAS CABINAS ESTÁN OPERATIVAS. 
        System.out.println("CANTIDAD DE CABINAS OPERATIVAS: " + Cabina.getTotalCabinaOperativa());

        // MOSTRAR INFORMACIÓN DE LA CABINA 1. 
        System.out.println(c1.toString());

        // MOSTRAR INFORMACIÓN DE LA CABINA 2. 
        System.out.println(c2.toString());

        // MOSTRAR LA CABINA QUE MAYOR TRÁFICO HA TENIDO. 
        switch (c1.mayorTrafico()) {

            case 0:
                System.out.println("TANTO LA CABINA 1 COMO LA CABINA 2 HAN TENIDO EL MISMO TRÁFICO.");
                break;

            case 1:
                System.out.println("LA CABINA 1 HA TENIDO MÁS TRÁFICO QUE LA CABINA 2.");
                break;

            case 2:
                System.out.println("LA CABINA 2 HA TENIDO MÁS TRÁFICO QUE LA CABINA 1.");
                break;

        }

    }

}
