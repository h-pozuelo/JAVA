/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Cabina {

    private int numeroCabina;
    private double importeRecaudado;
    private boolean cabinaOperativa = false;
    private int vehiculosCabina;
    private static int totalCabinaOperativa;
    private static int totalVehiculosCabina;

    public Cabina(int numeroCabina) {
        this.numeroCabina = numeroCabina;
    }

    public double pagarVehiculo(char tipoVehiculo, double recorridoVehiculo) {

        if (cabinaOperativa != false) {

            totalVehiculosCabina += 1;

            vehiculosCabina += 1;

            switch (tipoVehiculo) {

                case 'A':
                    importeRecaudado += 0.2 * recorridoVehiculo;
                    return 0.2 * recorridoVehiculo;

                case 'C':
                    importeRecaudado += 5 * recorridoVehiculo;
                    return 5 * recorridoVehiculo;

                case 'M':
                    importeRecaudado += 0.1 * recorridoVehiculo;
                    return 0.1 * recorridoVehiculo;

            }

        }

        return 0;

    }

    public boolean isCabinaOperativa() {
        return cabinaOperativa;
    }

    public void abrirCabina(int abrirCabina) {

        if (abrirCabina == 0) {

            if (cabinaOperativa == false) {

                System.out.println("LA CABINA SE ENCUENTRA ACTUALMENTE CERRADA.");

            } else {

                cabinaOperativa = false;

                System.out.println("LA CABINA SE HA CERRADO.");

                totalVehiculosCabina = 0;

                totalCabinaOperativa -= 1;

            }

        } else {

            if (cabinaOperativa == true) {

                System.out.println("LA CABINA SE ENCUENTRA ACTUALMENTE ABIERTA.");

            } else {

                cabinaOperativa = true;

                System.out.println("LA CABINA SE HA ABIERTO.");

                totalCabinaOperativa += 1;

            }

        }

    }

    public static int getTotalCabinaOperativa() {
        return totalCabinaOperativa;
    }

    @Override
    public String toString() {
        return "Cabina{" + "numeroCabina=" + numeroCabina + ", importeRecaudado=" + importeRecaudado + ", cabinaOperativa=" + cabinaOperativa + ", vehiculosCabina=" + vehiculosCabina + '}';
    }

    public int mayorTrafico() {

        if (totalVehiculosCabina - vehiculosCabina > vehiculosCabina) {
            return 2;
        }

        if (totalVehiculosCabina - vehiculosCabina < vehiculosCabina) {
            return 1;
        }

        return 0;

    }

}
