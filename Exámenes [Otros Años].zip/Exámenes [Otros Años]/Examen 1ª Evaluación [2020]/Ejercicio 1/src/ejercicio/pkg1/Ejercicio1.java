/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int alumnosCount = 0;
        String codigoAlumno, valoracionDocente;
        double nota;
        boolean entornoDesfavorecido, respuesta = false;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            alumnosCount += 1;

            do {

                System.out.println("INTRODUZCA CÓDIGO DE ALUMNO: ");
                codigoAlumno = sc.nextLine();

                if (!validarCodigoAlumno(codigoAlumno)) {
                    System.out.println("CÓDIGO DE ALUMNO NO VÁLIDO.");
                }

            } while (!validarCodigoAlumno(codigoAlumno));

            do {

                System.out.println("INTRODUZCA NOTA DEL CURSO: ");
                nota = sc.nextDouble();

                if (!validarNota(nota)) {
                    System.out.println("NOTA DEL CURSO NO VÁLIDA.");
                }

            } while (!validarNota(nota));

            sc.nextLine();

            if (!notaNoApta(nota)) {

                do {

                    System.out.println("INTRODUZCA VALORACIÓN DEL EQUIPO DOCENTE: ");
                    System.out.println("(1) NEGATIVA");
                    System.out.println("(2) POSITIVA");
                    System.out.println("(3) NORMAL");
                    valoracionDocente = sc.nextLine();

                } while (valoracionDocenteNoApta(valoracionDocente) == 2);

                if (valoracionDocenteNoApta(valoracionDocente) != 1) {

                    System.out.println("¿PROVIENE EL ALUMNO DE UN ENTORNO DESFAVORECIDO?");
                    System.out.println("[false] NO");
                    System.out.println("[true] SÍ");
                    entornoDesfavorecido = sc.nextBoolean();

                }

            }

            if (alumnosCount != 4) {

                System.out.println("¿DESEA AÑADIR OTRO ALUMNO?");
                System.out.println("[false] NO");
                System.out.println("[true] SÍ");
                respuesta = sc.nextBoolean();

            }

        } while (respuesta && alumnosCount < 4);

    }

    public static boolean validarCodigoAlumno(String codigoAlumno) {

        // VALIDAR LA LONGITUD DE LA CADENA DE CARACTERES. 
        if (codigoAlumno.length() != 6) {
            return false;
        }

        // VALIDAR QUE EL PRIMER CARACTER SEA UNA LETRA. 
        char letra = Character.toUpperCase(codigoAlumno.charAt(0));

        if ((letra < 'A' || letra > 'Z') && letra != 'Ñ') {
            return false;
        }
        /*
        if (!Character.isLetter(letra)) {
            return false;
        }
         */
        // VALIDAR QUE EL SEGUNDO CARACTER SEA UN GUIÓN. 
        char guion = codigoAlumno.charAt(1);

        if (guion != '-') {
            return false;
        }

        // VALIDAR QUE LOS CUATRO ÚLTIMOS CARACTERES SEAN NÚMEROS. 
        for (int i = 2; i <= codigoAlumno.length() - 1; i++) {

            char numero = codigoAlumno.charAt(i);

            if (numero < '0' || numero > '9') {
                return false;
            }

        }

        return true;

    }

    public static boolean validarNota(double nota) {

        if (nota < 0 || nota > 10) {
            return false;
        }

        return true;

    }

    public static boolean notaNoApta(double nota) {
        return nota < 5;
    }

    public static int valoracionDocenteNoApta(String valoracionDocente) {

        switch (valoracionDocente.toUpperCase()) {

            case "POSITIVA":
                return 0;

            case "NEGATIVA":
                return 1;

            case "NORMAL":
                return 0;

        }

        System.out.println("POR FAVOR INTRODUZCA UNA DE LAS OPCIONES DISPONIBLES.");

        return 2;

    }

    public static double calcularPuntos() {

    }

}
