/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import bbdd.BD_Transportes;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;
import modelos.Abono;
import modelos.AbonoMensual;
import modelos.AbonoNormal;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static Vector<Abono> abonos;
    static BD_Transportes bd = new BD_Transportes("transportes");
    static Scanner sc = new Scanner(System.in);
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {

            abonos = bd.obtenerAbonos();

            do {

                for (int i = 0; i < abonos.size(); i += 1) {

                    System.out.println(abonos.get(i).toString());

                }

                opcion = menu();

                switch (opcion) {

                    case 1:
                        
                        try {

                        int posicion = leerNumeroAbono();

                        System.out.println("EL NÚMERO DE ABONO INTRODUCIDO SE ENCUENTRA EN LA POSICIÓN [" + posicion + "] DEL VECTOR. ");

                        if (abonos.get(posicion).realizarViaje()) {

                            if (abonos.get(posicion) instanceof AbonoMensual) {

                                System.out.println("FECHA DE CADUCIDAD: " + abonos.get(posicion).getFecha());

                            } else {

                                System.out.println("VIAJES RESTANTES: " + abonos.get(posicion).getViajes());

                            }

                        } else {

                            System.out.println("NO LE QUEDA NINGÚN VIAJE RESTANTE. ");

                            boolean quit = false;

                            while (!quit) {

                                System.out.println("¿DESEA CARGAR LOS VIAJES DEL ABONO?"
                                        + "\n\t1. SÍ "
                                        + "\n\t2. NO ");
                                int respuesta = sc.nextInt();

                                if (respuesta < 1 || respuesta > 2) {

                                    System.out.println("LA OPCIÓN INDICADA NO ES VÁLIDA. ");

                                } else if (respuesta == 1) {

                                    double importe = 0;

                                    if (abonos.get(posicion) instanceof AbonoMensual) {

                                        switch (((AbonoMensual) (abonos.get(posicion))).getUsuario().getFamiliaNumerosa()) {

                                            case 0:

                                                importe = 30;

                                                break;

                                            case 1:

                                                importe = 20;

                                                break;

                                            case 2:

                                                importe = 10;

                                                break;

                                        }

                                    } else {

                                        int viajes;

                                        do {

                                            System.out.println("¿CUANTOS VIAJES DESEA CARGAR EN EL ABONO?");
                                            viajes = sc.nextInt();

                                            if (viajes % 10 != 0) {

                                                System.out.println("LA CANTIDAD DE VIAJES DEBE SER MÚLTIPLO DE 10. ");

                                            }

                                        } while (viajes % 10 != 0);

                                        importe = (viajes / 10) * 12;

                                    }

                                    System.out.println("IMPORTE TOTAL: " + abonos.get(posicion).cargar(importe) + " €");

                                    quit = true;

                                } else {

                                    quit = true;

                                }

                            }

                        }

                    } catch (ErrorLeyendoAbono x) {

                        System.out.println(x.getMessage());

                    }

                    break;

                    case 2:
                        break;

                }

            } while (opcion != 3);

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. BUSCAR ABONO POR NÚMERO DE ABONO "
                    + "\n\t2. BORRAR ABONOS SIN CARGAR "
                    + "\n\t3. CERRAR EL PROGRAMA ");

            try {

                opcion = sc.nextInt();

                if (opcion < 1 || opcion > 3) {

                    System.out.println("LA OPCIÓN INDICADA NO ES VÁLIDA. ");

                }

            } catch (InputMismatchException e) {

                opcion = 0;

                System.out.println("DEBES INDICAR UN NÚMERO ENTRE [ 1 - 3 ]. ");

                sc.nextLine();

            }

        } while (opcion < 1 || opcion > 3);

        return opcion;

    }

    public static int leerNumeroAbono() throws ErrorLeyendoAbono {

        for (int intentos = 0; intentos < 3; intentos += 1) {

            System.out.println("INTRODUZCA UN NÚMERO DE ABONO: ");
            int numero = sc.nextInt();

            for (int i = 0; i < abonos.size(); i += 1) {

                if (abonos.get(i).getNumero() == numero) {

                    return i;

                }

            }

            System.out.println("EL NÚMERO DE ABONO INTRODUCIDO NO SE ENCUENTRA EN EL VECTOR. ");

        }

        throw new ErrorLeyendoAbono("NÚMERO DE INTENTOS MÁXIMOS ALCANZADO. ");

    }

}
