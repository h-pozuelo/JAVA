/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public class AbonoMensual extends Abono {

    double gastadoEspeciales;

    public AbonoMensual(int numero, LocalDate fecha, Usuario usuario) {
        super(numero, fecha, 0, usuario);
    }

    public boolean realizarViaje() {

        return LocalDate.now().isBefore(fecha.plusMonths(1));

    }

    public double cargar(double importe) {

        this.fecha = LocalDate.now();

        if (this.usuario.getFamiliaNumerosa() != 0) {

            this.gastadoEspeciales += importe;

        }

        this.gastado += importe;

        return importe;

    }

    @Override
    public String toString() {
        return super.toString() + "AbonoMensual{" + "gastadoEspeciales=" + gastadoEspeciales + '}';
    }

}
