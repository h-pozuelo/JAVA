/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public abstract class Abono {

    private int numero;
    protected LocalDate fecha; // ESTA VARIABLE DETERMINA CUANDO FUE REALIZADA LA ÚLTIMA CARGA DEL ABONO. 
    protected int viajes;
    protected Usuario usuario;
    protected double gastado; // ESTA VARIABLE DETERMINA EL IMPORTE TOTAL DE TODAS LAS RECARGAS REALIZADAS. 

    public Abono(int numero, LocalDate fecha, int viajes, Usuario usuario) {
        this.numero = numero;
        this.fecha = fecha;
        this.viajes = viajes;
        this.usuario = usuario;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public int getViajes() {
        return viajes;
    }

    public void setViajes(int viajes) {
        this.viajes = viajes;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public double getGastado() {
        return gastado;
    }

    public void setGastado(double gastado) {
        this.gastado = gastado;
    }

    public abstract boolean realizarViaje();

    public double cargar(double importe) {

        this.fecha = LocalDate.now();

        this.viajes = (int) (importe / 12) * 10;

        this.gastado += importe;

        return importe;

    }

    @Override
    public String toString() {
        return "Abono{" + "numero=" + numero + ", fecha=" + fecha + ", viajes=" + viajes + ", usuario=" + usuario + ", gastado=" + gastado + '}';
    }

}
