/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public class AbonoNormal extends Abono {

    public AbonoNormal(int numero, LocalDate fecha, int viajes) {
        super(numero, fecha, viajes, null);
    }

    public boolean realizarViaje() {

        if (viajes > 0) {

            viajes -= 1;

            return true;

        }

        return false;

    }

}
