/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public class CargaAbono {

    /*
    private int numero; // NO NECESITO LLEVAR EL NÚMERO DADO QUE SE AUTOINCREMENTA EN LA BASE DE DATOS (CON ENVIAR LUEGO A LA BASE DE DATOS UN 0 BASTARÍA). 
     */
    private int bono;
    private LocalDate fecha;
    private double importe;
    private char tipo; // ESTA VARIABLE ME SIRVE PARA IDENTIFICAR EL TIPO DE ABONO QUE HA REALIZADO LA CARGA. 

    public CargaAbono(int bono, LocalDate fecha, double importe, char tipo) {
        this.bono = bono;
        this.fecha = fecha;
        this.importe = importe;
        this.tipo = tipo;
    }

    /*
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
     */
    public int getBono() {
        return bono;
    }

    public void setBono(int bono) {
        this.bono = bono;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public double getImporte() {
        return importe;
    }

    public void setImporte(double importe) {
        this.importe = importe;
    }

    public char getTipo() {
        return tipo;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "CargaAbono{" + "bono=" + bono + ", fecha=" + fecha + ", importe=" + importe + ", tipo=" + tipo + '}';
    }

}
