/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.util.Comparator;

/**
 *
 * @author Hugo
 */
public class AbonoPorFecha implements Comparator<CargaAbono> {

    @Override
    public int compare(CargaAbono arg0, CargaAbono arg1) {

        if (arg0.getFecha().equals(arg1.getFecha())) {

            if (arg0.getImporte() == arg1.getImporte()) {

                return 0;

            } else if (arg0.getImporte() > arg1.getImporte()) {

                return 1;

            } else {

                return -1;

            }

        }

        return arg0.getFecha().compareTo(arg1.getFecha());

    }

}
