/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

/*
PASOS A REALIZAR PARA CONECTARSE A UNA BASE DE DATOS (MYSQL): 
    1. EN PHPMYADMIN CREAMOS UNA BASE DE DATOS (MYSQL) VACÍA E IMPORTAMOS EL FICHERO SQL QUE CONTIENE LAS TABLAS [PESTAÑA "SQL"] 
    2. CUANDO CONSTRUIMOS UN OBJETO BBDD EN LA CLASE PRINCIPAL DEBEMOS DE INDICAR EL NOMBRE DE LA BASE DE DATOS (MYSQL) CREADA PREVIAMENTE 
    3. CREAMOS UNA CARPETA (lib) EN EL PROYECTO JAVA EN DONDE ALMACENAREMOS LA LIBRERÍA "mysql-connector-java-8.0.28.jar" 
    4. DESDE LAS PROPIEDADES DEL PROYECTO JAVA DEBEMOS DE IMPORTAR EL FICHERO JAR PARA PODER CARGAR LA LIBRERÍA 
    5. CUANDO ABRIMOS LA CONEXIÓN CON LA BASE DE DATOS (MYSQL) DEBEMOS DE UTILIZAR EL SIGUIENTE CONTROLADOR Class.forName("com.mysql.cj.jdbc.Driver") 
 */
import java.sql.*;

/**
 *
 * @author Hugo
 */
public class BD_Conector {

    private String base;
    private String usuario;
    private String pass;
    private String url;
    protected Connection c;

    public BD_Conector(String bbdd) { // CONSTRUYE UNA CONEXIÓN CON LA BASE DE DATOS (MYSQL) QUE COINCIDE CON EL NOMBRE DE BBDD QUE LE HEMOS PASADO 
        this.base = bbdd;
        this.usuario = "root";
        this.pass = "";
        this.url = "jdbc:mysql://localhost/" + this.base;
    }

    public void abrir() {

        try {
            /*
            Class.forName("com.mysql.jdbc.Driver"); // CONTROLADOR OBSOLETO (NO UTILIZAR) 
             */
            Class.forName("com.mysql.cj.jdbc.Driver"); // CONTROLADOR MODERNO 

        } catch (ClassNotFoundException e) {

            System.out.println(e.getMessage());

        }

        try {

            this.c = DriverManager.getConnection(this.url, this.usuario, this.pass);

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }

    }

    public void cerrar() {

        try {

            this.c.close();

        } catch (SQLException e) {

            System.out.println(e.getMessage());

        }

    }

}
