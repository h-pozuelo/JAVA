/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.*;
import ejercicio.pkg1.*;
import modelos.Abono;
import modelos.AbonoMensual;
import modelos.AbonoNormal;
import modelos.CargaAbono;
import modelos.Usuario;

/**
 *
 * @author Hugo
 */
public class BD_Transportes extends BD_Conector {

    private static Statement s;
    private static ResultSet reg;
    private static PreparedStatement ps;

    public BD_Transportes(String file) {
        super(file);
    }

    public Vector<Abono> obtenerAbonos() throws ErrorBaseDatos {

        Vector<Abono> abonos = new Vector<Abono>();

        String cadenaSQL = "SELECT * FROM abonos";

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                if (reg.getString("nif") == null) {
                    abonos.add(new AbonoNormal(reg.getInt("numero"), reg.getDate("fecha").toLocalDate(), reg.getInt("viajes")));
                } else {
                    abonos.add(new AbonoMensual(reg.getInt("numero"), reg.getDate("fecha").toLocalDate(), obtenerUsuario(reg.getString("nif"))));
                }
            }
            s.close();
            this.cerrar();
            return abonos;

        } catch (SQLException e) {

            throw new ErrorBaseDatos("NO ES POSIBLE OBTENER LOS ABONOS. ");

        }

    }

    public Usuario obtenerUsuario(String nif) throws ErrorBaseDatos {

        Usuario usuario = null;

        String cadenaSQL = "SELECT * FROM usuarios WHERE nif=?";

        try {

            this.abrir();
            ps = c.prepareStatement(cadenaSQL);
            ps.setString(1, nif);
            ResultSet reg = ps.executeQuery(); // AL VOLVER A DECLARAR LA VARIABLE 'reg' SI QUISIERA ACCEDER A LA VARIABLE ESTÁTICA DECLARADA EN EL COMIENZO DEBO LLAMARLA DE LA SIGUIENTE MANERA 'this.reg' 
            if (reg.next()) {
                usuario = new Usuario(reg.getString("nif"), reg.getString("nombre"), reg.getString("apellido"), reg.getDate("fechanacimiento").toLocalDate(), reg.getInt("familianumerosa"));
            }
            ps.close();
            this.cerrar();
            return usuario;

        } catch (SQLException e) {

            throw new ErrorBaseDatos("NO ES POSIBLE OBTENER EL USUARIO. ");

        }

    }

}
