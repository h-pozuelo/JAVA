-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 17-05-2021 a las 22:17:18
-- Versión del servidor: 5.5.24-log
-- Versión de PHP: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `transportes`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `abonos`
--

CREATE TABLE IF NOT EXISTS `abonos` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `viajes` int(11) NOT NULL,
  `nif` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `nif` (`nif`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcado de datos para la tabla `abonos`
--

INSERT INTO `abonos` (`numero`, `fecha`, `viajes`, `nif`) VALUES
(1, '2021-05-16', 0, '432345M'),
(2, '2021-05-16', 19, NULL),
(3, '2021-06-25', 0, '12121212J'),
(4, '2021-05-24', 5, NULL),
(5, '2021-06-22', 0, '11111H'),
(7, '2019-05-24', 40, NULL),
(9, '2019-06-25', 0, '23T');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cargasabonos`
--

CREATE TABLE IF NOT EXISTS `cargasabonos` (
  `numero` int(11) NOT NULL AUTO_INCREMENT,
  `bono` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `importe` double NOT NULL,
  PRIMARY KEY (`numero`),
  KEY `bono` (`bono`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Volcado de datos para la tabla `cargasabonos`
--

INSERT INTO `cargasabonos` (`numero`, `bono`, `fecha`, `importe`) VALUES
(1, 3, '2021-05-01', 10),
(2, 1, '2021-05-14', 20),
(3, 1, '2021-03-10', 20),
(4, 5, '2021-04-07', 24),
(5, 4, '2021-04-15', 10),
(6, 3, '2021-01-15', 10),
(7, 2, '2021-03-10', 12),
(8, 4, '2021-04-18', 30),
(9, 7, '2021-05-22', 12),
(10, 5, '2021-05-22', 30),
(12, 7, '2021-05-25', 36);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `nif` varchar(10) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) NOT NULL,
  `fechanacimiento` date NOT NULL,
  `familianumerosa` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`nif`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`nif`, `nombre`, `apellido`, `fechanacimiento`, `familianumerosa`) VALUES
('11111H', 'Andrés', 'García', '1990-05-26', 0),
('12121212J', 'Lourdes', 'Quiziada', '2003-05-02', 2),
('23T', 'Pedro', 'Marmol', '2001-12-12', 2),
('432345M', 'Julia', 'López', '2000-05-12', 1);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `abonos`
--
ALTER TABLE `abonos`
  ADD CONSTRAINT `abonos_ibfk_1` FOREIGN KEY (`nif`) REFERENCES `usuarios` (`nif`);

--
-- Filtros para la tabla `cargasabonos`
--
ALTER TABLE `cargasabonos`
  ADD CONSTRAINT `cargasabonos_ibfk_1` FOREIGN KEY (`bono`) REFERENCES `abonos` (`numero`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
