/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;
import static java.nio.file.StandardOpenOption.WRITE;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static int opcion; // SI NO SE ESPECIFICA SU VALOR ES CERO POR DEFECTO 

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        int carpetaEncontrada = -1;
        String nombreCarpeta = "";

        while (carpetaEncontrada != 0) {

            System.out.println("INDIQUE NOMBRE DE LA CARPETA: ");
            nombreCarpeta = sc.nextLine();

            carpetaEncontrada = buscarCarpeta(nombreCarpeta);

            switch (carpetaEncontrada) {

                case -1:

                    System.out.println("NO EXISTE LA RUTA INDICADA. ");

                    break;

                case 1:

                    System.out.println("LA RUTA INDICADA NO CORRESPONDE A UNA CARPETA. ");

                    break;

            }

        }

        while (opcion != 4) {

            opcion = menu();

            switch (opcion) {

                case 1:

                    String nombreFichero;
                    boolean coincide;

                    do {

                        System.out.println("INDIQUE NOMBRE DEL FICHERO A CREAR: (CON LA EXTENSIÓN DE FICHERO \".log\") ");
                        nombreFichero = sc.nextLine();

                        coincide = Pattern.matches("[^\\<\\>\\:\\\"\\/\\\\\\|\\?\\!\\*]+\\.log", nombreFichero);

                        if (!coincide) {

                            System.out.println("EL NOMBRE DEL FICHERO INDICADO NO CUMPLE CON LOS CRITERIOS ESTABLECIDOS. "
                                    + "\nNO INTRODUZCA NINGUNO DE LOS SIGUIENTES CARACTERES: "
                                    + "\n\t· < "
                                    + "\n\t· > "
                                    + "\n\t· : "
                                    + "\n\t· \" "
                                    + "\n\t· / "
                                    + "\n\t· \\ "
                                    + "\n\t· | "
                                    + "\n\t· ? "
                                    + "\n\t· ! "
                                    + "\n\t· * ");

                        }

                    } while (!coincide); // EL SÍMBOLO + DE LA EXPRESIÓN REGULAR INDICA QUE DEBE REPETIRSE AL MENOS 1 VEZ EL CARACTER ANTERIOR 

                    Path rutaFichero = Paths.get(nombreCarpeta, nombreFichero); // ES EQUIVALENTE PONER Paths.get(nombreCarpeta, nombreFichero) A Paths.get(nombreCarpeta + "/" + nombreFichero) 

                    BufferedWriter writer = null;
                    Charset charset = Charset.forName("UTF-8");

                    String fechaIncidencia = "";
                    String codigoError;
                    String nombreUsuario;

                    DateTimeFormatter patron = DateTimeFormatter.ofPattern("dd-LL-yyyy");

                    try {

                        writer = Files.newBufferedWriter(rutaFichero, charset, CREATE, WRITE, APPEND); // [CREATE] + [WRITE] CREA UN FICHERO EN CASO DE QUE NO EXISTA [APPEND] PERMITE CONTINUAR ESCRIBIENDO AL FINAR DEL FICHERO 

                        boolean quit = false;

                        while (!quit) {

                            System.out.println("¿FECHA DE LA INCIDENCIA?");
                            fechaIncidencia = sc.nextLine();

                            try {

                                LocalDate.parse(fechaIncidencia, patron);

                                quit = true;

                            } catch (DateTimeException x) {

                                System.out.println("LA FECHA INDICADA NO CUMPLE CON LOS CRITERIOS ESTABLECIDOS. "
                                        + "\nDEBE INTRODUCIR UNA FECHA CON EL FORMATO \"dd-LL-yyyy\". ");

                            }

                        }

                        do {

                            System.out.println("¿CÓDIGO DE ERROR?");
                            codigoError = sc.nextLine();

                            if (!Pattern.matches("[^\\ ]+", codigoError)) {

                                System.out.println("EL CÓDIGO DE ERROR NO PUEDE CONTENER ESPACIOS. ");

                            }

                        } while (!Pattern.matches("[^\\ ]+", codigoError));

                        do {

                            System.out.println("¿NOMBRE DE USUARIO?");
                            nombreUsuario = sc.nextLine();

                            if (!Pattern.matches("[^\\ ]+", nombreUsuario)) {

                                System.out.println("EL CÓDIGO DE ERROR NO PUEDE CONTENER ESPACIOS. ");

                            }

                        } while (!Pattern.matches("[^\\ ]+", nombreUsuario));

                        writer.write(fechaIncidencia + " " + codigoError + " " + nombreUsuario);

                        writer.newLine();

                        writer.close();

                    } catch (IOException e) {

                        System.out.format("IOException: %s%n", e);

                    }

                    break;

                case 2: // [CREATE] + [WRITE] CREA UN FICHERO EN CASO DE QUE NO EXISTA Y SI EXISTE VACÍA SU CONTENIDO 

                    break;

                case 3:

                    break;

            }

        }

    }

    public static int buscarCarpeta(String nombre) {

        try {

            Path carpeta = Paths.get(nombre).toRealPath();

            if (Files.isDirectory(carpeta)) {

                System.out.println(carpeta.toString());

                return 0;

            } else {

                return 1;

            }

        } catch (IOException e) {

            return -1;

        }

    }

    public static int menu() {

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. "
                    + "\n\t2. "
                    + "\n\t3. "
                    + "\n\t4. ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 4) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 4);

        return opcion;

    }

}
