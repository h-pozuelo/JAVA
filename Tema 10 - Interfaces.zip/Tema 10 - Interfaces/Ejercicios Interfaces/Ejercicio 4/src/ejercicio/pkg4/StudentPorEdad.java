/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

import java.util.Comparator;

/**
 *
 * @author Hugo
 */
public class StudentPorEdad implements Comparator<Student> { // CLASE PUENTE [IMPLEMENTA LA CLASE Comparator] 

    @Override
    public int compare(Student arg0, Student arg1) {
        // TODO Auto-generated method stub
        if (arg0.getAge() == arg1.getAge()) {
            return 0;
        } else if (arg0.getAge() < arg1.getAge()) {
            return -1;
        } else {
            return 1;
        }
    }

}
