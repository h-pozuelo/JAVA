/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // ArrayList<Student> al=new ArrayList<Student>();
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("dd-LL-yyyy");
        Vector<Student> al = new Vector();

        al.add(new Student(101, "Luis", 23, LocalDate.parse("30-03-2021", patron)));
        al.add(new Student(106, "Gemma", 27, LocalDate.parse("14-02-2021", patron)));
        al.add(new Student(105, "Pedro", 21, LocalDate.parse("31-05-2021", patron)));

        Collections.sort(al, new StudentPorNombre());

        System.out.println("ORDENACIÓN POR NOMBRE: ");

        for (Student st : al) {

            System.out.println(st);

        }

        Collections.sort(al, new StudentPorEdad());

        System.out.println("ORDENACIÓN POR EDAD: ");

        for (Student st : al) {

            System.out.println(st);

        }

        Collections.sort(al, new StudentPorFechaIncorporacion());

        System.out.println("ORDENACIÓN POR FECHA DE INCORPORACIÓN: ");

        for (Student st : al) {

            System.out.println(st);

        }

    }

}
