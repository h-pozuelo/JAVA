/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double[] numeros = {48, 57, 128, -26, 29, 0, -128, 66, 95, 11};
        Estadisticas estadistica = new Lista(numeros);

        System.out.println("----------------------------------------");
        System.out.println("MÍNIMO: " + estadistica.minimo());
        System.out.println("----------------------------------------");
        System.out.println("MÁXIMO: " + estadistica.maximo());
        System.out.println("----------------------------------------");
        System.out.println("SUMATORIO: " + estadistica.sumatorio());
        System.out.println("----------------------------------------");

    }

}
