/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Lista implements Estadisticas {

    private double[] numeros;

    public Lista(double[] numeros) {
        this.numeros = numeros;
    }

    public double minimo() {

        double minimo = Double.MAX_VALUE;

        for (int i = 0; i < numeros.length; i += 1) {

            if (numeros[i] < minimo) {

                minimo = numeros[i];

            }

        }

        return minimo;

    }

    public double maximo() {

        double maximo = Double.MIN_VALUE;

        for (int i = 0; i < numeros.length; i += 1) {

            if (numeros[i] > maximo) {

                maximo = numeros[i];

            }

        }

        return maximo;

    }

    public double sumatorio() {

        double sumatorio = 0;

        for (int i = 0; i < numeros.length; i += 1) {

            sumatorio += numeros[i];

        }

        return sumatorio;

    }

}
