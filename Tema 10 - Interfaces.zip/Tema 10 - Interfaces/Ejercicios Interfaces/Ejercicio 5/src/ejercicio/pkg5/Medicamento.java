/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg5;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Hugo
 */
public class Medicamento implements Caducable {

    private String nombre;
    private double precio;
    private LocalDate fechaCaducidad;

    public Medicamento(String nombre, double precio, LocalDate fechaCaducidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.fechaCaducidad = fechaCaducidad;
    }

    public boolean caducado() {

        return !this.fechaCaducidad.isAfter(LocalDate.now());

    }

    public int diasRestantes() {

        return (int) ChronoUnit.DAYS.between(LocalDate.now(), fechaCaducidad);

    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public LocalDate getFechaCaducidad() {
        return fechaCaducidad;
    }

    @Override
    public String toString() {
        return "Medicamento{" + "nombre=" + nombre + ", precio=" + precio + ", fechaCaducidad=" + fechaCaducidad + '}';
    }

}
