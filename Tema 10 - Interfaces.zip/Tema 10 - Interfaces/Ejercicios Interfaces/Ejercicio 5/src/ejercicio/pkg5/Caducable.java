/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg5;

/**
 *
 * @author Hugo
 */
public interface Caducable {

    public boolean caducado();

    public int diasRestantes();

}
