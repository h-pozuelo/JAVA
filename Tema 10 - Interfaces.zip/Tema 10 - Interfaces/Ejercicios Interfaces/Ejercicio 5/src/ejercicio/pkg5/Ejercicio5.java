/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg5;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("dd-LL-yyyy");
        Vector<Caducable> contenedor = new Vector<Caducable>();

        contenedor.add(new Carnet("13712269Z", "JAVIER RODRIGUEZ VALVERDE", LocalDate.parse("31-05-2021", patron)));
        contenedor.add(new Medicamento("PARACETAMOL", 2.30, LocalDate.parse("30-03-2022", patron)));
        contenedor.add(new Carnet("16642886V", "DIEGO MORÍN CALLE", LocalDate.parse("12-01-2022", patron)));
        contenedor.add(new Medicamento("IBUPROFENO", 4.30, LocalDate.parse("29-03-2022", patron)));
        contenedor.add(new Carnet("60250329N", "CRISTIAN VÁZQUEZ ANDRINO", LocalDate.parse("01-10-2022", patron)));
        contenedor.add(new Medicamento("GELOCATIL", 4.50, LocalDate.parse("18-08-2022", patron)));

        for (Caducable i : contenedor) {

            System.out.println(i.toString().toUpperCase());

            System.out.println("¿ESTÁ CADUCADO?: " + Boolean.toString(i.caducado()).toUpperCase());

            if (i.caducado() != true) {

                System.out.println("DÍAS RESTANTES: " + i.diasRestantes());

            }

            System.out.println("");

        }

    }

}
