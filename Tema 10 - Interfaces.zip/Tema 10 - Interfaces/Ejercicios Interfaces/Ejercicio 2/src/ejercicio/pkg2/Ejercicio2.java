/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    static int opcion;
    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Vector<Prestable> contenidoAudiovisual = new Vector<Prestable>();

        contenidoAudiovisual.add(new Serie("EL SEÑOR DE LOS ANILLOS", "FANTASÍA"));
        contenidoAudiovisual.add(new Serie("MY HERO ACADEMIA", 6, "CIENCIA FICCIÓN"));
        contenidoAudiovisual.add(new Videojuego("LEAGUE OF LEGENDS", "MOBA", "RIOT GAMES"));
        contenidoAudiovisual.add(new Videojuego("FORTNITE", 12, "BATTLE ROYALE", "EPIC GAMES"));

        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    sc.nextLine();

                    int posicion = buscarContenido(contenidoAudiovisual);

                    if (posicion == -1) {

                        System.err.println("DICHO TÍTULO NO SE ENCUENTRA ENTRE EL CONTENIDO AUDIOVISUAL. ");

                    } else {

                        if (!contenidoAudiovisual.get(posicion).isPrestado()) {

                            contenidoAudiovisual.get(posicion).prestar();

                        } else {

                            System.err.println("DICHO CONTENIDO AUDIOVISUAL YA SE ENCUENTRA PRESTADO. ");

                        }

                    }

                    break;

                case 2:

                    sc.nextLine();

                    posicion = buscarContenido(contenidoAudiovisual);

                    if (posicion == -1) {

                        System.err.println("DICHO TÍTULO NO SE ENCUENTRA ENTRE EL CONTENIDO AUDIOVISUAL. ");

                    } else {

                        if (contenidoAudiovisual.get(posicion).isPrestado()) {

                            contenidoAudiovisual.get(posicion).devolver();

                        } else {

                            System.err.println("DICHO CONTENIDO AUDIOVISUAL NO SE ENCUENTRA PRESTADO. ");

                        }

                    }

                    break;

                case 3:

                    for (int i = 0; i < contenidoAudiovisual.size(); i += 1) {

                        System.out.println(contenidoAudiovisual.get(i).toString());

                    }

                    break;

            }

        } while (opcion != 4);

        System.out.println("TOTAL RECAUDADO [SERIES]: " + Serie.getTotalRecaudado() + " €");
        System.out.println("TOTAL RECAUDADO [VIDEOJUEGOS]: " + Videojuego.getTotalRecaudado() + " €");

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. PRESTAR CONTENIDO AUDIOVISUAL "
                    + "\n\t2. DEVOLVER CONTENIDO AUDIOVISUAL "
                    + "\n\t3. MOSTRAR TODO EL CONTENIDO AUDIOVISUAL "
                    + "\n\t4. FINALIZAR EJECUCIÓN ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 4) {

                System.err.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 4);

        return opcion;

    }

    public static int buscarContenido(Vector<Prestable> contenidoAudiovisual) {

        System.out.println("INTRODUZCA TÍTULO DEL CONTENIDO AUDIOVISUAL: ");
        String titulo = sc.nextLine();

        for (int i = 0; i < contenidoAudiovisual.size(); i += 1) {

            if (contenidoAudiovisual.get(i).getTitulo().equalsIgnoreCase(titulo)) {

                return i;

            }

        }

        return -1;

    }

}
