/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Serie implements Prestable {

    private String titulo;
    private int numeroTemporadas = 3;
    private boolean prestado = false;
    private String genero;
    private double precio = 2 * this.numeroTemporadas;
    private static double totalRecaudado;

    public Serie(String titulo, String genero) {
        this.titulo = titulo;
        this.genero = genero;
    }

    public Serie(String titulo, int numeroTemporadas, String genero) {
        this.titulo = titulo;
        this.numeroTemporadas = numeroTemporadas;
        this.genero = genero;
        this.precio = 2 * this.numeroTemporadas;
    }

    public void prestar() {
        this.prestado = true;
        this.totalRecaudado = this.totalRecaudado + this.precio;
    }

    public void devolver() {
        prestado = false;
    }

    public boolean isPrestado() {
        return prestado;
    }

    public static double getTotalRecaudado() {
        return totalRecaudado;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public String toString() {
        return "Serie{" + "titulo=" + titulo + ", numeroTemporadas=" + numeroTemporadas + ", prestado=" + prestado + ", genero=" + genero + ", precio=" + precio + '}';
    }

}
