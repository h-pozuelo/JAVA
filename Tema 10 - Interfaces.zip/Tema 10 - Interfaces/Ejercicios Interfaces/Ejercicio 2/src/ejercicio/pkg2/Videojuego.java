/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Videojuego implements Prestable {

    private String titulo;
    private double horasEstimadas = 10;
    private boolean prestado = false;
    private String genero;
    private String compañia;
    private double precio = 0.5 * this.horasEstimadas;
    private static double totalRecaudado;

    public Videojuego(String titulo, String genero, String compañia) {
        this.titulo = titulo;
        this.genero = genero;
        this.compañia = compañia;
    }

    public Videojuego(String titulo, double horasEstimadas, String genero, String compañia) {
        this.titulo = titulo;
        this.horasEstimadas = horasEstimadas;
        this.genero = genero;
        this.compañia = compañia;
        this.precio = 0.5 * this.horasEstimadas;
    }

    public void prestar() {
        this.prestado = true;
        this.totalRecaudado = this.totalRecaudado + this.precio;
    }

    public void devolver() {
        prestado = false;
    }

    public boolean isPrestado() {
        return prestado;
    }

    public static double getTotalRecaudado() {
        return totalRecaudado;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public String toString() {
        return "Videojuego{" + "titulo=" + titulo + ", horasEstimadas=" + horasEstimadas + ", prestado=" + prestado + ", genero=" + genero + ", compa\u00f1ia=" + compañia + ", precio=" + precio + '}';
    }

}
