/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public interface Prestable {

    public void prestar();

    public void devolver();

    public boolean isPrestado();
    
    public String getTitulo();

}
