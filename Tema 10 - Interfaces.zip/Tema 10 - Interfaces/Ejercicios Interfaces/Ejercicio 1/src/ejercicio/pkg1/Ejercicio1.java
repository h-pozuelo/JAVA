/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        Interfaz[] estructurasDatosNoPrimitivas = new Interfaz[2];

        estructurasDatosNoPrimitivas[0] = new Pila();
        estructurasDatosNoPrimitivas[1] = new Cola();

        do {

            opcion = menu();

            String objeto;

            switch (opcion) {

                case 1:

                    System.out.println("INDIQUE NOMBRE DE OBJETO: ");
                    objeto = sc.nextLine();

                    estructurasDatosNoPrimitivas[0].addObjeto(objeto);

                    break;

                case 2:

                    System.out.println("INDIQUE NOMBRE DE OBJETO: ");
                    objeto = sc.nextLine();

                    estructurasDatosNoPrimitivas[1].addObjeto(objeto);

                    break;

                case 3:
                    
                    try {

                    System.out.println(estructurasDatosNoPrimitivas[0].returnObjeto());

                } catch (ArrayIndexOutOfBoundsException e) {

                    System.err.println("PARA PODER RECOGER OBJETOS PRIMERO DEBES DE AGREGAR ALGUNO. ");

                }

                break;

                case 4:
                    
                    try {

                    System.out.println(estructurasDatosNoPrimitivas[1].returnObjeto());

                } catch (ArrayIndexOutOfBoundsException e) {

                    System.err.println("PARA PODER RECOGER OBJETOS PRIMERO DEBES DE AGREGAR ALGUNO. ");

                }

                break;

            }

        } while (opcion != 5);

    }

    public static int menu() {

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. AGREGAR UN OBJETO A LA PILA "
                    + "\n\t2. AGREGAR UN OBJETO A LA COLA "
                    + "\n\t3. RECOGER UN OBJETO DE LA PILA "
                    + "\n\t4. RECOGER UN OBJETO DE LA COLA "
                    + "\n\t5. SALIR DEL PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 5) {

                System.err.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 5);

        return opcion;

    }

}
