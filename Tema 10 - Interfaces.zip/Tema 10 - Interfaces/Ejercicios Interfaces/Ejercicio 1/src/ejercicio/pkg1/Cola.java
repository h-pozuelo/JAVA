/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg1;

import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Cola implements Interfaz { // [QUEUE] - FIFO (PRIMERO EN ENTRAR ES EL PRIMERO EN SALIR) 

    private Vector<String> objetos;

    public Cola() {
        this.objetos = new Vector<String>();
    }

    public void addObjeto(String objeto) {

        objetos.add(objeto);

    }

    public String returnObjeto() {

        String objeto = objetos.get(0);

        objetos.remove(0);

        return objeto;

    }

}
