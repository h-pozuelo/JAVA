/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg1;

import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Pila implements Interfaz { // [STACK] - LIFO (ÚLTIMO EN ENTRAR ES EL PRIMERO EN SALIR) 

    private Vector<String> objetos;

    public Pila() {
        this.objetos = new Vector<String>();
    }

    public void addObjeto(String objeto) {

        objetos.add(objeto);

    }

    public String returnObjeto() {

        String objeto = objetos.get(objetos.size() - 1);

        objetos.remove(objetos.size() - 1);

        return objeto;

    }

}
