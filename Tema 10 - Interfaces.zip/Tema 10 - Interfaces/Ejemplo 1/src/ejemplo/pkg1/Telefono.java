/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.pkg1;

import java.util.HashMap;

/**
 *
 * @author Hugo
 */
public class Telefono implements Machine {

    private String numero;
    private HashMap<String, String> contactos; // TABLA HashMap QUE ALMACENA PAREJAS POR CLAVE (EN ESTE CASO PAREJAS DE LA MANERA ["Nombre", "Telefono"]) 

    public Telefono(String numero) {
        this.numero = numero;
        this.contactos = new HashMap<String, String>(); // EL PRIMER VALOR SERÁ LA CLAVE ["Nombre"] MIENTRAS QUE EL SEGUNDO VALOR ["Telefono"] PODRÁ SER IDENTIFICADO A PARTIR DEL "Nombre" 

    }

    public void addContacto(String nombre, String telefono) {
        contactos.put(nombre, telefono);
    }

    @Override
    public String suena() {
        return "Riiiiing";
    }

    public void reset() {
        contactos.clear();
    }

    @Override
    public String toString() {
        return "Telefono [numero=" + numero + ", contactos=" + contactos + "]";
    }

}
