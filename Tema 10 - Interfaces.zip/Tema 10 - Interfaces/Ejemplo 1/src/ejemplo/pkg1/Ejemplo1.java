/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.util.Vector;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Telefono tel = new Telefono("666666666");
        Vehiculo ve = new Vehiculo("6666XXX");

        tel.addContacto("Pepe", "444444444");
        tel.addContacto("Ana", "222222222");

        ve.recorrer(20);

        Vector<Machine> maquinas = new Vector<Machine>(); // PODEMOS CREAR UN CONTENEDOR CON OBJETOS QUE PERTENECEN A LA MISMA INTERFAZ 

        maquinas.add(ve); // NO AFECTA UTILIZAR .add() O .addElement() 

        maquinas.addElement(tel); // NO AFECTA UTILIZAR .add() O .addElement() 

        for (int i = 0; i < maquinas.size(); i++) {

            System.out.println(maquinas.get(i).toString()); // ESTO SERÍA ALGO PARECIDO AL POLIMORFISMO (EJECUTA EL MÉTODO ADECUADO SEGÚN EL TIPO DE OBJETO) 

            System.out.println(maquinas.get(i).suena());

            maquinas.get(i).reset();

        }

        for (int i = 0; i < maquinas.size(); i++) {

            System.out.println(maquinas.get(i).toString()); // MUESTRO POR PANTALLA LAS MÁQUINAS UNA VEZ RESETEADAS 

        }

    }

}
