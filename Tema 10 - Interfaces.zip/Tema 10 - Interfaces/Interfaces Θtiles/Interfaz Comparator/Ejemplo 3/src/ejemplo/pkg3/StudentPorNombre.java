/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.pkg3;

import java.util.Comparator;

/**
 *
 * @author Hugo
 */
public class StudentPorNombre implements Comparator<Student> { // CLASE PUENTE [IMPLEMENTA LA CLASE Comparator] 

    @Override
    public int compare(Student arg0, Student arg1) {
        // TODO Auto-generated method stub
        return arg0.getName().compareTo(arg1.getName());
    }

}
