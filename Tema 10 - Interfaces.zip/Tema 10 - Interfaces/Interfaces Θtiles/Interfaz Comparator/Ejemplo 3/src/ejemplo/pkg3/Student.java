/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.pkg3;

/**
 *
 * @author Hugo
 */
public class Student { // CLASE ORIGEN [NO IMPLEMENTA LA CLASE Comparator] 

    private int number;
    private String name;
    private int age;

    Student(int nu, String name, int age) {
        this.number = nu;
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Student [number=" + number + ", name=" + name + ", age=" + age + "]";
    }

}
