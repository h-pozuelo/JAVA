/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.pkg2;

/**
 *
 * @author Hugo
 */
public class Student implements Comparable<Student> { // DADO QUE IMPLEMENTA LA CLASE Comparable DEBO REDEFINIR EL MÉTODO compareTo() DE MANERA OBLIGATORIA 

    private int number;
    private String name;
    private int age;

    Student(int nu, String name, int age) {
        this.number = nu;
        this.name = name;
        this.age = age;
    }

    public int compareTo(Student st) { // CUANDO LLAMEMOS AL MÉTODO Collections.sort() ORDENARÁ EL VECTOR PASADO SEGÚN EL CRITERIO DE ESTE MÉTODO (REDEFINIMOS EL CRITERIO DE ORDENACIÓN DEL MÉTODO compareTo()) 
        /*
        return name.compareTo(st.name); // ORDENACIÓN DE MENOR A MAYOR 
         */
 /*
        return st.name.compareTo(name); // ORDENACIÓN DE MAYOR A MENOR 
         */
        if (age == st.age) {

            return 0;

        } else if (age > st.age) {

            return 1;

        } else {

            return -1;

        }

    }

    @Override
    public String toString() {
        return "Student [number=" + number + ", name=" + name + ", age=" + age + "]";
    }

}
