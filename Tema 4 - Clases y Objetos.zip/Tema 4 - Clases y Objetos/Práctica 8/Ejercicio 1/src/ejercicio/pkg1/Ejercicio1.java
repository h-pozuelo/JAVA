/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Satelite s1, s2;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        s1 = new Satelite();
        s2 = new Satelite(10, 423);

        s1.setDistancia(50);

        s1.setPosition(83, 24);

        s2.setDistancia(1000);

        if (!s1.orbita()) {
            System.out.println("EL SATÉLITE S1 NO ESTÁ EN ÓRBITA.");
        } else {
            System.out.println("EL SATÉLITE S1 SÍ ESTÁ EN ÓRBITA.");
        }

        System.out.println("SATÉLITE 1: " + s1.toString());

        System.out.println("SATÉLITE 2: " + s2.toString());

    }

}
