/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg1;

/**
 *
 * @author Hugo
 */
public class Satelite {

    private int distancia;
    private int meridiano;
    private int paralelo;

    public Satelite(int meridiano, int paralelo) {
        this.meridiano = meridiano;
        this.paralelo = paralelo;
    }

    public Satelite() {
        distancia = 0;
        meridiano = 0;
        paralelo = 0;
    }

    public boolean orbita() {
        return distancia > 0;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public void setPosition(int m, int p) {
        meridiano = m;
        paralelo = p;
    }

    @Override
    public String toString() {
        return "Satelite{" + "distancia=" + distancia + ", meridiano=" + meridiano + ", paralelo=" + paralelo + '}';
    }

}
