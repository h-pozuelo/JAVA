/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double imp;
        
        System.out.println("NÚMERO TOTAL DE PEDIDOS: " + Repartidor.getTotalPedidos());
        
        Repartidor r1 = new Repartidor(327);
        Repartidor r2 = new Repartidor(420);
        
        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);
        
        imp = r1.realizarPedido(30, 2);
        
        System.out.println("EL REPARTIDOR 1 HA GANADO EN EL PEDIDO 1: " + imp);
        
        imp = r1.realizarPedido(60, 10);
        
        System.out.println("EL REPARTIDOR 1 HA GANADO EN EL PEDIDO 2: " + imp);
        
        System.out.println(r1.toString());
        
        imp = r2.realizarPedido(12, 0);
        
        System.out.println("EL REPARTIDOR 2 HA GANADO EN EL PEDIDO 1: " + imp);
        
        System.out.println(r2.toString());
        
        System.out.println("NÚMERO TOTAL DE PEDIDOS: " + Repartidor.getTotalPedidos()); // DADO QUE LA VARIABLE totalPedidos ES ESTÁTICA DEBEMOS DE LLAMAR A LA CLASE Repartidor.getTotalPedidos(). (LLAMAMOS AL MÉTODO CON EL NOMBRE DE LA CLASE POR DELANTE EN VEZ DE CON EL NOMBRE DEL OBJETO) 

        System.out.println("CANTIDAD TOTAL DE GANANCIAS: " + Repartidor.getTotalGanancias());
        
    }
    
}
