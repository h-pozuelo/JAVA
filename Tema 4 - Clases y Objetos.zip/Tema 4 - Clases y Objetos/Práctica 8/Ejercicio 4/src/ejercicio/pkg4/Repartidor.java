/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public class Repartidor {

    private int numero;
    private double ganancias;
    private int numPedidos;
    private static int totalPedidos = 0;
    private static double totalGanancias = 0;

    public Repartidor(int numero) {
        this.numero = numero;
        // this.ganancias = 0;
        // this.numPedidos = 0;
    }

    public double realizarPedido(double importe, double propinas) {

        double gana;

        gana = propinas + importe * 0.2;

        ganancias += gana;

        totalGanancias += gana;

        numPedidos++;

        totalPedidos += 1;

        return gana;

    }

    public static int getTotalPedidos() {
        return totalPedidos;
    }

    public static double getTotalGanancias() {
        return totalGanancias;
    }

    @Override
    public String toString() {
        return "Repartidor{" + "numero=" + numero + ", ganancias=" + ganancias + ", numPedidos=" + numPedidos + '}';
    }

}
