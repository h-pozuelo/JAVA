/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Alumno {

    private int numeroMatricula;
    private double notaModulo1, notaModulo2, notaModulo3, notaMedia;

    public Alumno(int numeroMatricula) {
        this.numeroMatricula = numeroMatricula;
    }

    public void setNumeroMatricula(int numeroMatricula) {
        this.numeroMatricula = numeroMatricula;
    }

    public void setNotaModulo1(double notaModulo1) {
        this.notaModulo1 = notaModulo1;
        this.notaMedia = notaMedia + (notaModulo1 / 3);
    }

    public void setNotaModulo2(double notaModulo2) {
        this.notaModulo2 = notaModulo2;
        this.notaMedia = notaMedia + (notaModulo2 / 3);
    }

    public void setNotaModulo3(double notaModulo3) {
        this.notaModulo3 = notaModulo3;
        this.notaMedia = notaMedia + (notaModulo3 / 3);
    }

    public double getNotaMedia() {
        return notaMedia;
    }

    @Override
    public String toString() {
        return "Alumno{" + "numeroMatricula=" + numeroMatricula + ", notaModulo1=" + notaModulo1 + ", notaModulo2=" + notaModulo2 + ", notaModulo3=" + notaModulo3 + ", notaMedia=" + notaMedia + '}';
    }

}
