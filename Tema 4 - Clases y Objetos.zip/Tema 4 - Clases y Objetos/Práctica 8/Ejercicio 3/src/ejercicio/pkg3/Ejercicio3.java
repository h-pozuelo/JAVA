/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Alumno a1, a2, a3;
        int numeroMatricula;
        double notaModulo;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        // ALUMNO 1
        a1 = new Alumno(0);

        System.out.println("INTRODUZCA NÚMERO DE MATRÍCULA: ");
        numeroMatricula = sc.nextInt();

        a1.setNumeroMatricula(numeroMatricula);

        do {

            System.out.println("INTRODUZCA NOTA EN BASES DE DATOS: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a1.setNotaModulo1(notaModulo);

        do {

            System.out.println("INTRODUZCA NOTA EN ENTORNOS DE DESARROLLO: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a1.setNotaModulo2(notaModulo);

        do {

            System.out.println("INTRODUZCA NOTA EN PROGRAMACIÓN: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a1.setNotaModulo3(notaModulo);

        // ALUMNO 2
        a2 = new Alumno(0);

        System.out.println("INTRODUZCA NÚMERO DE MATRÍCULA: ");
        numeroMatricula = sc.nextInt();

        a2.setNumeroMatricula(numeroMatricula);

        do {

            System.out.println("INTRODUZCA NOTA EN BASES DE DATOS: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a2.setNotaModulo1(notaModulo);

        do {

            System.out.println("INTRODUZCA NOTA EN ENTORNOS DE DESARROLLO: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a2.setNotaModulo2(notaModulo);

        do {

            System.out.println("INTRODUZCA NOTA EN PROGRAMACIÓN: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a2.setNotaModulo3(notaModulo);

        // ALUMNO 3
        a3 = new Alumno(0);

        System.out.println("INTRODUZCA NÚMERO DE MATRÍCULA: ");
        numeroMatricula = sc.nextInt();

        a3.setNumeroMatricula(numeroMatricula);

        do {

            System.out.println("INTRODUZCA NOTA EN BASES DE DATOS: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a3.setNotaModulo1(notaModulo);

        do {

            System.out.println("INTRODUZCA NOTA EN ENTORNOS DE DESARROLLO: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a3.setNotaModulo2(notaModulo);

        do {

            System.out.println("INTRODUZCA NOTA EN PROGRAMACIÓN: ");
            notaModulo = sc.nextDouble();

        } while (notaModulo < 0 || notaModulo > 10);

        a3.setNotaModulo3(notaModulo);

        if (a1.getNotaMedia() >= a2.getNotaMedia() && a1.getNotaMedia() >= a1.getNotaMedia()) {
            System.out.println(a1.toString());
            if (a2.getNotaMedia() >= a3.getNotaMedia()) {
                System.out.println(a2.toString());
                System.out.println(a3.toString());
            } else {
                System.out.println(a3.toString());
                System.out.println(a2.toString());
            }
        } else if (a2.getNotaMedia() >= a1.getNotaMedia() && a2.getNotaMedia() >= a3.getNotaMedia()) {
            System.out.println(a2.toString());
            if (a1.getNotaMedia() >= a3.getNotaMedia()) {
                System.out.println(a1.toString());
                System.out.println(a3.toString());
            } else {
                System.out.println(a3.toString());
                System.out.println(a1.toString());
            }
        } else {
            System.out.println(a3.toString());
            if (a2.getNotaMedia() >= a1.getNotaMedia()) {
                System.out.println(a2.toString());
                System.out.println(a1.toString());
            } else {
                System.out.println(a1.toString());
                System.out.println(a2.toString());
            }
        }

    }

}
