/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

/**
 *
 * @author Hugo
 */
public class Viaje {

    private String ciudadOrigen, ciudadDestino, codigoViaje;
    private int numeroPlazas, reservarPlazas;
    private double importeViaje;
    private static double totalRecaudado;

    public Viaje(String ciudadOrigen, String ciudadDestino, String codigoViaje, int numeroPlazas, double importeViaje) {
        this.ciudadOrigen = ciudadOrigen;
        this.ciudadDestino = ciudadDestino;
        this.codigoViaje = codigoViaje;
        this.numeroPlazas = numeroPlazas;
        this.importeViaje = importeViaje;
    }

    @Override
    public String toString() {
        return "Viaje{" + "ciudadOrigen=" + ciudadOrigen + ", ciudadDestino=" + ciudadDestino + ", codigoViaje=" + codigoViaje + ", numeroPlazas=" + numeroPlazas + ", importeViaje=" + importeViaje + '}';
    }

    public double reservar(int cantidadAdultos, int cantidadNiños) {

        if ((cantidadAdultos + cantidadNiños) > 0 && (cantidadAdultos + cantidadNiños) <= numeroPlazas) {

            reservarPlazas += cantidadAdultos + cantidadNiños;

            numeroPlazas -= (cantidadNiños + cantidadAdultos);

            double importeTotal = (cantidadAdultos * importeViaje) + (cantidadNiños * (importeViaje * 0.8));

            totalRecaudado += importeTotal;

            return importeTotal;

        }

        return 0;

    }

    public boolean modificarNumeroPlazas(int modificarNumeroPlazas) {

        if (modificarNumeroPlazas >= reservarPlazas) {

            numeroPlazas = modificarNumeroPlazas - reservarPlazas;

            return true;

        }

        return false;

    }

    public static double getTotalRecaudado() {
        return totalRecaudado;
    }

}
