/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg7;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Viaje v1;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        v1 = new Viaje("MADRID", "BARCELONA", "MABA1", 80, 75);

        System.out.println(v1.toString());

        // RESERVAR NÚMERO DE PLAZAS 
        System.out.println("INTRODUZCA CANTIDAD DE ADULTOS: ");
        int cantidadAdultos = sc.nextInt();

        System.out.println("INTRODUZCA CANTIDAD DE NIÑOS: ");
        int cantidadNiños = sc.nextInt();

        v1.reservar(cantidadAdultos, cantidadNiños);

        // TOTAL RECAUDADO 
        System.out.println("IMPORTE TOTAL: " + Viaje.getTotalRecaudado() + " €");

        // MODIFICAR NÚMERO DE PLAZAS 
        sc.nextLine();

        System.out.println("¿DESEA LA AEROLÍNEA MODIFICAR EL NÚMERO DE PLAZAS?");
        char respuesta = sc.nextLine().charAt(0);

        respuesta = Character.toUpperCase(respuesta);

        switch (respuesta) {

            case 'S':

                int numeroPlazas;

                do {

                    System.out.println("INTRODUZCA NÚMERO DE PLAZAS: ");
                    numeroPlazas = sc.nextInt();

                    if (v1.modificarNumeroPlazas(numeroPlazas) == true) {

                        System.out.println("COMPLETADO.");

                        System.out.println(v1.toString());

                    } else {

                        System.out.println("CANTIDAD NO VÁLIDA.");

                    }

                } while (v1.modificarNumeroPlazas(numeroPlazas) == false);

                break;

            case 'N':
                break;

            default:
                break;

        }

    }

}
