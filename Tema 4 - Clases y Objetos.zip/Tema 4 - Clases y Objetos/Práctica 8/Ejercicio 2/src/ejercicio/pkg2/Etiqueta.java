/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Etiqueta {

    private int anchura, altura;
    private char caracter;

    public Etiqueta(int anchura, int altura, char caracter) {
        this.anchura = anchura;
        this.altura = altura;
        this.caracter = caracter;
    }

    public void dibujar() {

        for (int f = 1; f <= altura; f += 1) {

            for (int c = 1; c <= anchura; c += 1) {

                if (f == 1 || f == altura) {
                    System.out.print(caracter);
                } else if (c == 1 || c == anchura) {
                    System.out.print(caracter);
                } else {
                    System.out.print(" ");
                }

            }

            System.out.println(); // SERÍA LO MISMO PONER System.out.print("\n"); o System.out.println(""); 

        }

    }

    public void setCaracter(char caracter) {
        this.caracter = caracter;
    }

}
