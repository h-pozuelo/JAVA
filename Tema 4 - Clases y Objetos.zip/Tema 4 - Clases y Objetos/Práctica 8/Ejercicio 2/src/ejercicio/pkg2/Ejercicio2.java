/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Etiqueta e1, e2;
        char caracter;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        e1 = new Etiqueta(5, 3, '$');

        e1.dibujar(); // COMO EL OBJETO e1 YA ESTÁ CREADO NO ES NECESARIO VOLVER A PASAR LOS DATOS. 

        e2 = new Etiqueta(10, 14, '&');

        System.out.println("INTRODUZCA CARACTER: ");
        caracter = sc.nextLine().charAt(0);

        e2.setCaracter(caracter);

        e2.dibujar();

    }

}
