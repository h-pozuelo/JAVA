/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double descuento, cantidad;
        Cargamento c1, c2, c3;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        // CARGAMENTO 1 
        c1 = new Cargamento("MANZANAS", "LEÓN", 20, 2.5, 3);

        System.out.println(c1.toString());

        // CARGAMENTO 2 
        c2 = new Cargamento("NARANJAS", "LEÓN", 25, 5, 7.5);

        System.out.println(c2.toString());

        // CARGAMENTO 3 
        c3 = new Cargamento("PLÁTANOS", "CANARIAS", 30, 2, 4);

        System.out.println(c3.toString());

        // COMPROBAR PROCEDENCIA 
        if (c1.comprobarProcedencia(c2)) {
            System.out.println("LOS CARGAMENTOS 1 Y 2 SÍ TIENEN LA MISMA PROCEDENCIA.");
        } else {
            System.out.println("LOS CARGAMENTOS 1 Y 2 NO TIENEN LA MISMA PROCEDENCIA.");
        }

        // REBAJAR CARGAMENTO 1 
        do {

            System.out.println("INTRODUZCA PRECIO A REBAJAR DEL CARGAMENTO 1: ");
            descuento = sc.nextDouble();

        } while (c1.rebajar(descuento) == false);

        System.out.println(c1.toString());

        // REBAJAR CARGAMENTO 2 
        do {

            System.out.println("INTRODUZCA PRECIO A REBAJAR DEL CARGAMENTO 2: ");
            descuento = sc.nextDouble();

        } while (c2.rebajar(descuento) == false);

        System.out.println(c2.toString());

        // REBAJAR CARGAMENTO 3 
        do {

            System.out.println("INTRODUZCA PRECIO A REBAJAR DEL CARGAMENTO 3: ");
            descuento = sc.nextDouble();

        } while (c3.rebajar(descuento) == false);

        System.out.println(c3.toString());

        // VENDER CARGAMENTO 1 
        do {

            System.out.println("INTRODUZCA CANTIDAD A VENDER DEL CARGAMENTO 1: ");
            cantidad = sc.nextDouble();

        } while (c1.vender(cantidad) == false);

        System.out.println(c1.toString());

        // VENDER CARGAMENTO 2 
        do {

            System.out.println("INTRODUZCA CANTIDAD A VENDER DEL CARGAMENTO 2: ");
            cantidad = sc.nextDouble();

        } while (c2.vender(cantidad) == false);

        System.out.println(c2.toString());

        // VENDER CARGAMENTO 3 
        do {

            System.out.println("INTRODUZCA CANTIDAD A VENDER DEL CARGAMENTO 3: ");
            cantidad = sc.nextDouble();

        } while (c3.vender(cantidad) == false);

        System.out.println(c3.toString());

        System.out.println("BENEFICIO TOTAL: " + Cargamento.getBeneficios() + " €");

    }

}
