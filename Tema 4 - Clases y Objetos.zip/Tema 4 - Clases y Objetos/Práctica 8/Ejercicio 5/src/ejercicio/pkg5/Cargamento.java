/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio.pkg5;

/**
 *
 * @author Hugo
 */
public class Cargamento {

    private String nombre;
    private String procedencia;
    private double peso;
    private double precioCoste;
    private double precioVenta;
    private static double beneficios;

    public Cargamento(String nombre, String procedencia, double peso, double precioCoste, double precioVenta) {
        this.nombre = nombre;
        this.procedencia = procedencia;
        this.peso = peso;
        this.precioCoste = precioCoste;
        this.precioVenta = precioVenta;
    }

    @Override
    public String toString() {
        return "Cargamento{" + "nombre=" + nombre + ", procedencia=" + procedencia + ", peso=" + peso + ", precioCoste=" + precioCoste + ", precioVenta=" + precioVenta + '}';
    }

    public boolean comprobarProcedencia(Cargamento c) {
        return this.procedencia.equalsIgnoreCase(c.procedencia);
    }

    public boolean rebajar(double descuento) {

        double precioRebajado = precioVenta;

        precioRebajado -= descuento;

        if (precioRebajado >= precioCoste && descuento >= 0) {

            precioVenta -= descuento;

            return true;

        } else {

            System.out.println("CANTIDAD NO VÁLIDA.");

            return false;

        }

    }

    public boolean vender(double cantidad) {

        double cantidadRestante = peso;

        cantidadRestante -= cantidad;

        if (cantidadRestante >= 0 && cantidad >= 0) {

            peso -= cantidad;

            double importe = cantidad * precioVenta;

            beneficios += (precioVenta - precioCoste) * cantidad;

            // ---------- INICIO REDONDEAR VALOR ---------- 
            double scale = Math.pow(10, 2);

            double importeRound = Math.round(importe * scale) / scale;

            // ---------- FINAL REDONDEAR VALOR ---------- 
            System.out.println("IMPORTE TOTAL: " + importeRound + " €");

            return true;

        } else {

            System.out.println("CANTIDAD NO VÁLIDA.");

            return false;

        }

    }

    public static double getBeneficios() {
        return beneficios;
    }

}
