/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.letras;

/**
 *
 * @author Hugo
 */
public abstract class Letra {

    protected char c; // CARÁCTER DE DIBUJO. 
    protected char s; // CARÁCTER A DIBUJAR. 

    public Letra(char car, char cad) {
        this.c = car;
        this.s = cad;
    }

    public char getNombre() {
        return this.s;
    }

    abstract public void dibuja();

}
