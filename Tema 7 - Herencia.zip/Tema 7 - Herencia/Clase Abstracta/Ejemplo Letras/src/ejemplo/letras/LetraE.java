/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.letras;

/**
 *
 * @author Hugo
 */
public class LetraE extends Letra {

    public LetraE(char car) {
        super(car, 'e');
    }

    public void dibuja() {

        System.out.println(c + "" + c + c + c);

        System.out.println(c);

        System.out.println("" + c + c + c + c);

        System.out.println(c);

        System.out.println("" + c + c + c + c);

    }

}
