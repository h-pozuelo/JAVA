/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.letras;

/**
 *
 * @author Hugo
 */
public class EjemploLetras {

    static Letra tabla[] = new Letra[6];

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        tabla[0] = new LetraA('?');
        tabla[1] = new LetraE('4');
        tabla[2] = new LetraI('8');
        tabla[3] = new LetraA('#');
        tabla[4] = new LetraE('&');
        tabla[5] = new LetraI('!');

        for (int i = 0; i < tabla.length; i += 1) {

            tabla[i].dibuja();
            System.out.print("\n");

        }

    }

}
