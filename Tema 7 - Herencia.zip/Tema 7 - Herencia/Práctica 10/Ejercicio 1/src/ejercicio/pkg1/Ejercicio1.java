/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Libro libros[] = new Libro[5];
        int opcion;
        int cantidadLibros = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        do {

            do {

                opcion = menu(sc);

            } while (opcion == -1);

            switch (opcion) {

                case 1:

                    if (cantidadLibros < libros.length) {

                        sc.nextLine();

                        System.out.println("INTRODUZA TÍTULO: ");
                        String titulo = sc.nextLine();

                        System.out.println("INTRODUZCA AUTOR: ");
                        String autor = sc.nextLine();

                        System.out.println("INTRODUZCA EDITORIAL: ");
                        String editorial = sc.nextLine();

                        System.out.println("INTRODUZCA PRECIO: ");
                        double precio = sc.nextDouble();

                        sc.nextLine();

                        System.out.println("¿ES UN LIBRO DE TEXTO? (S/N)");
                        char respuesta = sc.nextLine().charAt(0);

                        if (Character.toUpperCase(respuesta) == 'S') {

                            System.out.println("INTRODUZCA CURSO: ");
                            String curso = sc.nextLine();

                            double descuento;

                            do {

                                System.out.println("INTRODUZCA DESCUENTO: ");
                                descuento = sc.nextDouble();

                                if (descuento < 0 || descuento > 20) {

                                    System.out.println("DESCUENTO NO VÁLIDO. ");

                                }

                            } while (descuento < 0 || descuento > 20);

                            libros[cantidadLibros] = new Texto(curso, descuento, titulo, autor, editorial, precio);

                        } else {

                            libros[cantidadLibros] = new Libro(titulo, autor, editorial, precio);

                        }

                        cantidadLibros += 1;

                    } else {

                        System.out.println("NO DE PUEDEN DAR DE ALTA MÁS LIBROS. ");

                    }

                    break;

                case 2:

                    for (int i = 0; i < cantidadLibros; i += 1) {

                        System.out.println(libros[i].toString());

                    }

                    break;

                case 3:

                    System.out.println("INTRODUZCA PRECIO: ");
                    double precio = sc.nextDouble();

                    for (int i = 0; i < cantidadLibros; i += 1) {

                        if (libros[i].getPrecio() < precio) {

                            System.out.println(libros[i].toString());

                        }

                    }

                    break;

            }

        } while (opcion != 4);

    }

    private static int menu(Scanner sc) {

        System.out.println("INDIQUE UNA OPCIÓN: \n"
                + "\t1. DAR DE ALTA UN LIBRO. \n"
                + "\t2. LISTAR TODOS LOS LIBROS. \n"
                + "\t3. LISTAR ÚNICAMENTE LOS LIBROS CON UN PRECIO MENOR AL INTRODUCIDO. \n"
                + "\t4. SALIR. ");
        int opcion = sc.nextInt();

        if (opcion < 1 || opcion > 4) {

            System.out.println("OPCIÓN NO VÁLIDA. ");

            return -1;

        }

        return opcion;

    }

}
