/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg1;

/**
 *
 * @author Hugo
 */
public class Texto extends Libro {

    private String curso;
    private double descuento;

    public Texto(String curso, double descuento, String titulo, String autor, String editorial, double precio) {
        super(titulo, autor, editorial, precio);
        this.curso = curso;
        this.descuento = descuento;
        // this.precio -= ((this.precio * this.descuento) / 100);
    }

    public double getPrecio() {
        return (this.precio * this.descuento) / 100;
    }

    @Override
    public String toString() {
        return "Texto{" + super.toString() + "curso=" + curso + ", descuento=" + descuento + '}';
    }

}
