/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Extranjero extends Alumno {

    private String pais;

    public Extranjero(String pais, String nombre, String apellidos, String curso, double importe) {
        super(nombre, apellidos, curso, importe);
        this.pais = pais;
        this.importe += this.importe * 15 / 100;
    }

    @Override
    public String toString() {
        return super.toString() + "\n"
                + "PAÍS DE ORIGEN: " + pais + ".";
    }

}
