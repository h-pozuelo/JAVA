/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Alumno alumnos[] = new Alumno[5];

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        for (int i = 0; i < alumnos.length; i += 1) {

            System.out.println("INTRODUZCA NOMBRE: ");
            String nombre = sc.nextLine();

            System.out.println("INTRODUZCA APELLIDOS: ");
            String apellidos = sc.nextLine();

            System.out.println("INTRODUZCA CURSO: ");
            String curso = sc.nextLine();

            System.out.println("INTRODUZCA IMPORTE DE LA MATRÍCULA: ");
            double importe = sc.nextDouble();

            System.out.println("INDIQUE UNA OPCIÓN: \n"
                    + "\t1. ALUMNO NORMAL. \n"
                    + "\t2. ALUMNO EXTRANJERO. \n"
                    + "\t3. ALUMNO CURSO PUENTE. ");
            int opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    alumnos[i] = new Alumno(nombre, apellidos, curso, importe);

                    sc.nextLine();

                    break;

                case 2:

                    sc.nextLine();

                    System.out.println("INTRODUZCA PAÍS DE ORIGEN: ");
                    String pais = sc.nextLine();

                    alumnos[i] = new Extranjero(pais, nombre, apellidos, curso, importe);

                    break;

                case 3:

                    sc.nextLine();

                    System.out.println("INTRODUZCA CARRERA DE PROCEDENCIA: ");
                    String carrera = sc.nextLine();

                    alumnos[i] = new CursoPuente(carrera, nombre, apellidos, curso, importe);

                    break;

            }

        }

        for (int i = 0; i < alumnos.length; i += 1) {

            System.out.println("\n"
                    + alumnos[i].toString());

        }

    }

}
