/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class Alumno {

    private String nombre, apellidos, curso;
    protected double importe;

    public Alumno(String nombre, String apellidos, String curso, double importe) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.curso = curso;
        this.importe = importe;
    }

    @Override
    public String toString() {
        return "NOMBRE: " + nombre + ".\n"
                + "APELLIDOS: " + apellidos + ".\n"
                + "CURSO: " + curso + ".\n"
                + "IMPORTE DE LA MATRÍCULA: " + importe + ".";
    }

}
