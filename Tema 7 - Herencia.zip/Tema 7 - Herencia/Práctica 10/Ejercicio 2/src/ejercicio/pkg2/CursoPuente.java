/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg2;

/**
 *
 * @author Hugo
 */
public class CursoPuente extends Alumno {

    private String carrera;

    public CursoPuente(String carrera, String nombre, String apellidos, String curso, double importe) {
        super(nombre, apellidos, curso, importe);
        this.carrera = carrera;
    }

    @Override
    public String toString() {
        return super.toString() + "\n"
                + "CARRERA DE PROCEDENCIA: " + carrera + ".";
    }

}
