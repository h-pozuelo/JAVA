/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public abstract class Vehiculo {

    private String matricula;
    protected double fianza;
    protected double precioCoste;
    protected boolean alquilado = false;
    protected static double totalRecaudado;

    public Vehiculo(String matricula) {
        this.matricula = matricula;
    }

    public abstract double alquilar(int dias);

    @Override
    public String toString() {
        return "\tVehiculo: "
                + "Matricula = " + matricula
                + " , Fianza = " + fianza
                + " , Precio Coste = " + precioCoste
                + ", ¿Alquilado? = " + alquilado;
    }

    public String getMatricula() {
        return matricula;
    }

    public boolean isAlquilado() {
        return alquilado;
    }

    public static double getTotalRecaudado() {
        return totalRecaudado;
    }

}
