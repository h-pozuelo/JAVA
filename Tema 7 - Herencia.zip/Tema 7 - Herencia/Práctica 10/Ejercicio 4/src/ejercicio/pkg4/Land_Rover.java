/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public class Land_Rover extends Coche {

    private final String tipoCoche = "Land Rover";

    public Land_Rover(String matricula) {
        super(matricula);
    }

    public double alquilar(int dias) {

        if (dias < 4) {

            this.precioCoste = 100;

        } else {

            this.precioCoste = 70;

        }

        this.alquilado = true;

        this.totalRecaudado += (dias * this.precioCoste) + this.fianza;

        return (dias * this.precioCoste) + this.fianza;

    }

    @Override
    public String toString() {
        return super.toString() + ", Marca = " + tipoCoche;
    }

}
