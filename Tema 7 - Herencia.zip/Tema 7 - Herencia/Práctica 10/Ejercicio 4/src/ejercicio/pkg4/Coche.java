/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public abstract class Coche extends Vehiculo {

    private final String tipoVehiculo = "Coche";

    public Coche(String matricula) {
        super(matricula);
        this.fianza = 50;
    }

    public abstract double alquilar(int dias);

    @Override
    public String toString() {
        return super.toString() + ", Tipo de Vehiculo = " + tipoVehiculo;
    }

}
