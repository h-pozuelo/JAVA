/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public class Bicicleta extends Vehiculo {

    private final String tipoVehiculo = "Bicicleta";

    public Bicicleta(String matricula) {
        super(matricula);
        this.fianza = 30;
        this.precioCoste = 10;
    }

    public double alquilar(int dias) {

        this.alquilado = true;

        this.totalRecaudado += (dias * this.precioCoste) + this.fianza;

        return (dias * this.precioCoste) + this.fianza;

    }

    @Override
    public String toString() {
        return super.toString() + ", Tipo de Vehiculo = " + tipoVehiculo;
    }

}
