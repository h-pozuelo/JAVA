/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Vehiculo vehiculos[];
        vehiculos = new Vehiculo[5];
        int cantidadVehiculos = 0;

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int opcion;

        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    if (cantidadVehiculos < vehiculos.length) {

                        sc.nextLine();

                        System.out.println("INTRODUZCA NÚMERO DE MATRÍCULA: ");
                        String matricula = sc.nextLine();

                        int tipoVehiculo;

                        do {

                            System.out.println("INDIQUE TIPO DE VEHÍCULO: \n"
                                    + "\t1. COCHE \n"
                                    + "\t2. BICICLETA ");
                            tipoVehiculo = sc.nextInt();

                            if (tipoVehiculo < 1 || tipoVehiculo > 2) {

                                System.out.println("TIPO DE VEHÍCULO NO VÁLIDO. ");

                            }

                        } while (tipoVehiculo < 1 || tipoVehiculo > 2);

                        if (tipoVehiculo == 1) {

                            int tipoCoche;

                            do {

                                System.out.println("INDIQUE TIPO DE COCHE: \n"
                                        + "\t1. CORSA \n"
                                        + "\t2. LAND ROVER ");
                                tipoCoche = sc.nextInt();

                                if (tipoCoche < 1 || tipoCoche > 2) {

                                    System.out.println("TIPO DE COCHE NO VÁLIDO. ");

                                }

                            } while (tipoCoche < 1 || tipoCoche > 2);

                            if (tipoCoche == 1) {

                                vehiculos[cantidadVehiculos] = new Corsa(matricula);

                                cantidadVehiculos += 1;

                                System.out.println("CORSA AGREGADO CORRECTAMENTE. ");

                            } else {

                                vehiculos[cantidadVehiculos] = new Land_Rover(matricula);

                                cantidadVehiculos += 1;

                                System.out.println("LAND ROVER AGREGADO CORRECTAMENTE. ");

                            }

                        } else {

                            vehiculos[cantidadVehiculos] = new Bicicleta(matricula);

                            cantidadVehiculos += 1;

                            System.out.println("BICICLETA AGREGADA CORRECTAMENTE. ");

                        }

                    } else {

                        System.out.println("NO SE PUEDEN AGREGAR MÁS VEHÍCULOS. ");

                    }

                    break;

                case 2:

                    if (cantidadVehiculos > 0) {

                        for (int i = 0; i < cantidadVehiculos; i += 1) {

                            System.out.println(vehiculos[i].toString());

                        }

                        sc.nextLine();

                        System.out.println("INTRODUZCA NÚMERO DE MATRÍCULA: ");
                        String matricula = sc.nextLine();

                        int buscarVehiculo = buscarVehiculo(vehiculos, cantidadVehiculos, matricula);

                        if (buscarVehiculo == -1) {

                            System.out.println("VEHÍCULO NO ENCONTRADO. ");

                        } else if (vehiculos[buscarVehiculo].isAlquilado()) {

                            System.out.println("VEHÍCULO ACTUALMENTE NO DISPONIBLE. ");

                        } else {

                            int dias;

                            do {

                                System.out.println("¿POR CUANTOS DÍAS DESEA ALQUILAR EL VEHÍCULO?");
                                dias = sc.nextInt();

                                if (dias <= 0) {

                                    System.out.println("CANTIDAD DE DÍAS NO VÁLIDO. ");

                                }

                            } while (dias <= 0);

                            System.out.println("COSTE TOTAL: " + vehiculos[buscarVehiculo].alquilar(dias) + " €");

                        }

                    }

                    break;

                case 3:

                    break;

                case 4:

                    if (cantidadVehiculos > 0) {

                        for (int i = 0; i < cantidadVehiculos; i += 1) {

                            System.out.println(vehiculos[i].toString());

                        }

                    }

                    break;

                case 5:

                    if (cantidadVehiculos > 0) {

                        System.out.println("TOTAL RECAUDADO: " + Vehiculo.getTotalRecaudado() + " €");

                    }

                    break;

            }

        } while (opcion != 6);

    }

    private static int menu() {

        int opcion;

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("INDIQUE UNA OPCIÓN: \n"
                    + "\t1. DAR DE ALTA UN VEHÍCULO \n"
                    + "\t2. ALQUILAR UN VEHÍCULO \n"
                    + "\t3. DAR DE BAJA UN VEHÍCULO \n"
                    + "\t4. LISTAR TODOS LOS VEHÍCULOS \n"
                    + "\t5. MOSTRAR TOTAL RECAUDADO \n"
                    + "\t6. SALIR DEL PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 6) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 6);

        return opcion;

    }

    private static int buscarVehiculo(Vehiculo vehiculos[], int cantidadVehiculos, String matricula) {

        for (int i = 0; i < cantidadVehiculos; i += 1) {

            if (matricula.equalsIgnoreCase(vehiculos[i].getMatricula())) {

                return i;

            }

        }

        return -1;

    }

}
