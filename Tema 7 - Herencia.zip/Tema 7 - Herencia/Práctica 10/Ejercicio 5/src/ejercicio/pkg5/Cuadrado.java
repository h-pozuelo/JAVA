/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg5;

/**
 *
 * @author Hugo
 */
public class Cuadrado extends Poligono {

    private double base;

    public Cuadrado(double base) {
        this.base = base;
    }

    public void calcularArea() {

        this.area = this.base * this.base;

    }

    public void calcularPerimetro() {

        this.perimetro = this.base * 4;

    }

}
