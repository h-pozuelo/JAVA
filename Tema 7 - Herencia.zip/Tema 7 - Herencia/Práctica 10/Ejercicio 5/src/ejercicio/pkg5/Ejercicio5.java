/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Poligono poligonos[] = new Poligono[3];

        poligonos[0] = new Cuadrado(5);
        poligonos[1] = new Rectangulo(5, 4);
        poligonos[2] = new Triangulo(4, 3);

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.ENGLISH);

        int opcion;

        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    int tipoPoligono = tipoPoligono() - 1;

                    poligonos[tipoPoligono].calcularArea();

                    System.out.println(poligonos[tipoPoligono].getArea());

                    break;

                case 2:

                    tipoPoligono = tipoPoligono() - 1;

                    poligonos[tipoPoligono].calcularPerimetro();

                    System.out.println(poligonos[tipoPoligono].getPerimetro());

                    break;

            }

        } while (opcion != 3);

    }

    private static int menu() {

        Scanner sc = new Scanner(System.in);

        int opcion;

        do {

            System.out.println("INDIQUE UNA OPCIÓN: \n"
                    + "\t1. CALCULAR ÁREA \n"
                    + "\t2. CALCULAR PERÍMETRO \n"
                    + "\t3. SALIR DEL PROGRAMA ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 3) {

                System.out.println("OPCIÓN NO VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 3);

        return opcion;

    }

    private static int tipoPoligono() {

        Scanner sc = new Scanner(System.in);

        int poligono;

        do {

            System.out.println("INDIQUE UN POLÍGONO: \n"
                    + "\t1. CUADRADO \n"
                    + "\t2. RECTÁNGULO \n"
                    + "\t3. TRIÁNGULO ");
            poligono = sc.nextInt();

            if (poligono < 1 || poligono > 3) {

                System.out.println("POLÍGONO NO VÁLIDO. ");

            }

        } while (poligono < 1 || poligono > 3);

        return poligono;

    }

}
