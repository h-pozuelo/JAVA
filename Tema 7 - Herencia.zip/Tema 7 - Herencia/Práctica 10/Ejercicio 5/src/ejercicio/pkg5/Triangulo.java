/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg5;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Triangulo extends Poligono {

    private double base;
    private double altura;
    private double hipotenusa;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
        this.hipotenusa = calcularHipotenusa();
    }

    private double calcularHipotenusa() {

        double resultado = (this.base * this.base) + (this.altura * this.altura);

        return Math.sqrt(resultado);

    }

    public void calcularArea() {

        this.area = (this.base * this.altura) / 2;

    }

    public void calcularPerimetro() {

        this.perimetro = this.base + this.altura + this.hipotenusa;

    }

}
