/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg5;

/**
 *
 * @author Hugo
 */
public class Rectangulo extends Poligono {

    private double base;
    private double altura;

    public Rectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public void calcularArea() {

        this.area = this.base * this.altura;

    }

    public void calcularPerimetro() {

        this.perimetro = (this.base * 2) + (this.altura * 2);

    }

}
