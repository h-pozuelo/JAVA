/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg5;

/**
 *
 * @author Hugo
 */
public abstract class Poligono {

    protected double area;
    protected double perimetro;
    protected int lados;

    public Poligono() {
    }

    public abstract void calcularArea();

    public abstract void calcularPerimetro();

    public double getArea() {
        return area;
    }

    public double getPerimetro() {
        return perimetro;
    }

}
