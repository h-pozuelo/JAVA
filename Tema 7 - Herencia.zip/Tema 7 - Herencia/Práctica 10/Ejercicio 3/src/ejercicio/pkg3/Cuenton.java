/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

/**
 *
 * @author Hugo
 */
public class Cuenton extends Cuenta {

    public Cuenton(String[] titulares, int totalTitulares, double saldo) {
        super(titulares, totalTitulares, saldo);
        this.interes = 4;
    }

}
