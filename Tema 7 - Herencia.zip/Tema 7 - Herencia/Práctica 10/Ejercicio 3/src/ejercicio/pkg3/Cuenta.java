/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Cuenta {

    protected int interes = 3;
    private static int totalIdentificador;
    private int identificador;
    private static int totalCuentas;
    private String[] titulares = new String[3];
    private int totalTitulares;
    private double saldo;

    public Cuenta(String[] titulares, int totalTitulares, double saldo) {
        this.totalIdentificador += 1;
        this.identificador = this.totalIdentificador;
        this.totalCuentas += 1;
        this.titulares = titulares;
        this.totalTitulares = totalTitulares;
        this.saldo = saldo;
    }

    public static int getTotalCuentas() {
        return totalCuentas;
    }

    public int getInteres() {
        return interes;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String[] getTitulares() {
        return titulares;
    }

    public int getTotalTitulares() {
        return totalTitulares;
    }

    public static void setTotalCuentas(int totalCuentas) {
        Cuenta.totalCuentas = totalCuentas;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "interes=" + interes + ", identificador=" + identificador + ", titulares=" + Arrays.toString(titulares) + ", totalTitulares=" + totalTitulares + ", saldo=" + saldo + '}';
    }

}
