/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package herenciaempleado;

/**
 *
 * @author Hugo
 */
public class HerenciaEmpleado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Empleado plantilla[] = new Empleado[3];
        // EN EL MISMO ARRAY PUEDO MEZCLAR Jefes Y Empleados. 
        plantilla[0] = new Jefe("Félix Muñoz", 200000, 2, "Estefanía Sanz");
        plantilla[1] = new Empleado("Amaya Uriarte", 100000, 1);
        plantilla[2] = new Empleado("Luis Ricote", 120000, 2);
        /*
        COMPROBAR SI DOS OBJETOS SON IGUALES UTILIZANDO EL MÉTODO equals 
        SI NO HUBIERA REDEFINIDO EL MÉTODO equals EN LA CLASE Empleado COMPARARÍA 
        LAS DIRECCIONES DE MEMORIA DE LOS 2 OBJETOS. 
         */
        if (plantilla[0].equals(plantilla[1])) {
            System.out.println("SI OCUPAN LA MISMA DIRECCIÓN DE MEMORIA. ");
        } else {
            System.out.println("NO OCUPAN LA MISMA DIRECCIÓN DE MEMORIA. ");
        }

        plantilla[1] = new Empleado("Luis Ricote", 100000, 1);

        if (plantilla[1].equals(plantilla[2])) {
            System.out.println("SI TIENEN EL MISMO NOMBRE. ");
        } else {
            System.out.println("NO TIENEN EL MISMO NOMBRE. ");
        }

        System.out.println(plantilla[0].getClass().getSimpleName()); // RETORNA EL NOMBRE DE LA CLASE A LA QUE PERTENECE EL OBJETO ALMACENADO EN LA CELDA 0. 

        int i;
        /*
        EJECUTA EL MÉTODO toString DEL Jefe O DEL Empleado DEPENDIENDO 
        DE LA CLASE A LA QUE PERTENEZA EL OBJETO GUARDADO EN plantilla[i]. 
         */
        for (i = 0; i < 3; i += 1) {
            System.out.println(plantilla[i].toString());
        }

        for (i = 0; i < 3; i += 1) {
            plantilla[i].aumentoSalario(5);
        }

        for (i = 0; i < 3; i += 1) {
            System.out.println(plantilla[i].toString());
        }

        // [HERENCIAEMPLEADO]
        
        // MOSTRAR TODOS LOS JEFES (CADA JEFE TIENE ASIGNADO UN AYUDANTE) 
        
        System.out.println("JEFES: ");
        for (i = 0; i < 3; i += 1) {
            if (plantilla[i] instanceof Jefe) {
                System.out.println(plantilla[i].toString());
            }
        }

        // MOSTRAR TODOS LOS AYUDANTES 
        
        // TENIENDO EN CUENTA QUE EL ARRAY PLANTILLA ES DE TIPO EMPLEADO 
        // ES NECESARIO REALIZAR UN CASTING (NO CONFUNDIR CON PARSE) DEL 
        // ARRAY PLANTILLA Y TRANSFORMARLO EN UN ARRAY DE TIPO JEFE PARA 
        // PODER ASÍ EJECUTAR LAS FUNCIONES PROPIAS DE UN JEFE. 
        
        System.out.println("AYUDANTES: ");
        for (i = 0; i < 3; i += 1) {
            if (plantilla[i].getClass().getSimpleName().equalsIgnoreCase("Jefe")) {
                System.out.println(((Jefe) (plantilla[i])).getAyudante());
            }
        }

    }

}
