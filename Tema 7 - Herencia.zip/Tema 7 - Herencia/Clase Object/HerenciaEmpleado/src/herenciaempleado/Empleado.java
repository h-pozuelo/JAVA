/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciaempleado;

import java.util.Objects;

/**
 *
 * @author Hugo
 */
public class Empleado {

    private String nombre;
    protected double salario;
    protected int antiguedad;

    public Empleado(String nombre, double salario, int antiguedad) {
        this.nombre = nombre;
        this.salario = salario;
        this.antiguedad = antiguedad;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSalario() {
        return salario;
    }

    public void aumentoSalario(double porcentaje) {

        this.salario += (this.salario * porcentaje) / 100;

    }

    public String toString() {

        String s = "\nNombre:" + nombre + ",sueldo:" + salario + ",antiguedad:" + antiguedad;

        return s;

    }

    /*
    REDEFINIMOS EL MÉTODO equals DE LA CLASE Object PARA QUE EN VEZ DE COMPARAR 
    SUS DIRECCIONES DE MEMORIA COMPARE UN ATRIBUTO ESPECÍFICO [nombre]. 
     */
    @Override
    public boolean equals(Object obj) { // obj HACE REFERENCIA AL OBJETO QUE PASAMOS. 

        if (this == obj) { // this HACE REFERENCIA AL OBJETO QUE EJECUTA LA FUNCIÓN. 
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (!(obj instanceof Empleado)) {
            return false;
        }
        /*
        if (getClass() != obj.getClass()) {
            return false;
        }
         */
        final Empleado other = (Empleado) obj; // obj CON CLASE Object TRANSFORMADO EN obj CON CLASE Empleado. 

        return (this.nombre == null) ? (other.nombre == null) : this.nombre.equals(other.nombre);
        /*
        if (this.nombre == null) {

            return (other.nombre != null);

        } else {

            return (this.nombre.equals(other.nombre));

        }
         */
    }

}
