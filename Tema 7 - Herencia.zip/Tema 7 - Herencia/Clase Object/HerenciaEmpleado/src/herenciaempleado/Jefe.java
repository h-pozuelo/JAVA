/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciaempleado;

/**
 *
 * @author Hugo
 */
public class Jefe extends Empleado {

    private String ayudante; // SÓLO LOS JEFES TIENEN AYUDANTE. 

    public Jefe(String nombre, double salario, int antiguedad, String ayudante) {
        super(nombre, salario, antiguedad); // ES LA PRIMERA LÍNEA DEL CONSTRUCTOR. 
        this.ayudante = ayudante;
    }

    // ESTE MÉTODO SÓLO LO TIENEN LOS JEFES. 
    public String getAyudante() {
        return ayudante;
    }

    // ESTE MÉTODO REDEFINE EL MÉTODO DE Empleado MISMO PROTOTIPO PERO DIFERENTE CONTENIDO. 
    public void aumentoSalario(double porcentaje) {

        double bonus = 0.5 * antiguedad;

        salario += (salario * (bonus + porcentaje)) / 100;

    }

    // ESTE MÉTODO REDEFINE EL MÉTODO toString DE Empleado. 
    public String toString() {
        // LLAMAMOS AL MÉTODO toString DEL Empleado Y LE AÑADIMOS LA INFORMACIÓN DEL Jefe. 
        // EN ESTE CASO EL AYUDANTE. 
        String s = super.toString() + ",ayudante:" + ayudante;

        return s;

    }

}
