/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.persona;

/**
 *
 * @author Hugo
 */
public class EjemploPersona {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Direccion direccion;
        direccion = new Direccion("Bohonal", 132, "3ºA", "28053", "Madrid", "España");

        Alumno alumnoHugo = new Alumno(23, "Desarrollo de Aplicaciones Web", 1, "Hugo Pozuelo Martínez", "02295085F", direccion, "696289215");
        Alumno alumnoRuben = new Alumno(24, "Administración de Sistemas Informáticos en Red", 2, "Rubén Pozuelo Martínez", "02295084Y", new Direccion("Bohonal", 132, "3ºA", "28053", "Madrid", "España"), "616981174");

        System.out.println(alumnoHugo.getNombre());
        System.out.println(alumnoHugo.getCurso() + " de " + alumnoHugo.getCiclo());
        System.out.println(alumnoHugo.getDireccion().getProvincia());
        System.out.println("\n" + alumnoHugo.toString() + "\n");

        System.out.println(alumnoRuben.getNombre());
        System.out.println(alumnoRuben.getCurso() + " de " + alumnoRuben.getCiclo());
        System.out.println(alumnoRuben.getDireccion().getProvincia());
        System.out.println("\n" + alumnoRuben.toString() + "\n");

    }

}
