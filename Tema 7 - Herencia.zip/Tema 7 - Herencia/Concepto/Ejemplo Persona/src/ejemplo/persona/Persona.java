/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.persona;

/**
 *
 * @author Hugo
 */
public class Persona {

    private String nombre;
    private String dni;
    private Direccion direccion;
    private String telefono;

    public Persona(String nombre, String dni, Direccion direccion, String telefono) {
        this.nombre = nombre;
        this.dni = dni;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDni() {
        return dni;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    @Override
    public String toString() {
        return "\nPersona: "
                + "\nNombre: " + nombre
                + "\nDNI: " + dni
                + direccion.toString() // BASTARÍA CON PONER direccion EN VEZ DE direccion.toString() 
                + "\nTelefono: " + telefono;
    }

}
