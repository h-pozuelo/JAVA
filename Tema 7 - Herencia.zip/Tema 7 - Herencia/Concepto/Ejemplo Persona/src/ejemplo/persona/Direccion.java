/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.persona;

/**
 *
 * @author Hugo
 */
public class Direccion {

    private String calle;
    private int numero;
    private String piso;
    private String codigoPostal;
    private String provincia;
    private String pais;

    public Direccion(String calle, int numero, String piso, String codigoPostal, String provincia, String pais) {
        this.calle = calle;
        this.numero = numero;
        this.piso = piso;
        this.codigoPostal = codigoPostal;
        this.provincia = provincia;
        this.pais = pais;
    }

    public String getCalle() {
        return calle;
    }

    public int getNumero() {
        return numero;
    }

    public String getPiso() {
        return piso;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public String getProvincia() {
        return provincia;
    }

    public String getPais() {
        return pais;
    }

    @Override
    public String toString() {
        return "\nDireccion: "
                + "\nCalle: " + calle
                + "\nNumero: " + numero
                + "\nPiso: " + piso
                + "\nCodigo Postal: " + codigoPostal
                + "\nProvincia: " + provincia
                + "\nPais: " + pais;
    }

}
