/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.persona;

/**
 *
 * @author Hugo
 */
public class Profesor extends Persona {

    private String titulacion;
    private boolean tutor;
    private String curso;

    public Profesor(String titulacion, boolean tutor, String curso, String nombre, String dni, Direccion direccion, String telefono) {
        super(nombre, dni, direccion, telefono);
        this.titulacion = titulacion;
        this.tutor = tutor;
        this.curso = curso;
    }

    public String getTitulacion() {
        return titulacion;
    }

    public boolean isTutor() {
        return tutor;
    }

    public String getCurso() {
        return curso;
    }

    @Override
    public String toString() {
        return "Profesor: "
                + super.toString()
                + "\nTitulacion: " + titulacion
                + "\nTutor: " + tutor
                + "\nCurso: " + curso;
    }

}
