/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplo.persona;

/**
 *
 * @author Hugo
 */
public class Alumno extends Persona {

    private int numeroMatricula;
    private String ciclo;
    private int curso;

    public Alumno(int numeroMatricula, String ciclo, int curso, String nombre, String dni, Direccion direccion, String telefono) {
        super(nombre, dni, direccion, telefono);
        this.numeroMatricula = numeroMatricula;
        this.ciclo = ciclo;
        this.curso = curso;
    }

    public int getNumeroMatricula() {
        return numeroMatricula;
    }

    public String getCiclo() {
        return ciclo;
    }

    public int getCurso() {
        return curso;
    }

    @Override
    public String toString() {
        return "Alumno: "
                + super.toString()
                + "\nNumero de Matricula: " + numeroMatricula
                + "\nCiclo: " + ciclo
                + "\nCurso: " + curso;
    }

}
