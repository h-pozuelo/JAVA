/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciaanimales;

/**
 *
 * @author Hugo
 */
public class Antilope extends Herbivoro {

    private double velocidad;

    public Antilope(double velocidad, String nombre, int edad, String tipoHierba) {
        super(nombre, edad, tipoHierba);
        this.velocidad = velocidad;
    }

    @Override
    public String toString() {
        return "Antilope: \n" + super.toString() + "\nVelocidad: " + velocidad;
    }

}
