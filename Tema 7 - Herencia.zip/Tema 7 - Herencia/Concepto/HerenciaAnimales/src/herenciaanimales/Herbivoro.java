/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciaanimales;

/**
 *
 * @author Hugo
 */
public class Herbivoro extends Animal {

    private String tipoHierba;

    public Herbivoro(String nombre, int edad, String tipoHierba) {
        super(nombre, edad);
        this.tipoHierba = tipoHierba;
    }

    public String getTipoHierba() {
        return tipoHierba;
    }

    public void setTipoHierba(String tipoHierba) {
        this.tipoHierba = tipoHierba;
    }

    @Override
    public String toString() {
        return "Herbivoro: \n" + super.toString() + "\nTipo de Hierba: " + tipoHierba;
    }

}
