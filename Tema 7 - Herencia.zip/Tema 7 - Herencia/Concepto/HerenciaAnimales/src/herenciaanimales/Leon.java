/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciaanimales;

/**
 *
 * @author Hugo
 */
public class Leon extends Carnivoro {

    private String color;

    public Leon(String color, String nombre, int edad, double KgCarne) {
        super(nombre, edad, KgCarne);
        this.color = color;
    }

    @Override
    public String toString() {
        return "Leon: \n" + super.toString() + "\nColor: " + color;
    }

}
