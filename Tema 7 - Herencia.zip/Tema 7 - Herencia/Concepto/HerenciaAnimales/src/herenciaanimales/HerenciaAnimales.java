/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package herenciaanimales;

/**
 *
 * @author Hugo
 */
public class HerenciaAnimales {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Animal animal;
        Carnivoro carnivoro;
        Herbivoro herbivoro;
        Antilope antilope = new Antilope(75, "Antilópez", 4, "Hierba");
        Leon leon = new Leon("Blanco", "Simba", 6, 90);

        animal = new Animal("Delfín", 2);
        carnivoro = new Carnivoro("Leopardo", 5, 50);
        herbivoro = new Herbivoro("Conejo", 3, "Heno");

        System.out.println(animal.toString() + "\n");
        System.out.println(carnivoro.toString() + "\n");
        System.out.println(herbivoro.toString() + "\n");
        System.out.println(leon.toString() + "\n");
        System.out.println(antilope.toString() + "\n");

    }

}
