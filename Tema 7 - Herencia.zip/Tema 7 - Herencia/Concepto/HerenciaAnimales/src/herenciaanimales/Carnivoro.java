/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciaanimales;

/**
 *
 * @author Hugo
 */
public class Carnivoro extends Animal {

    private double KgCarne;

    public Carnivoro(String nombre, int edad, double KgCarne) {
        super(nombre, edad);
        this.KgCarne = KgCarne;
    }

    @Override
    public String toString() {
        /*
        String cadena = super.toString();
        return cadena + "\nKg. Carne: " + KgCarne;
         */
        return "Carnivoro: \n" + super.toString() + "\nKg. Carne: " + KgCarne;
    }

}
