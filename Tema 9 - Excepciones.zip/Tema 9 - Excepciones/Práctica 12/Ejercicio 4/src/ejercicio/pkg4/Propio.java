/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public class Propio extends Empleado {

    private double beneficiosIndividuales;
    private double bonificacion;

    public Propio(double bonificacion, int identificador, String nombre, String dni, Direccion direccion, String telefono) {
        super(identificador, nombre, dni, direccion, telefono);
        this.bonificacion = bonificacion;
        this.precioHora = 15;

    }

    public void setBeneficiosIndividuales(double beneficiosIndividuales) {
        this.beneficiosIndividuales = beneficiosIndividuales;
    }

    @Override
    public String toString() {
        return "Propio{" + "bonificacion=" + bonificacion + ", beneficiosIndividuales=" + beneficiosIndividuales + ", empleado=" + super.toString() + '}';
    }

    public double pagar() {

        this.salario = (this.cantidadHoras * this.precioHora) + this.bonificacion + this.beneficiosIndividuales;

        this.cantidadHoras = 0;

        return this.salario;

    }

}
