/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public class NoExisteEmpleadoPropio extends Exception {

    public NoExisteEmpleadoPropio(String message) {
        super(message);
    }

}
