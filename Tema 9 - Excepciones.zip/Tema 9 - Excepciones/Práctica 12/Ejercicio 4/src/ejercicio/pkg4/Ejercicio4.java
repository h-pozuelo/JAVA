/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg4;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio4 {

    static Vector<Empleado> empleados = new Vector<Empleado>();
    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion;
        sc.useLocale(Locale.ENGLISH);

        do {

            opcion = menu();

            switch (opcion) {

                case 1:

                    int tipoEmpleado = 0;

                    do {

                        try {

                            System.out.println("INDIQUE TIPO DE EMPLEADO: "
                                    + "\n\t1. EMPLEADO PROPIO "
                                    + "\n\t2. EMPLEADO EXTERNO ");
                            tipoEmpleado = sc.nextInt();

                            if (tipoEmpleado < 1 || tipoEmpleado > 2) {

                                System.out.println("TIPO DE EMPLEADO NO VÁLIDO. ");

                            }

                        } catch (InputMismatchException e) {

                            sc.nextLine();

                            System.out.println("NO HAS INTRODUCIDO UN NÚMERO. ");

                        }

                    } while (tipoEmpleado < 1 || tipoEmpleado > 2);

                    System.out.println("INTRODUZCA NOMBRE: ");
                    sc.nextLine();
                    String nombre = sc.nextLine();

                    System.out.println("INTRODUZCA DNI: ");
                    String dni = sc.nextLine();

                    System.out.println("INTRODUZCA CALLE: ");
                    String calle = sc.nextLine();

                    int numero;

                    while (true) {

                        try {

                            System.out.println("INTRODUZCA NÚMERO: ");
                            numero = sc.nextInt();

                            break;

                        } catch (InputMismatchException e) {

                            sc.nextLine();

                            System.out.println("NO HAS INTRODUCIDO UN NÚMERO. ");

                        }

                    }

                    System.out.println("INTRODUZCA PISO: ");
                    sc.nextLine();
                    String piso = sc.nextLine();

                    System.out.println("INTRODUZCA CÓDIGO POSTAL: ");
                    String codigoPostal = sc.nextLine();

                    System.out.println("INTRODUZCA PROVINCIA: ");
                    String provincia = sc.nextLine();

                    System.out.println("INTRODUZCA PAÍS: ");
                    String pais = sc.nextLine();

                    Direccion direccion = new Direccion(calle, numero, piso, codigoPostal, provincia, pais);

                    System.out.println("INTRODUZCA TELÉFONO: ");
                    String telefono = sc.nextLine();

                    if (tipoEmpleado == 1) {

                        double bonificacion = -1;

                        do {

                            try {

                                System.out.println("INTRODUZCA BONIFICACIÓN: ");
                                bonificacion = sc.nextDouble();

                                if (bonificacion < 0) {

                                    System.out.println("CANTIDAD NO VÁLIDA. ");

                                }

                            } catch (InputMismatchException e) {

                                sc.nextLine();

                                System.out.println("NO HAS INTRODUCIDO UN NÚMERO. ");

                            }

                        } while (bonificacion < 0);

                        empleados.add(new Propio(bonificacion, (empleados.size() + 1), nombre, dni, direccion, telefono));

                    } else {

                        System.out.println("INTRODUZCA PROCEDENCIA: ");
                        String procedencia = sc.nextLine();

                        empleados.add(new Externo(procedencia, (empleados.size() + 1), nombre, dni, direccion, telefono));

                    }

                    break;

                case 2:

                    sc.nextLine();

                    System.out.println("INDIQUE NOMBRE DE EMPLEADO: ");
                    nombre = sc.nextLine();

                    try {

                        int encontrado = buscarEmpleado(nombre);

                        boolean fichar;

                        double horas;

                        boolean valido = false;

                        do {

                            try {

                                System.out.println("INTRODUZCA CANTIDAD DE HORAS: ");
                                horas = sc.nextDouble();

                                valido = empleados.get(encontrado).fichar(horas);

                                if (!valido) {

                                    System.out.println("CANTIDAD DE HORAS NO VÁLIDA. ");

                                }

                            } catch (InputMismatchException e) {

                                sc.nextLine();

                                System.out.println("NO HAS INTRODUCIDO UN NÚMERO. ");

                            }

                        } while (!valido);

                    } catch (NoExisteEmpleado e) {

                        System.out.println(e.getMessage());

                    }

                    break;

                case 3:

                    if (empleados.size() != 0) {

                        try {

                            int cantidadPropios = buscarEmpleadoPropio();

                            double beneficiosTotales = 0;

                            do {

                                try {

                                    System.out.println("INTRODUZCA BENEFICIOS TOTALES: ");
                                    beneficiosTotales = sc.nextDouble();

                                    if (beneficiosTotales <= 0) {

                                        System.out.println("CANTIDAD NO VÁLIDA. ");

                                    }

                                } catch (InputMismatchException e) {

                                    sc.nextLine();

                                    System.out.println("NO HAS INTRODUCIDO UN NÚMERO. ");

                                }

                            } while (beneficiosTotales <= 0);

                            double beneficiosIndividuales = calcularBeneficios(beneficiosTotales, cantidadPropios);

                            for (int i = 0; i < empleados.size(); i += 1) {

                                if (empleados.get(i).getClass().getSimpleName().equalsIgnoreCase("Propio")) {

                                    ((Propio) empleados.get(i)).setBeneficiosIndividuales(beneficiosIndividuales);

                                }

                            }

                            System.out.println("CANTIDAD DE BENEFICIOS INDIVIDUALES: " + beneficiosIndividuales + " €");

                        } catch (NoExisteEmpleadoPropio e) {

                            System.out.println(e.getMessage());

                        }

                    } else {

                        System.out.println("AÚN NO HAS DADO DE ALTA A NINGÚN EMPLEADO. ");

                    }

                    break;

                case 4:

                    for (int i = 0; i < empleados.size(); i += 1) {

                        System.out.println("EMPLEADO CON IDENTIFICADOR " + empleados.get(i).getIdentificador() + ": " + empleados.get(i).pagar() + " €");

                    }

                    break;

                case 5:

                    System.out.println("LISTA DE EMPLEADOS: ");

                    for (int i = 0; i < empleados.size(); i += 1) {

                        System.out.println(empleados.get(i).toString());

                    }

                    break;

            }

        } while (opcion != 6);

    }

    public static int menu() {

        int opcion = 0;

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. DAR DE ALTA UN EMPLEADO "
                    + "\n\t2. FICHAR UN EMPLEADO "
                    + "\n\t3. REPARTO DE BENEFICIOS "
                    + "\n\t4. PAGAR A TODOS LOS EMPLEADOS "
                    + "\n\t5. MOSTRAR TODOS LOS EMPLEADOS "
                    + "\n\t6. SALIR DEL PROGRAMA ");

            try {

                opcion = sc.nextInt();

                if (opcion < 1 || opcion > 6) {

                    System.out.println("OPCIÓN NO VÁLIDA.");

                }

            } catch (InputMismatchException e) {

                sc.nextLine();

                System.out.println("NOS HAS INTRODUCIDO UN NÚMERO. ");

            }

        } while (opcion < 1 || opcion > 6);

        return opcion;

    }

    public static int buscarEmpleado(String nombre) throws NoExisteEmpleado {

        for (int i = 0; i < empleados.size(); i += 1) {

            if (empleados.get(i).getNombre().equalsIgnoreCase(nombre)) {

                return i;

            }

        }

        throw new NoExisteEmpleado("NOMBRE DE EMPLEADO NO ENCONTRADO. ");

    }

    public static int buscarEmpleadoPropio() throws NoExisteEmpleadoPropio {

        int cantidadPropios = 0;

        for (int i = 0; i < empleados.size(); i += 1) {

            if (empleados.get(i) instanceof Propio) {

                cantidadPropios++;

            }

        }

        if (cantidadPropios == 0) {

            throw new NoExisteEmpleadoPropio("NO EXISTE NINGÚN EMPLEADO PROPIO. ");

        } else {

            return cantidadPropios;

        }

    }

    public static double calcularBeneficios(double beneficiosTotales, int cantidadPropios) {

        return beneficiosTotales / cantidadPropios;

    }

}
