/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public abstract class Empleado {

    private int identificador;
    private String nombre;
    private String dni;
    private Direccion direccion;
    private String telefono;
    protected double cantidadHoras;
    protected double salario;
    protected double precioHora;

    public Empleado(int identificador, String nombre, String dni, Direccion direccion, String telefono) {
        this.identificador = identificador;
        this.nombre = nombre;
        this.dni = dni;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public boolean fichar(double horas) {

        if (horas > 0) {

            this.cantidadHoras += horas;

            System.out.println("TOTAL DE HORAS: " + this.cantidadHoras);

            return true;

        }

        return false;

    }

    public int getIdentificador() {
        return identificador;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Empleado{" + "identificador=" + identificador + ", nombre=" + nombre + ", dni=" + dni + ", direccion=" + direccion + ", telefono=" + telefono + ", cantidadHoras=" + cantidadHoras + ", salario=" + salario + ", precioHora=" + precioHora + '}';
    }

    public abstract double pagar();

}
