/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio.pkg4;

/**
 *
 * @author Hugo
 */
public class Direccion {

    private String calle;
    private int numero;
    private String piso;
    private String codigoPostal;
    private String provincia;
    private String pais;

    public Direccion(String calle, int numero, String piso, String codigoPostal, String provincia, String pais) {
        this.calle = calle;
        this.numero = numero;
        this.piso = piso;
        this.codigoPostal = codigoPostal;
        this.provincia = provincia;
        this.pais = pais;
    }

    @Override
    public String toString() {
        return "Direccion{" + "calle=" + calle + ", numero=" + numero + ", piso=" + piso + ", codigoPostal=" + codigoPostal + ", provincia=" + provincia + ", pais=" + pais + '}';
    }

}
