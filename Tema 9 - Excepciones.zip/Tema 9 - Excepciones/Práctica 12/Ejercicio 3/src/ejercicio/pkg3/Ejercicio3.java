/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg3;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio3 {

    static Scanner sc = new Scanner(System.in);
    static Random r = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numeros[] = {r.nextInt(10), r.nextInt(10), r.nextInt(10), r.nextInt(10), r.nextInt(10)};
        int posiciones[] = new int[numeros.length];
        int numeroCelda = -1;
        boolean finalizarEjecucion = false;

        do {

            try {

                System.out.println("INTRODUZCA NÚMERO DE LA CELDA A MOSTRAR: \n" + Arrays.toString(numeros) + "\nINTRODUZCA 0 PARA FINALIZAR LA EJECUCIÓN. ");
                numeroCelda = sc.nextInt();

                if (numeroCelda != 0) {

                    try {

                        System.out.println(numeros[numeroCelda - 1]);

                        posiciones[numeroCelda - 1] = 1;

                        for (int i = 0; i < posiciones.length; i += 1) {

                            if (posiciones[i] == 1) {

                                finalizarEjecucion = true;

                            } else {

                                finalizarEjecucion = false;

                                break;

                            }

                        }

                    } catch (ArrayIndexOutOfBoundsException e) { // EN ESTE CASO NO ES NECESARIO LIMPIAR EL BUFFER DADO QUE EL sc.nextInt() NO SE ENCUENTRA DENTRO DEL try { sc.nextInt() }. 

                        System.out.println("INTRODUZCA UN NÚMERO ENTRE [ 1 - " + numeros.length + " ].");

                    }

                }

            } catch (InputMismatchException e) {

                sc.nextLine(); // EN ESTE CASO ES NECESARIO LIMPIAR EL BUFFER DADO QUE EL sc.nextInt() SE ENCUENTRA DENTRO DEL try { sc.nextInt() }. 

                System.out.println("NOS HAS INTRODUCIDO UN NÚMERO. ");

            }

        } while (numeroCelda != 0 && finalizarEjecucion != true);

    }

}
