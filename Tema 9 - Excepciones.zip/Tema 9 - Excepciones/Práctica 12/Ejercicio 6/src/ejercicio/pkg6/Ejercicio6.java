/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg6;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio6 {

    static char letras[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String dni;
        int validarDNI;

        Scanner sc = new Scanner(System.in);

        do {

            System.out.println("INTRODUZCA DNI: ");
            dni = sc.nextLine();

            validarDNI = validarDNI(dni);

            switch (validarDNI) {

                case 1:

                    System.out.println("EL TAMAÑO DEL DNI NO PUEDE SUPERAR LOS 9 CARACTERES. ");

                    break;

                case 2:

                    System.out.println("LOS OCHO PRIMEROS CARACTERES TIENEN QUE SER NÚMEROS. ");

                    break;

                case 3:

                    System.out.println("EL ÚLTIMO CARACTER TIENE QUE SE UNA LETRA. ");

                    break;

                case 4:

                    System.out.println("EL DNI INTRODUCIDO NO ES VÁLIDO. ");

                    break;

            }

        } while (validarDNI != 0);

    }

    public static int validarDNI(String dni) {

        if (dni.length() > 9) {

            return 1;

        }

        int numeros;

        try {

            numeros = Integer.parseInt(dni.substring(0, dni.length() - 1));

        } catch (NumberFormatException e) {

            return 2;

        }

        if (!Character.isLetter(dni.charAt(dni.length() - 1))) {

            return 3;

        }

        int numeroLetra = numeros % letras.length;

        if (letras[numeroLetra] != Character.toUpperCase(dni.charAt(dni.length() - 1))) {

            return 4;

        }

        return 0;

    }

}
