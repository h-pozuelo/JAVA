/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg2;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio2 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String cadena;
        int validarCadena;

        do {

            System.out.println("INTRODUZCA CADENA DE CARACTERES: ");
            cadena = sc.nextLine();

            validarCadena = validarCadena(cadena);

            switch (validarCadena) {

                case 1:

                    System.out.println("LA CADENA TIENE QUE TENER UNA LONGITUD DE SEIS CARACTERES. ");

                    break;

                case 2:

                    System.out.println("LOS CUATRO PRIMEROS CARACTERES TIENEN QUE SER NÚMEROS. ");

                    break;

                case 3:

                    System.out.println("LOS DOS ÚLTIMOS CARACTERES TIENEN QUE SER LETRAS. ");

                    break;

                case 4:

                    System.out.println("LA CADENA INTRODUCIDA ES VÁLIDA. ");

                    break;

            }

        } while (validarCadena != 4);

    }

    public static int validarCadena(String cadena) {

        if (cadena.length() != 6) {

            return 1;

        }

        try {

            String numeros = cadena.substring(0, 4);

            Integer.parseInt(numeros);

        } catch (NumberFormatException e) {

            return 2;

        }

        for (int i = 4; i < cadena.length(); i += 1) {

            // SI ME VALIDARÍA QUE EL CARACTER NO FUERA UN CARACTER ESPECIAL. ADEMÁS ME VALIDARÍA QUE EL CARACTER NO FUERA UN NÚMERO. 
            if (!Character.isLetter(cadena.charAt(i))) {

                return 3;

            }
            /*
            // NO ME VALIDARÍA QUE EL CARACTER NO FUERA UN CARACTER ESPECIAL. AUNQUE ME VALIDARÍA QUE EL CARACTER NO FUERA UN NÚMERO. 
            try {

                String caracteres = cadena.substring(i, (i + 1));

                Integer.parseInt(caracteres);

                return 3;

            } catch (NumberFormatException e) {

            }
             */
        }

        return 4;

    }

}
