/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.pkg1;

import java.util.*;

/**
 *
 * @author Hugo
 */
public class Ejercicio1 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numero, numerosCount = 0;
        double numerosTotal = 0;

        do {

            System.out.println("INTRODUZCA NÚMERO: ");
            numero = leerNumero("NOS HAS INTRODUCIDO UN NÚMERO. INTRODUZCA UN NÚMERO: ");

            if (numero != 0) {

                numerosCount++;
                numerosTotal += numero;

            }

        } while (numero != 0);

        double resultado = numerosTotal / numerosCount;

        System.out.println("MEDIA TOTAL: " + resultado);

    }

    public static int leerNumero(String mensajeError) {

        int numero = 0;
        boolean correcto = false;

        do {

            try {

                numero = sc.nextInt();

                correcto = true;

            } catch (InputMismatchException e) {

                sc.nextLine();

                System.out.println(mensajeError);

            }

        } while (!correcto);

        return numero;

    }

}
