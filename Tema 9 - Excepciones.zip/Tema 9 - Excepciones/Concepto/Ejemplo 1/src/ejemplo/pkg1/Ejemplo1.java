/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg1;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejemplo1 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean correcto = false;

        do {

            try { // AQUÍ INTRODUCIMOS TODO EL CÓDIGO EN EL QUE SE PUEDE PRODUCIR UNA EXCEPCIÓN. 

                System.out.println("INTRODUZCA NÚMERO: ");
                int numero = sc.nextInt(); // SI SE PRODUCE UNA EXPECIÓN NO SEGUIRÁ EJECUTANDO CÓDIGO. 

                correcto = true; // SI NO SE PRODUCE UNA EXCEPCIÓN SE PONDRA LA VARIABLE [correcto = true]. 

                double doble = numero * 2;

                System.out.println("EL DOBLE ES: " + doble);

            } catch (Exception e) { // SOLO EJECUTA EL MENSAJE SI LA EXCEPCIÓN COINCIDE. SE PUEDE PONER Exception ASÍ COMO EL NOMBRE DE LA EXCEPCIÓN QUE SE HA PRODUCIDO. 

                sc.nextLine(); // SI NO SE BORRA EL BUFFER SE FORMARÍA UN BUCLE INFINITO. 

                System.out.println(e.getClass().getSimpleName()); // TE MUESTRA EL NOMBRE DE LA EXCEPCIÓN QUE SE HA PRODUCIDO. 
                System.out.println(e.toString());
                System.out.println("NO HAS INTRODUCIDO UN NUMERO. ");

            }

        } while (!correcto);

        System.out.println("FIN DEL PROGRAMA. ");

    }

}
