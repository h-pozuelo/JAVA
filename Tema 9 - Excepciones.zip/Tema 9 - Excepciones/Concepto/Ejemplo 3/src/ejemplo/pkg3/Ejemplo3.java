/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg3;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejemplo3 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        boolean correcto = false;
        int dividendo, divisor;

        do {

            System.out.println("INTRODUZCA DIVIDENDO: ");
            dividendo = leerNumero("NOS HAS INTRODUCIDO UN NÚMERO. INTRODUZCA UN NÚMERO: ");

        } while (dividendo < 0);

        do {

            do {

                System.out.println("INTRODUZCA DIVISOR: ");
                divisor = leerNumero("NOS HAS INTRODUCIDO UN NÚMERO. INTRODUZCA UN NÚMERO: ");

            } while (divisor < 0);

            try {

                double division = dividendo / divisor;

                correcto = true;

                System.out.println("LA DIVISIÓN ES: " + division);

            } catch (ArithmeticException e) {

                sc.nextLine();

                System.out.println("NO SE PUEDE DIVIDIR ENTRE 0. ");

            }

        } while (!correcto);

        System.out.println("FIN DEL PROGRAMA. ");

    }

    public static int leerNumero(String mensajeError) {

        int numero = 0;
        boolean correcto = false;

        do {

            try {

                numero = sc.nextInt();

                correcto = true;

            } catch (InputMismatchException e) {

                sc.nextLine();

                System.out.println(mensajeError);

            }

        } while (!correcto);

        return numero;

    }

}
