/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.pkg2;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Hugo
 */
public class Ejemplo2 {

    static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numero;

        do {

            System.out.println("INTRODUZCA NÚMERO: ");
            numero = leerNumero("NOS HAS INTRODUCIDO UN NÚMERO. INTRODUZCA UN NÚMERO: ");

            if (numero < 0) {

                System.out.println("NOS HAS INTRODUCIDO UN NÚMERO POSITIVO. ");

            }

        } while (numero < 0);

        double doble = numero * 2;

        System.out.println("EL DOBLE ES: " + doble);

        System.out.println("FIN DEL PROGRAMA. ");

    }

    public static int leerNumero(String mensajeError) {

        int numero = 0;
        boolean correcto = false;

        do {

            try {

                numero = sc.nextInt();

                correcto = true;

            } catch (InputMismatchException e) {

                sc.nextLine();

                System.out.println(mensajeError);

            }

        } while (!correcto);

        return numero;

    }

}
