/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.colegio;

import bbdd.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import modelos.Alumno;
import modelos.Curso;
import modelos.Tutor;

/**
 *
 * @author Hugo
 */
public class EjemploColegio {

    static Scanner sc = new Scanner(System.in);
    static BD_Colegio bd = new BD_Colegio("colegio");
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        sc.useLocale(Locale.ENGLISH);

        do {

            System.out.println("INDIQUE UNA OPCIÓN: "
                    + "\n\t1. DAR DE ALTA UN ALUMNO "
                    + "\n\t2. DAR DE ALTA UN CURSO "
                    + "\n\t3. DAR DE BAJA UN ALUMNO "
                    + "\n\t4. LISTAR ALUMNOS POR CURSO "
                    + "\n\t5. LISTAR CURSOS DISPONIBLES "
                    + "\n\t6. CONSULTAR INFORMACIÓN DE UN ALUMNO "
                    + "\n\t7. CONSULTAR TUTOR DE UN CURSO "
                    + "\n\t8. LISTAR ALUMNOS POR TUTOR "
                    + "\n\t9. SALIR DEL PROGRAMA ");

            try {

                opcion = sc.nextInt();

                if (opcion < 1 || opcion > 9) {

                    System.out.println("LA OPCIÓN INDICADA NO ES VÁLIDA. ");
                    opcion = 0;

                }

            } catch (InputMismatchException e) {

                System.out.println("DEBES INDICAR UN NÚMERO ENTRE [ 1 - 9 ]. ");
                opcion = 0;

            }

            sc.nextLine();

            switch (opcion) {

                case 1:

                    System.out.println("INTRODUZCA NOMBRE COMPLETO: ");
                    String nombre = sc.nextLine();

                    System.out.println("INTRODUZCA NÚMERO DE TELÉFONO: ");
                    String telefono = sc.nextLine();

                    System.out.println("INTRODUZCA DNI: ");
                    String dni = sc.nextLine();

                    System.out.println("INTRODUZCA NÚMERO DE MATRÍCULA: ");
                    int matricula = sc.nextInt();

                    Vector<Curso> cursos;

                    try {

                        cursos = bd.listadoCursos();

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (cursos == null) {

                        System.out.println("NO SE ENCUENTRAN CURSOS DISPONIBLES. ");
                        break;

                    }

                    System.out.println("LISTADO DE CURSOS: ");

                    for (int i = 0; i < cursos.size(); i += 1) {

                        System.out.println(cursos.get(i).toString());

                    }

                    System.out.println("INDIQUE EL CURSO CORRESPONDIENTE: ");
                    String nombreCurso = sc.next();

                    Alumno alumno = new Alumno(dni, nombre, nombreCurso, matricula, telefono);

                    int filas;

                    try {

                        filas = bd.agregarAlumno(alumno);

                        switch (filas) {

                            case 1:
                                System.out.println("LA ALTA SE HA REALIZADO CORRECTAMENTE. ");
                                break;

                            case 0:
                                System.out.println("NO SE HA PODIDO DAR DE ALTA EL ALUMNO. ");
                                break;

                        }

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

                    }

                    break;

                case 2:

                    System.out.println("INTRODUZCA NOMBRE DEL CURSO: ");
                    nombreCurso = sc.nextLine();

                    System.out.println("INTRODUZCA DESCRIPCIÓN DEL CURSO: ");
                    String descripcion = sc.nextLine();

                    System.out.println("INTRODUZCA AULA DEL CURSO: ");
                    String aula = sc.nextLine();

                    Curso curso = new Curso(descripcion, nombreCurso, aula);

                    filas = 0;

                    try {

                        filas = bd.agregarCurso(curso);

                        switch (filas) {

                            case 1:
                                System.out.println("LA ALTA SE HA REALIZADO CORRECTAMENTE. ");
                                break;

                            case 0:
                                System.out.println("NO SE HA PODIDO DAR DE ALTA EL CURSO. ");
                                break;

                        }

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

                    }

                    break;

                case 3:

                    System.out.println("INDIQUE EL DNI DEL ALUMNO CORRESPONDIENTE: ");
                    dni = sc.nextLine();

                    filas = 0;

                    try {

                        filas = bd.borrarAlumno(dni);

                        switch (filas) {

                            case 1:
                                System.out.println("LA BAJA SE HA REALIZADO CORRECTAMENTE. ");
                                break;

                            case 0:
                                System.out.println("NO SE HA PODIDO DAR DE BAJA EL ALUMNO. ");
                                break;

                        }

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

                    }

                    break;

                case 4:

                    cursos = null;

                    try {

                        cursos = bd.listadoCursos();

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (cursos == null) {

                        System.out.println("NO SE ENCUENTRAN CURSOS DISPONIBLES. ");
                        break;

                    }

                    System.out.println("LISTADO DE CURSOS: ");

                    for (int i = 0; i < cursos.size(); i += 1) {

                        System.out.println(cursos.get(i).toString());

                    }

                    System.out.println("INDIQUE EL CURSO CORRESPONDIENTE: ");
                    nombreCurso = sc.nextLine();

                    Vector<Alumno> alumnos = null;

                    try {

                        alumnos = bd.alumnosCurso(nombreCurso);

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    System.out.println("LISTADO DE ALUMNOS POR CURSO: ");

                    for (int i = 0; i < alumnos.size(); i += 1) {

                        System.out.println(alumnos.get(i).toString());

                    }

                    break;

                case 5:

                    cursos = null;

                    try {

                        cursos = bd.listadoCursos();

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (cursos == null) {

                        System.out.println("NO SE ENCUENTRAN CURSOS DISPONIBLES. ");
                        break;

                    }

                    System.out.println("LISTADO DE CURSOS: ");

                    for (int i = 0; i < cursos.size(); i += 1) {

                        System.out.println(cursos.get(i).toString());

                    }

                    break;

                case 6:

                    alumno = null;

                    System.out.println("INDIQUE EL DNI DEL ALUMNO CORRESPONDIENTE: ");
                    dni = sc.nextLine();

                    try {

                        alumno = bd.informacionAlumno(dni);

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (alumno == null) {

                        System.out.println("EL DNI DEL ALUMNO INDICADO NO SE ENCUENTRA EN LA BASE DE DATOS. ");
                        break;

                    }

                    System.out.println(alumno.toString());

                    break;

                case 7:

                    cursos = null;

                    try {

                        cursos = bd.listadoCursos();

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (cursos == null) {

                        System.out.println("NO SE ENCUENTRAN CURSOS DISPONIBLES. ");
                        break;

                    }

                    System.out.println("LISTADO DE CURSOS: ");

                    for (int i = 0; i < cursos.size(); i += 1) {

                        System.out.println(cursos.get(i).toString());

                    }

                    System.out.println("INDIQUE EL CURSO CORRESPONDIENTE: ");
                    nombreCurso = sc.nextLine();

                    Tutor tutor = null;

                    try {

                        tutor = bd.tutorCurso(nombreCurso);

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (tutor == null) {

                        System.out.println("EL CURSO [ " + nombreCurso.toUpperCase() + " ] NO TIENE NINGÚN TUTOR ASIGNADO. ");
                        break;

                    }

                    System.out.println("EL CURSO [ " + nombreCurso.toUpperCase() + " ] TIENE COMO TUTOR ASIGNADO [ " + tutor.getNombre().toUpperCase() + " ]. ");

                    break;

                case 8:

                    System.out.println("INDIQUE EL NOMBRE DEL TUTOR CORRESPONDIENTE: ");
                    nombre = sc.nextLine();

                    alumnos = null;

                    try {

                        alumnos = bd.alumnosTutor(nombre);

                    } catch (ErrorBaseDatos e) {

                        System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());
                        break;

                    }

                    if (alumnos != null && !alumnos.isEmpty()) {

                        System.out.println("LISTADO DE ALUMNOS POR TUTOR: ");

                        for (int i = 0; i < alumnos.size(); i += 1) {

                            System.out.println(alumnos.get(i).toString());

                        }

                    }

                    break;

            }

        } while (opcion != 9);

    }

}
