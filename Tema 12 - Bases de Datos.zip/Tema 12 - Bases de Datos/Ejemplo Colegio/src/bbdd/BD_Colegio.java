/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.*;
import ejemplo.colegio.*;
import modelos.Alumno;
import modelos.Curso;
import modelos.Tutor;

/**
 *
 * @author Hugo
 */
public class BD_Colegio extends BD_Conector {

    private static Statement s;
    private static ResultSet reg;

    public BD_Colegio(String file) {
        super(file);
    }

    public int agregarAlumno(Alumno al) throws ErrorBaseDatos {

        String cadenaSQL = String.format("INSERT INTO alumnos VALUES('%1$s','%2$s','%3$s','%4$s','%5$s','%6$s')", al.getNombre(), al.getDni(), al.getTelefono(), al.getMatricula(), al.getCurso(), al.getFechaMatricula());

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            int filas = s.executeUpdate(cadenaSQL);
            s.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDE AGREGAR EL ALUMNO EN ESTE MOMENTO. ");

        }

    }

    public int agregarCurso(Curso curso) throws ErrorBaseDatos {

        String cadenaSQL = String.format("INSERT INTO cursos VALUES('%1$s','%2$s','%3$s')", curso.getCurso(), curso.getDescripcion(), curso.getAula());

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            int filas = s.executeUpdate(cadenaSQL);
            s.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDE AGREGAR EL CURSO EN ESTE MOMENTO. ");

        }

    }

    public int borrarAlumno(String dni) throws ErrorBaseDatos {

        String cadenaSQL = String.format("DELETE FROM alumnos WHERE dni='%1$s'", dni);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            int filas = s.executeUpdate(cadenaSQL);
            if (filas == 0) {
                System.out.println("NINGÚN ALUMNO COINCIDE CON LOS DATOS INDICADOS. ");
            }
            s.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDE ELIMINAR EL ALUMNO EN ESTE MOMENTO. ");

        }

    }

    public Vector<Alumno> alumnosCurso(String curso) throws ErrorBaseDatos {

        Vector<Alumno> v = new Vector<Alumno>();

        String cadenaSQL = String.format("SELECT * FROM alumnos WHERE curso='%1$s'", curso);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                java.sql.Date fecha = reg.getDate("fechaMatricula"); // EL DATO "fechaMatricula" QUE RECUPERAMOS DE LA BASE DE DATOS (MYSQL) ES DE TIPO sql.Date 
                LocalDate fechaBuena = fecha.toLocalDate(); // ES NECESARIO TRANSFORMAR EL TIPO DE DATO sql.Date A LocalDate 
                v.add(new Alumno(reg.getString("dni"), reg.getString("nombre"), reg.getString("curso"), reg.getInt("matricula"), reg.getString("telefono"), fechaBuena));
            }
            s.close();
            this.cerrar();
            return v;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDEN LISTAR LOS ALUMNOS POR CURSO EN ESTE MOMENTO. ");

        }

    }

    public Vector<Curso> listadoCursos() throws ErrorBaseDatos {

        Vector<Curso> v = new Vector<Curso>();

        String cadenaSQL = "SELECT * FROM cursos";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                v.add(new Curso(reg.getString("descripcion"), reg.getString("curso"), reg.getString("aula")));
            }
            s.close();
            this.cerrar();
            return v;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDEN LISTAR LOS CURSOS EN ESTE MOMENTO. ");

        }

    }

    public Alumno informacionAlumno(String dni) throws ErrorBaseDatos {

        Alumno al = null;

        String cadenaSQL = String.format("SELECT * FROM alumnos WHERE dni='%1$s'", dni);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                java.sql.Date fecha = reg.getDate("fechaMatricula");
                LocalDate fechaBuena = fecha.toLocalDate();
                al = new Alumno(reg.getString("dni"), reg.getString("nombre"), reg.getString("curso"), reg.getInt("matricula"), reg.getString("telefono"), fechaBuena);
            }
            s.close();
            this.cerrar();
            return al;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDE LISTAR LA INFORMACIÓN DEL ALUMNO EN ESTE MOMENTO. ");

        }

    }

    public Tutor tutorCurso(String curso) throws ErrorBaseDatos {

        Tutor tutor = null;

        String cadenaSQL = String.format("SELECT * FROM tutores WHERE curso='%1$s'", curso);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                tutor = new Tutor(reg.getString("dni"), reg.getString("nombre"), reg.getString("curso"));
            }
            s.close();
            this.cerrar();
            return tutor;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDE LISTAR LA INFORMACIÓN DEL TUTOR EN ESTE MOMENTO. ");

        }

    }

    public Vector<Alumno> alumnosTutor(String nombre) throws ErrorBaseDatos {

        String curso = "";

        String cadenaSQL = String.format("SELECT curso FROM tutores WHERE nombre='%1$s'", nombre);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                curso = reg.getString(1);
            }
            s.close();
            this.cerrar();

            if (!curso.equals("")) {

                Vector<Alumno> v = new Vector<Alumno>();

                cadenaSQL = String.format("SELECT * FROM alumnos WHERE curso='%1$s'", curso);

                System.out.println("INSTRUCCIÓN: " + cadenaSQL);

                try {

                    this.abrir();
                    s = c.createStatement();
                    reg = s.executeQuery(cadenaSQL);
                    while (reg.next()) {
                        java.sql.Date fecha = reg.getDate("fechaMatricula");
                        LocalDate fechaBuena = fecha.toLocalDate();
                        v.add(new Alumno(reg.getString("dni"), reg.getString("nombre"), reg.getString("curso"), reg.getInt("matricula"), reg.getString("telefono"), fechaBuena));
                    }
                    s.close();
                    this.cerrar();
                    return v;

                } catch (SQLException e) {

                    this.cerrar();
                    throw new ErrorBaseDatos("NO SE PUEDEN LISTAR LOS ALUMNOS POR TUTOR EN ESTE MOMENTO. ");

                }

            } else {

                return null;

            }

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("NO SE PUEDEN LISTAR LOS ALUMNOS POR TUTOR EN ESTE MOMENTO. ");

        }

    }

}
