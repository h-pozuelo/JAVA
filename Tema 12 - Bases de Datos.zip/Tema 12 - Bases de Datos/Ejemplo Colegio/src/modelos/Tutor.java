/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

/**
 *
 * @author Hugo
 */
public class Tutor extends Persona {

    public Tutor(String dni, String nombre, String curso) {
        super(dni, nombre, curso);
    }

}
