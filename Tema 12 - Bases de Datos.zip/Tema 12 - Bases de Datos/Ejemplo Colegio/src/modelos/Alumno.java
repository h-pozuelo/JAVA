/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 *
 * @author Hugo
 */
public class Alumno extends Persona {

    private int matricula;
    private String telefono;
    private LocalDate fechaMatricula;

    public Alumno(String dni, String nombre, String curso, int matricula, String telefono) {
        super(dni, nombre, curso);
        this.matricula = matricula;
        this.telefono = telefono;
        this.fechaMatricula = LocalDate.now();
    }

    public Alumno(String dni, String nombre, String curso, int matricula, String telefono, LocalDate fechaMatricula) {
        super(dni, nombre, curso);
        this.matricula = matricula;
        this.telefono = telefono;
        this.fechaMatricula = fechaMatricula;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public LocalDate getFechaMatricula() {
        return fechaMatricula;
    }

    public void setFechaMatricula(LocalDate fechaMatricula) {
        this.fechaMatricula = fechaMatricula;
    }

    @Override
    public String toString() {
        return super.toString() + ", " + matricula + ", " + telefono + ", " + parseFecha();
    }

    public String parseFecha() {

        DateTimeFormatter formatter;
        formatter = DateTimeFormatter.ofPattern("dd/LL/yyyy", Locale.getDefault());
        return fechaMatricula.format(formatter);

    }

}
