/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio.tarjetas;

import bbdd.BD_Tarjetas;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.Vector;
import modelos.Cuenta;
import modelos.Tarjeta;

/**
 *
 * @author Hugo
 */
public class EjercicioTarjetas {

    static Scanner sc = new Scanner(System.in);
    static BD_Tarjetas bd = new BD_Tarjetas("tarjetas");
    static int opcion;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        do {

            opcion = menu();

            switch (opcion) {

                case 1:
                    sc.nextLine();
                    altaCredito();
                    break;

                case 2:
                    sc.nextLine();
                    altaDebito();
                    break;

                case 3:
                    sacarCredito();
                    break;

                case 4:
                    sacarDebito();
                    break;

                case 5:
                    cargarMovimientos();
                    break;

                case 6:
                    sc.nextLine();
                    informacionTitular();
                    break;

                case 7:
                    importarMovimientos();
                    break;

            }

        } while (opcion != 8);

    }

    public static void altaCredito() {

        String dni;

        do {

            System.out.println("INTRODUZCA EL DNI DEL TITULAR DE LA CUENTA: ");
            dni = sc.nextLine().toUpperCase();

            if (!dni.matches("[0-9]{8}[a-zA-Z]{1}$")) {

                System.out.println("EL DNI INTRODUCIDO NO CUMPLE CON EL CRITERIO DE ENTRADA REQUERIDO. ");

            }

        } while (!dni.matches("[0-9]{8}[a-zA-Z]{1}$"));

        try {

            Vector<Cuenta> cuentas = bd.mostrarCuentas(dni); // SI DEVUELVE UN VECTOR VACÍO QUIERE DECIR QUE NO HA ENCONTRADO NINGUNA CUENTA 

            if (!cuentas.isEmpty()) { // SI NINGÚN TITULAR (DE TODAS LAS CUENTAS DISPONIBLES) CONTIENE EL DNI INDICADO NO SEGUIRÁ EJECUTANDO CÓDIGO 

                for (int i = 0; i < cuentas.size(); i += 1) {

                    System.out.println(cuentas.get(i).toString());

                }

                Cuenta cuenta; // NECESITO UN CONSTRUCTOR EN LA CLASE CUENTA AL QUE SOLO NECESITE PASARLE EL NÚMERO DE CUENTA 

                do {

                    System.out.println("INDIQUE UN NÚMERO DE CUENTA: ");
                    cuenta = new Cuenta(sc.nextInt());

                    if (cuentas.indexOf(cuenta) == -1) {

                        System.out.println("EL NÚMERO DE CUENTA INDICADO NO TIENE COMO TITULAR EL DNI " + dni + ". ");

                    }

                } while (cuentas.indexOf(cuenta) == -1); // NECESITO REDEFINIR EL MÉTODO EQUALS EN LA CLASE CUENTA PARA QUE PUEDA COMPARAR POR EL NÚMERO DE CUENTA 

                int numero;

                boolean existe;

                do {

                    System.out.println("INTRODUZCA UN NÚMERO PARA LA TARJETA DE CRÉDITO: ");
                    numero = sc.nextInt();

                    existe = bd.buscarTarjeta(numero) != null; // SI EL MÉTODO ".buscarTarjeta()" RETORNA NULL QUERRÁ DECIR QUE NO EXISTE [(null != null) = false] 

                    if (existe) {

                        System.out.println("EL NÚMERO PARA LA TARJETA DE CRÉDITO INTRODUCIDO YA SE ENCUENTRA EN USO. ");

                    }

                } while (existe);

                sc.nextLine();

                System.out.println("INDIQUE UN TITULAR PARA LA TARJETA DE CRÉDITO: ");
                String titular = sc.nextLine();

                System.out.println("INDIQUE UNA CLAVE PARA LA TARJETA DE CRÉDITO: ");
                String clave = sc.nextLine();

                double limite;

                do {

                    System.out.println("INTRODUZCA UN LÍMITE PARA LA TARJETA DE CRÉDITO: ");
                    limite = sc.nextDouble();

                    if (limite < 0) {

                        System.out.println("EL LÍMITE PARA LA TARJETA DE CRÉDITO NO PUEDE SER MENOR QUE CERO. ");

                    }

                } while (limite < 0);

                bd.altaTarjeta(numero, cuenta.getNumero(), titular, limite, "C", LocalDate.now().plusYears(1), clave, false);

            }

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static void altaDebito() {

        String dni;

        do {

            System.out.println("INTRODUZCA EL DNI DEL TITULAR DE LA CUENTA: ");
            dni = sc.nextLine().toUpperCase();

            if (!dni.matches("[0-9]{8}[a-zA-Z]{1}$")) {

                System.out.println("EL DNI INTRODUCIDO NO CUMPLE CON EL CRITERIO DE ENTRADA REQUERIDO. ");

            }

        } while (!dni.matches("[0-9]{8}[a-zA-Z]{1}$"));

        try {

            Vector<Cuenta> cuentas = bd.mostrarCuentas(dni); // SI DEVUELVE UN VECTOR VACÍO QUIERE DECIR QUE NO HA ENCONTRADO NINGUNA CUENTA 

            if (!cuentas.isEmpty()) { // SI NINGÚN TITULAR (DE TODAS LAS CUENTAS DISPONIBLES) CONTIENE EL DNI INDICADO NO SEGUIRÁ EJECUTANDO CÓDIGO 

                for (int i = 0; i < cuentas.size(); i += 1) {

                    System.out.println(cuentas.get(i).toString());

                }

                Cuenta cuenta; // NECESITO UN CONSTRUCTOR EN LA CLASE CUENTA AL QUE SOLO NECESITE PASARLE EL NÚMERO DE CUENTA 

                do {

                    System.out.println("INDIQUE UN NÚMERO DE CUENTA: ");
                    cuenta = new Cuenta(sc.nextInt());

                    if (cuentas.indexOf(cuenta) == -1) {

                        System.out.println("EL NÚMERO DE CUENTA INDICADO NO TIENE COMO TITULAR EL DNI " + dni + ". ");

                    }

                } while (cuentas.indexOf(cuenta) == -1); // NECESITO REDEFINIR EL MÉTODO EQUALS EN LA CLASE CUENTA PARA QUE PUEDA COMPARAR POR EL NÚMERO DE CUENTA 

                int numero = 0;

                Vector<Tarjeta> tarjetas = bd.mostrarTarjetas();

                for (int i = 0; i < tarjetas.size(); i += 1) {

                    if (tarjetas.get(i).getNumero() > numero) {

                        numero = tarjetas.get(i).getNumero();

                    }

                }

                sc.nextLine();

                System.out.println("INDIQUE UN TITULAR PARA LA TARJETA DE DÉBITO: ");
                String titular = sc.nextLine();

                System.out.println("INDIQUE UNA CLAVE PARA LA TARJETA DE DÉBITO: ");
                String clave = sc.nextLine();

                bd.altaTarjeta((numero + 1), cuenta.getNumero(), titular, 0, "D", LocalDate.now().plusMonths(6), clave, false);

            }

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static void sacarCredito() {

        int numero;

        Tarjeta tarjeta;

        boolean existe, tipoCorrecto, claveCorrecta, limiteSuperado;

        try {

            do {

                do {

                    System.out.println("INTRODUZCA EL NÚMERO DE LA TARJETA DE CRÉDITO: ");
                    numero = sc.nextInt();

                    tarjeta = bd.buscarTarjeta(numero);

                    existe = tarjeta != null; // SI EL MÉTODO ".buscarTarjeta()" RETORNA NULL QUERRÁ DECIR QUE NO EXISTE [(null != null) = false] 

                    if (!existe) {

                        System.out.println("EL NÚMERO DE LA TARJETA INTRODUCIDO NO SE ENCUENTRA EN LA BASE DE DATOS. ");

                    }

                } while (!existe);

                tipoCorrecto = tarjeta.getTipo().equalsIgnoreCase("C");

                if (!tipoCorrecto) {

                    System.out.println("EL NÚMERO DE LA TARJETA INTRODUCIDO NO COINCIDE CON UNA TARJETA DE CRÉDITO. ");

                } else if (tarjeta.isBloqueada()) {

                    System.out.println("LA TARJETA DE CRÉDITO INDICADA SE ENCUENTRA BLOQUEADA. ");

                }

            } while (!tipoCorrecto || tarjeta.isBloqueada());

            sc.nextLine();

            do {

                System.out.println("INTRODUZCA LA CLAVE DE LA TARJETA DE CRÉDITO:  ");
                claveCorrecta = tarjeta.getClave().equalsIgnoreCase(sc.nextLine());

                if (!claveCorrecta) {

                    System.out.println("LA CLAVE INTRODUCIDA NO COINCIDE CON LA CLAVE DE LA TARJETA DE CRÉDITO. ");

                }

            } while (!claveCorrecta);

            double importe;

            do {

                System.out.println("INTRODUZCA LA CANTIDAD DE DINERO A SACAR: ");
                importe = sc.nextDouble();

                limiteSuperado = importe > tarjeta.getLimite();

                if (limiteSuperado) {

                    System.out.println("LA CANTIDAD DE DINERO A SACAR NO PUEDE SUPERAR LOS " + tarjeta.getLimite() + " €. ");

                }

            } while (limiteSuperado);

            bd.sacarCredito(numero, importe);

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static void sacarDebito() {

        int numero;

        Tarjeta tarjeta;

        boolean existe, tipoCorrecto, claveCorrecta, saldoNegativo;

        try {

            do {

                do {

                    System.out.println("INTRODUZCA EL NÚMERO DE LA TARJETA DE DÉBITO: ");
                    numero = sc.nextInt();

                    tarjeta = bd.buscarTarjeta(numero);

                    existe = tarjeta != null; // SI EL MÉTODO ".buscarTarjeta()" RETORNA NULL QUERRÁ DECIR QUE NO EXISTE [(null != null) = false] 

                    if (!existe) {

                        System.out.println("EL NÚMERO DE LA TARJETA INTRODUCIDO NO SE ENCUENTRA EN LA BASE DE DATOS. ");

                    }

                } while (!existe);

                tipoCorrecto = tarjeta.getTipo().equalsIgnoreCase("D");

                if (!tipoCorrecto) {

                    System.out.println("EL NÚMERO DE LA TARJETA INTRODUCIDO NO COINCIDE CON UNA TARJETA DE DÉBITO. ");

                } else if (tarjeta.isBloqueada()) {

                    System.out.println("LA TARJETA DE DÉBITO INDICADA SE ENCUENTRA BLOQUEADA. ");

                }

            } while (!tipoCorrecto || tarjeta.isBloqueada());

            sc.nextLine();

            do {

                System.out.println("INTRODUZCA LA CLAVE DE LA TARJETA DE DÉBITO:  ");
                claveCorrecta = tarjeta.getClave().equalsIgnoreCase(sc.nextLine());

                if (!claveCorrecta) {

                    System.out.println("LA CLAVE INTRODUCIDA NO COINCIDE CON LA CLAVE DE LA TARJETA DE DÉBITO. ");

                }

            } while (!claveCorrecta);

            Cuenta cuenta = bd.buscarCuenta(tarjeta.getCuenta());

            double importe;

            do {

                System.out.println("INTRODUZCA LA CANTIDAD DE DINERO A SACAR: ");
                importe = sc.nextDouble();

                saldoNegativo = ((cuenta.getSaldo() - importe) < 0);

                if (saldoNegativo) {

                    System.out.println("LA CANTIDAD DE DINERO A SACAR NO PUEDE SUPERAR LOS " + cuenta.getSaldo() + " €. ");

                }

            } while (saldoNegativo);

            bd.sacarDebito(tarjeta.getCuenta(), importe, cuenta.getSaldo());

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static void cargarMovimientos() {

        int numero;

        Tarjeta tarjeta;

        boolean existe, tipoCorrecto;

        try {

            do {

                do {

                    System.out.println("INTRODUZCA EL NÚMERO DE LA TARJETA DE CRÉDITO: ");
                    numero = sc.nextInt();

                    tarjeta = bd.buscarTarjeta(numero);

                    existe = tarjeta != null; // SI EL MÉTODO ".buscarTarjeta()" RETORNA NULL QUERRÁ DECIR QUE NO EXISTE [(null != null) = false] 

                    if (!existe) {

                        System.out.println("EL NÚMERO DE LA TARJETA INTRODUCIDO NO SE ENCUENTRA EN LA BASE DE DATOS. ");

                    }

                } while (!existe);

                tipoCorrecto = tarjeta.getTipo().equalsIgnoreCase("C");

                if (!tipoCorrecto) {

                    System.out.println("EL NÚMERO DE LA TARJETA INTRODUCIDO NO COINCIDE CON UNA TARJETA DE CRÉDITO. ");

                }

            } while (!tipoCorrecto);

            Cuenta cuenta = bd.buscarCuenta(tarjeta.getCuenta());

            bd.cargarMovimientosCommit(cuenta, tarjeta);

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static void informacionTitular() {

        System.out.println("INTRODUZCA EL NOMBRE DE UN TITULAR DE UNA TARJETA: ");
        String titular = sc.nextLine();

        try {

            Vector<Tarjeta> tarjetas = bd.buscarTarjetas(titular);

            if (!tarjetas.isEmpty()) {

                for (int i = 0; i < tarjetas.size(); i += 1) {

                    System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");

                    System.out.println(tarjetas.get(i).toString());

                    System.out.println(bd.buscarCuenta(tarjetas.get(i).getCuenta()).toString());

                    System.out.println("*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");

                }

            }

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static void importarMovimientos() {

        try {

            bd.importarMovimientos();

        } catch (ErrorBaseDatos e) {

            System.out.println("CONTACTE CON SISTEMAS: " + e.getMessage());

        }

    }

    public static int menu() {

        do {

            System.out.println("INDIQUE UNA DE LAS SIGUIENTES OPCIONES: "
                    + "\n\t1. DAR DE ALTA UNA TARJETA DE CRÉDITO "
                    + "\n\t2. DAR DE ALTA UNA TARJETA DE DÉBITO "
                    + "\n\t3. SACAR DINERO DE UNA TARJETA DE CRÉDITO "
                    + "\n\t4. SACAR DINERO DE UNA TARJETA DE DÉBITO "
                    + "\n\t5. CARGAR MOVIMIENTOS DE UNA TARJETA DE CRÉDITO "
                    + "\n\t6. MOSTRAR INFORMACIÓN DE UN TITULAR ESPECÍFICO "
                    + "\n\t7. IMPORTAR MOVIMIENTOS DEL FICHERO EN LA BASE DE DATOS "
                    + "\n\t8. FINALIZAR LA EJECUCIÓN ");
            opcion = sc.nextInt();

            if (opcion < 1 || opcion > 8) {

                System.out.println("LA OPCIÓN INDICADA NO ES VÁLIDA. ");

            }

        } while (opcion < 1 || opcion > 8);

        return opcion;

    }

}
