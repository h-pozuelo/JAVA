/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.*;
import ejercicio.tarjetas.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import modelos.Cuenta;
import modelos.Movimiento;
import modelos.Tarjeta;

/**
 *
 * @author Hugo
 */
public class BD_Tarjetas extends BD_Conector {

    private static Statement s;
    private static ResultSet reg;

    public BD_Tarjetas(String file) {
        super(file);
    }

    public Vector<Cuenta> mostrarCuentas(String dni) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. VECTOR 
            2. VECTOR VACÍO 
            3. EXCEPCIÓN 
         */
        Vector<Cuenta> cuentas = new Vector<Cuenta>();

        String cadenaSQL = String.format("SELECT * FROM cuentas WHERE titular1='%1$s' OR titular2='%1$s' OR titular3='%1$s'", dni);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                LocalDate fecha = reg.getDate("fecha").toLocalDate();
                cuentas.add(new Cuenta(reg.getInt("número"), reg.getString("titular1"), reg.getString("titular2"), reg.getString("titular3"), reg.getDouble("saldo"), fecha));
            }
            s.close();
            this.cerrar();
            return cuentas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public Tarjeta buscarTarjeta(int numero) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. TARJETA 
            2. NULL 
            3. EXCEPCIÓN 
         */
        Tarjeta tarjeta = null;

        String cadenaSQL = String.format("SELECT * FROM tarjetas WHERE numero='%1$s'", numero);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                LocalDate caducidad = reg.getDate("caducidad").toLocalDate();
                tarjeta = new Tarjeta(reg.getInt("numero"), reg.getInt("cuenta"), reg.getString("titular"), reg.getDouble("limite"), reg.getString("tipo"), caducidad, reg.getString("clave"), reg.getBoolean("bloqueada"));
            }
            s.close();
            this.cerrar();
            return tarjeta;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public Cuenta buscarCuenta(int numero) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. CUENTA 
            2. NULL 
            3. EXCEPCIÓN 
         */
        Cuenta cuenta = null;

        String cadenaSQL = String.format("SELECT * FROM cuentas WHERE número='%1$s'", numero);

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            if (reg.next()) {
                LocalDate fecha = reg.getDate("fecha").toLocalDate();
                cuenta = new Cuenta(reg.getInt("número"), reg.getString("titular1"), reg.getString("titular2"), reg.getString("titular3"), reg.getDouble("saldo"), fecha);
            }
            s.close();
            this.cerrar();
            return cuenta;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public int altaTarjeta(int numero, int cuenta, String titular, double limite, String tipo, LocalDate caducidad, String clave, boolean bloqueada) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. FILAS 
            2. EXCEPCIÓN 
         */
        String cadenaSQL = "INSERT INTO tarjetas VALUES(?,?,?,?,?,?,?,?)";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            PreparedStatement ps = c.prepareStatement(cadenaSQL);
            ps.setInt(1, numero);
            ps.setInt(2, cuenta);
            ps.setString(3, titular);
            ps.setDouble(4, limite);
            ps.setString(5, tipo);
            ps.setDate(6, java.sql.Date.valueOf(caducidad));
            ps.setString(7, clave);
            ps.setBoolean(8, bloqueada);
            int filas = ps.executeUpdate(); // A UN OBJETO "PreparedStatement" NO SE LE NECESITA PASAR LA "cadenaSQL" A DIFERENCIA DE UN OBJETO "Statement" 
            ps.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public Vector<Tarjeta> mostrarTarjetas() throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. VECTOR 
            2. VECTOR VACÍO 
            3. EXCEPCIÓN 
         */
        Vector<Tarjeta> tarjetas = new Vector<Tarjeta>();

        String cadenaSQL = "SELECT * FROM tarjetas";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                LocalDate fecha = reg.getDate("caducidad").toLocalDate();
                tarjetas.add(new Tarjeta(reg.getInt("numero"), reg.getInt("cuenta"), reg.getString("titular"), reg.getDouble("limite"), reg.getString("tipo"), fecha, reg.getString("clave"), reg.getBoolean("bloqueada")));
            }
            s.close();
            this.cerrar();
            return tarjetas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public int sacarCredito(int tarjeta, double importe) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. FILAS 
            2. EXCEPCIÓN 
         */
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("yyyy-LL-dd");

        int numero = 0;

        String cadenaSQL = "SELECT numero FROM movimientos";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                if (reg.getInt(1) > numero) {
                    numero = reg.getInt(1);
                }
            }
            s.close();
            this.cerrar();

            cadenaSQL = "INSERT INTO movimientos VALUES(?,?,?,?,?)";

            System.out.println("INSTRUCCIÓN: " + cadenaSQL);

            this.abrir();
            PreparedStatement ps = c.prepareStatement(cadenaSQL);
            ps.setInt(1, (numero + 1));
            ps.setInt(2, tarjeta);
            ps.setBoolean(3, false);
            ps.setDouble(4, importe);
            ps.setDate(5, java.sql.Date.valueOf(LocalDate.now().format(patron)));
            int filas = ps.executeUpdate();
            ps.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public int sacarDebito(int numero, double importe, double saldo) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. FILAS 
            2. EXCEPCIÓN 
         */
        String cadenaSQL = "UPDATE cuentas SET saldo=? WHERE número=?";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            PreparedStatement ps = c.prepareStatement(cadenaSQL);
            ps.setDouble(1, (saldo - importe));
            ps.setInt(2, numero);
            int filas = ps.executeUpdate();
            ps.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public int cargarMovimientos(Cuenta cuenta, Tarjeta tarjeta) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. FILAS 
            2. EXCEPCIÓN 
         */
        Vector<Movimiento> movimientos = new Vector<Movimiento>();

        double importe = 0;

        String cadenaSQL = String.format("SELECT * FROM movimientos WHERE tarjeta='%1$s' AND cargado='0'", tarjeta.getNumero());

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL);
            while (reg.next()) {
                LocalDate fecha = reg.getDate("fecha").toLocalDate();
                movimientos.add(new Movimiento(reg.getInt("numero"), reg.getInt("tarjeta"), reg.getBoolean("cargado"), reg.getDouble("importe"), fecha));
                importe += reg.getDouble("importe");
            }
            s.close();
            this.cerrar();

            cadenaSQL = "UPDATE cuentas SET saldo=? WHERE número=?";

            System.out.println("INSTRUCCIÓN: " + cadenaSQL);

            this.abrir();
            PreparedStatement ps = c.prepareStatement(cadenaSQL);
            ps.setDouble(1, (cuenta.getSaldo() - importe));
            ps.setInt(2, cuenta.getNumero());
            int filas = ps.executeUpdate();
            ps.close();
            this.cerrar();

            cadenaSQL = "UPDATE movimientos SET cargado='1' WHERE numero=?";

            System.out.println("INSTRUCCIÓN: " + cadenaSQL);

            this.abrir();
            ps = c.prepareStatement(cadenaSQL);
            for (int i = 0; i < movimientos.size(); i += 1) {
                ps.setInt(1, movimientos.get(i).getNumero());
                ps.executeUpdate();
            }
            ps.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public boolean cargarMovimientosCommit(Cuenta cuenta, Tarjeta tarjeta) throws ErrorBaseDatos {

        double total = 0;
        boolean correcto = true;
        String cadenaSQL1 = "SELECT SUM(importe) FROM movimientos WHERE tarjeta=" + tarjeta.getNumero() + " AND cargado=0";
        String cadenaSQL2 = "UPDATE movimientos SET cargado=1 WHERE tarjeta=" + tarjeta.getNumero() + " AND cargado=0";

        try {

            this.abrir();
            c.setAutoCommit(false); // SI EJECUTAMOS 'c.setAutoCommit(false)' CUALQUIER CONSULTA QUE EJECUTEMOS POSTERIORMENTE NO TENDRÁ EFECTO DIRECTO EN LA BASE DE DATOS HASTA QUE EJECUTEMOS 'c.commit()' 
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL1);
            reg.next(); // NO ES NECESARIO METER A 'reg.next()' DENTRO DE UN 'if' DADO QUE LA CONSULTA SIEMPRE ME VA A DEVOLVER UN VALOR (SUMA O CERO) 
            total = reg.getDouble(1); // VOLCAMOS EL VALOR DE 'reg.getDouble(1)' EN LA VARIABLE 'total' 
            String cadenaSQL3 = "UPDATE cuentas SET saldo=(saldo-" + total + ") WHERE número=(SELECT cuenta FROM tarjetas WHERE numero=" + tarjeta.getNumero() + ")";
            System.out.println("IMPORTE TOTAL: " + total + " €");
            if (total > 0) { // SOLO SERÁ NECESARIO CARGAR MOVIMIENTOS SI EL IMPORTE TOTAL SUPERA CERO 
                s.executeUpdate(cadenaSQL2);
                System.out.println("LOS MOVIMIENTOS SE HAN CARGADO CORRECTAMENTE. ");
                if (s.executeUpdate(cadenaSQL3) == 0) { // SI LA CONSULTA 'cadenaSQL3' DEVUELVE CERO FILAS ACTUALIZADAS (NO SE HA ACTUALIZADO EL SALDO) SERÁ NECESARIO REALIZAR ROLLBACK 
                    System.out.println("[REALIZANDO ROLLBACK] NO SE HA PODIDO ACTUALIZAR EL SALDO. ");
                    c.rollback(); // REVIERTE CUALQUIER CONSULTA DE MODIFICACIÓN QUE HAYA SIDO EJECUTADA 
                    correcto = false;
                } else {
                    System.out.println("EL SALDO SE HA ACTUALIZADO CORRECTAMENTE. ");
                }
            }
            s.close();
            c.commit();
            /*
            c.setAutoCommit(true); // NO ES NECESARIO EJECUTAR 'c.setAutoCommit(true)' SI CERRAMOS LA CONEXIÓN CON LA BASE DE DATOS 
             */
            this.cerrar();

        } catch (SQLException e) {

            try {

                System.out.println("[REALIZANDO ROLLBACK]");
                c.rollback();

            } catch (SQLException x) {

                System.out.println("NO SE HA PODIDO REALIZAR EL ROLLBACK. ");

            } finally {

                this.cerrar();
                correcto = false;

            }

        }

        return correcto;

    }

    public Vector<Tarjeta> buscarTarjetas(String titular) throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. VECTOR 
            2. VECTOR VACÍO 
            3. EXCEPCIÓN 
         */
        Vector<Tarjeta> tarjetas = new Vector<Tarjeta>();

        String cadenaSQL = "SELECT * FROM tarjetas WHERE titular=?";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            PreparedStatement ps = c.prepareStatement(cadenaSQL);
            ps.setString(1, titular);
            reg = ps.executeQuery();
            while (reg.next()) {
                if (!reg.getDate("caducidad").toLocalDate().isBefore(LocalDate.now())) {
                    LocalDate caducidad = reg.getDate("caducidad").toLocalDate();
                    tarjetas.add(new Tarjeta(reg.getInt("numero"), reg.getInt("cuenta"), reg.getString("titular"), reg.getDouble("limite"), reg.getString("tipo"), caducidad, reg.getString("clave"), reg.getBoolean("bloqueada")));
                }
            }
            ps.close();
            this.cerrar();
            return tarjetas;

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        }

    }

    public void importarMovimientos() throws ErrorBaseDatos {
        /*
        VALORES QUE PUEDE RETORNAR: 
            1. EXCEPCIÓN 
         */
        DateTimeFormatter patron = DateTimeFormatter.ofPattern("yyyy-LL-dd");

        Path file = Paths.get("movimientos.txt");

        Charset charset = Charset.forName("UTF-8");

        BufferedReader reader = null;

        try {

            reader = Files.newBufferedReader(file, charset);
            String line = null;

            String cadenaSQL = "INSERT INTO movimientos VALUES(?,?,?,?,?)";

            System.out.println("INSTRUCCIÓN: " + cadenaSQL);

            this.abrir();
            PreparedStatement ps = c.prepareStatement(cadenaSQL);
            while ((line = reader.readLine()) != null) {
                String datos[] = line.split(" ");
                ps.setInt(1, Integer.parseInt(datos[0]));
                ps.setInt(2, Integer.parseInt(datos[1]));
                ps.setBoolean(3, Boolean.parseBoolean(datos[2]));
                ps.setDouble(4, Double.parseDouble(datos[3]));
                ps.setDate(5, java.sql.Date.valueOf(LocalDate.parse(datos[4], patron)));
                ps.executeUpdate();
            }
            ps.close();
            this.cerrar();

        } catch (IOException e) {

            throw new ErrorBaseDatos("");

        } catch (SQLException e) {

            this.cerrar();
            throw new ErrorBaseDatos("");

        } finally {

            if (reader != null) {

                try {

                    reader.close();

                } catch (IOException e) {

                    throw new ErrorBaseDatos("");

                }

            }

        }

    }

}
