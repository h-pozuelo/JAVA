/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public class Tarjeta {

    private int numero;
    private int cuenta;
    private String titular;
    private double limite;
    private String tipo;
    private LocalDate caducidad;
    private String clave;
    private boolean bloqueada;

    public Tarjeta(int numero, int cuenta, String titular, double limite, String tipo, LocalDate caducidad, String clave, boolean bloqueada) {
        this.numero = numero;
        this.cuenta = cuenta;
        this.titular = titular;
        this.limite = limite;
        this.tipo = tipo;
        this.caducidad = caducidad;
        this.clave = clave;
        this.bloqueada = bloqueada;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDate getCaducidad() {
        return caducidad;
    }

    public void setCaducidad(LocalDate caducidad) {
        this.caducidad = caducidad;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public boolean isBloqueada() {
        return bloqueada;
    }

    public void setBloqueada(boolean bloqueada) {
        this.bloqueada = bloqueada;
    }

    @Override
    public String toString() {
        return "Tarjeta{" + "numero=" + numero + ", cuenta=" + cuenta + ", titular=" + titular + ", limite=" + limite + ", tipo=" + tipo + ", caducidad=" + caducidad + ", clave=" + clave + ", bloqueada=" + bloqueada + '}';
    }

}
