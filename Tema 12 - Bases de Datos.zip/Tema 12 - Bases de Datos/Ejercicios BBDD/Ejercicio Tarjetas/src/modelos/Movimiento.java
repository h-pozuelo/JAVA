/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public class Movimiento {

    private int numero;
    private int tarjeta;
    private boolean cargado;
    private double importe;
    private LocalDate fecha;

    public Movimiento(int numero, int tarjeta, boolean cargado, double importe, LocalDate fecha) {
        this.numero = numero;
        this.tarjeta = tarjeta;
        this.cargado = cargado;
        this.importe = importe;
        this.fecha = fecha;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(int tarjeta) {
        this.tarjeta = tarjeta;
    }

    public boolean isCargado() {
        return cargado;
    }

    public void setCargado(boolean cargado) {
        this.cargado = cargado;
    }

    public double getImporte() {
        return importe;
    }

    public void setImporte(double importe) {
        this.importe = importe;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Movimiento{" + "numero=" + numero + ", tarjeta=" + tarjeta + ", cargado=" + cargado + ", importe=" + importe + ", fecha=" + fecha + '}';
    }

}
