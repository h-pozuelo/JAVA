/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelos;

import java.time.LocalDate;

/**
 *
 * @author Hugo
 */
public class Cuenta {

    private int numero; // SI NO VAMOS A REALIZAR OPERACIONES LO PODEMOS PONER COMO TIPO DE DATO String 
    private String titular1;
    private String titular2;
    private String titular3;
    private double saldo;
    private LocalDate fecha;

    public Cuenta(int numero, String titular1, String titular2, String titular3, double saldo, LocalDate fecha) {
        this.numero = numero;
        this.titular1 = titular1;
        this.titular2 = titular2;
        this.titular3 = titular3;
        this.saldo = saldo;
        this.fecha = fecha;
    }

    public Cuenta(int numero, String titular1, String titular2, double saldo, LocalDate fecha) {
        this.numero = numero;
        this.titular1 = titular1;
        this.titular2 = titular2;
        this.titular3 = "0";
        this.saldo = saldo;
        this.fecha = fecha;
    }

    public Cuenta(int numero, String titular1, double saldo, LocalDate fecha) {
        this.numero = numero;
        this.titular1 = titular1;
        this.titular2 = "0";
        this.titular3 = "0";
        this.saldo = saldo;
        this.fecha = fecha;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTitular1() {
        return titular1;
    }

    public void setTitular1(String titular1) {
        this.titular1 = titular1;
    }

    public String getTitular2() {
        return titular2;
    }

    public void setTitular2(String titular2) {
        this.titular2 = titular2;
    }

    public String getTitular3() {
        return titular3;
    }

    public void setTitular3(String titular3) {
        this.titular3 = titular3;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "numero=" + numero + ", titular1=" + titular1 + ", titular2=" + titular2 + ", titular3=" + titular3 + ", saldo=" + saldo + ", fecha=" + fecha + '}';
    }

    public Cuenta(int numero) {
        this.numero = numero;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cuenta other = (Cuenta) obj;
        return this.numero == other.numero;
    }

}
