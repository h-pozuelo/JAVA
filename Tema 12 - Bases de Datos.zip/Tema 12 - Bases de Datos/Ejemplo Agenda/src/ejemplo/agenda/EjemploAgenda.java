/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplo.agenda;

import java.io.*;
import java.util.*;
import modelos.Contacto;
import bbdd.*;

/**
 *
 * @author Hugo
 */
public class EjemploAgenda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int opcion = 0;
        String nombre = "", apellidos = "", telefono = "";
        Contacto ct;
        BD_Agenda bd = new BD_Agenda("agenda");

        do {

            System.out.println("1. NUEVO CONTACTO"
                    + "\n2. BORRAR CONTACTO "
                    + "\n3. CONSULTAR TELÉFONO "
                    + "\n4. MOSTRAR CONTACTOS "
                    + "\n5. SALIR ");

            try {

                opcion = Integer.parseInt(br.readLine());

            } catch (NumberFormatException e) {

                System.out.println("OPCIÓN NO VÁLIDA ");
                opcion = 0;

            } catch (IOException e) {

                System.out.println(e.getMessage());
                System.exit(0);

            }

            switch (opcion) {

                case 1:

                    System.out.println("INTRODUZCA NOMBRE: ");
                    nombre = br.readLine();

                    System.out.println("INTRODUZCA APELLIDOS: ");
                    apellidos = br.readLine();

                    System.out.println("INTRODUZCA TELÉFONO: ");
                    telefono = br.readLine();

                    ct = new Contacto(nombre, apellidos, telefono);

                    if (bd.agregarContacto(ct)) {

                        System.out.println("CONTACTO AGREGADO CORRECTAMENTE ");

                    } else {

                        System.out.println("NO SE HA PRODIDO AGREGAR EL CONTACTO ");

                    }

                    break;

                case 2:

                    System.out.println("INTRODUZCA NOMBRE: ");
                    nombre = br.readLine();

                    System.out.println("INTRODUZCA APELLIDOS: ");
                    apellidos = br.readLine();

                    System.out.println("INTRODUZCA TELÉFONO: ");
                    telefono = br.readLine();

                    ct = new Contacto(nombre, apellidos, telefono);

                    int filas = bd.eliminarContacto(ct);

                    switch (filas) {

                        case 0:

                            System.out.println("CONTACTO NO ENCONTRADO ");

                            break;

                        case 1:

                            System.out.println("CONTACTO ELIMINADO CORRECTAMENTE ");

                            break;

                        default:

                            System.out.println("EN ESTE MOMENTO NO PODEMOS ELIMINAR EL CONTACTO. INTÉNTALO MÁS TARDE ");

                            break;

                    }

                    break;

                case 3:

                    System.out.println("INTRODUZCA NOMBRE: ");
                    nombre = br.readLine();

                    System.out.println("INTRODUZCA APELLIDOS: ");
                    apellidos = br.readLine();

                    ct = new Contacto(nombre, apellidos);

                    telefono = bd.buscarTelefono(ct);

                    if (telefono == null) {

                        System.out.println("EN ESTE MOMENTO NO PODEMOS OBTENER EL TELÉFONO. INTÉNTALO MÁS TARDE ");

                    } else {

                        if (telefono.equals("")) {

                            System.out.println("CONTACTO NO ENCONTRADO ");

                        } else {

                            System.out.println("SU TELÉFONO ES: " + telefono);

                        }

                    }

                    break;

                case 4:

                    Vector<Contacto> v = bd.mostrarContactos();

                    for (int i = 0; i < v.size(); i += 1) {

                        System.out.println(v.get(i));

                    }

                    break;

            }

        } while (opcion != 5);

    }

}
