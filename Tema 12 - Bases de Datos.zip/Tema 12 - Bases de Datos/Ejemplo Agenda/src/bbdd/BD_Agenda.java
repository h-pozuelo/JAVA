/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bbdd;

import java.sql.*;
import java.util.*;
import modelos.Contacto;

/**
 *
 * @author Hugo
 */
public class BD_Agenda extends BD_Conector {

    private static Statement s;
    private static ResultSet reg;

    public BD_Agenda(String bbdd) {
        super(bbdd);
    }

    public boolean agregarContacto(Contacto ct) {

        // String cadenaSQL = "INSERT INTO contactos VALUES('" + ct.getNombre() + "','" + ct.getApellidos() + "','" + ct.getTelefono() + "')";
        /*
        String cadenaSQL = "INSERT INTO contactos VALUES('$1','$2','$3')"
                .replace("$1", ct.getNombre())
                .replace("$2", ct.getApellidos())
                .replace("$3", ct.getTelefono());
         */
        // String cadenaSQL = "INSERT INTO contactos VALUES('%s','%s','%s')".formatted(ct.getNombre(), ct.getApellidos(), ct.getTelefono());
        // String cadenaSQL = "INSERT INTO contactos VALUES('%1$s','%2$s','%3$s')".formatted(ct.getNombre(), ct.getApellidos(), ct.getTelefono());
        String cadenaSQL = String.format("INSERT INTO contactos VALUES('%1$s','%2$s','%3$s')", ct.getNombre(), ct.getApellidos(), ct.getTelefono());

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            /*
            LA VARIABLE c ES UN DATO HEREDADO DE LA CLASE PADRE BD_Conector (PROTECTED) 
            LA FUNCIÓN DEL CONECTOR ES ESTABLECER UNA CONEXIÓN ENTRE LA BASE DE DATOS (MYSQL) Y LA APLICACIÓN (JAVA) 
             */
            s = c.createStatement(); // CONSTRUIMOS UN OBJETO Statement (INSTRUCCIÓN) QUE TENDRÁ EL VALOR DEL CONECTOR (c.createStatement()) Y LO ALMACENAMOS EN LA VARIABLE Statement (s) 
            s.executeUpdate(cadenaSQL); // EJECUTAMOS LA INSTRUCCIÓN ALMACENADA EN LA VARIABLE cadenaSQL EN LA CONEXIÓN QUE SE ENCUENTRA ALMACENADA EN LA VARIABLE s 
            s.close();
            this.cerrar(); // SIEMPRE QUE HAYAMOS ABIERTO UNA CONEXIÓN CON LA BASE DE DATOS DEBEMOS DE CERRARLA DESPUÉS 
            return true;

        } catch (SQLException e) {

            System.out.println(e.getMessage());
            this.cerrar();
            return false;

        }

    }

    /*
    EL MÉTODO .executeUpdate() SIRVE PARA [INSERT] [DELETE] [UPDATE] 
    EL MÉTODO .executeQuery() SIRVE PARA [SELECT] 
     */
    public int eliminarContacto(Contacto ct) {

        String cadenaSQL = String.format("DELETE FROM contactos WHERE nombre='%1$s' AND apellidos='%2$s' AND telefono='%3$s'", ct.getNombre(), ct.getApellidos(), ct.getTelefono());

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            int filas = s.executeUpdate(cadenaSQL); // EL MÉTODO .executeUpdate() DEVOLVERÁ EL NÚMERO DE FILAS [INSERTED] [DELETED] [UPDATED] 
            if (filas == 0) {
                System.out.println("NINGÚN CONTACTO COINCIDE CON LOS DATOS INDICADOS. ");
            }
            s.close();
            this.cerrar();
            return filas;

        } catch (SQLException e) {

            this.cerrar();
            return -1;

        }

    }

    public String buscarTelefono(Contacto ct) { // EN LA CLASE Contacto SE ENCUENTRA UN CONSTRUCTOR QUE SOLO REQUIERE INDICAR EL NOMBRE Y LOS APELLIDOS 

        String cadenaSQL = String.format("SELECT telefono FROM contactos WHERE nombre='%1$s' AND apellidos='%2$s'", ct.getNombre(), ct.getApellidos());

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            String t = "";
            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL); // CUANDO EJECUTAMOS EL MÉTODO .executeQuery() DEBE ALMACENARSE EN UNA VARIABLE DE TIPO ResultSet (CONJUNTO DE RESULTADOS) 
            /*
            EL MÉTODO .executeQuery() DEVOLVERÁ UNA LISTA CON TODOS LOS REGISTROS QUE COINCIDAN CON EL CRITERIO DE LA INSTRUCCIÓN EJECUTADA 
            EN CADA CELDA DE LA LISTA (reg) SE ENCUENTRA UN OBJETO CONFORMADO POR LOS CAMPOS SELECCIONADOS A TRAVÉS DE LA INSTRUCCIÓN PREVIA 
            LOS OBJETOS TIENEN UN NÚMERO DE CELDAS QUE COINCIDEN CON LA CANTIDAD DE CAMPOS SELECCIONADOS (SIENDO [1] LA PRIMERA CELDA Y NO [0]) 
             */
            if (reg.next()) { // EL MÉTODO .next() DEVOLVERÁ NULL SI NO QUEDA NINGÚN OTRO REGISTRO EN LA LISTA (reg) 
                t = reg.getString(1);
            }
            /*
            SIEMPRE ES NECESARIO EJECUTAR EL MÉTODO .next() AUNQUE SOLO VAYAMOS A RECUPERAR UN REGISTRO DADO QUE ANTES DEBE POSICIONARSE EN EL PRIMER REGISTRO 
            SI HUBIERAN VARIOS REGISTROS EN LA LISTA (reg) SERÍA NECESARIO CREAR UN BUCLE QUE ITERE EL MÉTODO .next() HASTA QUE DEVUELVA NULL 
             */
            s.close();
            this.cerrar();
            return t;

        } catch (SQLException e) {

            this.cerrar();
            return null;

        }

    }

    public Vector<Contacto> mostrarContactos() {

        Vector<Contacto> v = new Vector<Contacto>(); // TODOS LOS CONTACTOS QUE ENCUENTRE EN LA BASE DE DATOS (MYSQL) SERÁN ALMACENADOS EN ESTE VECTOR 

        String cadenaSQL = "SELECT * FROM contactos";

        System.out.println("INSTRUCCIÓN: " + cadenaSQL);

        try {

            this.abrir();
            s = c.createStatement();
            reg = s.executeQuery(cadenaSQL); // TODOS LOS REGISTROS QUE SE ENCUENTREN EN LA BASE DE DATOS (MYSQL) SERÁN ALMACENADOS EN LA VARIABLE reg (LISTA ESPECIAL) 
            while (reg.next()) { // MIENTRAS HAYA UN REGISTRO (.next()) SE EJECUTARÁ EL BUCLE MOSTRANDO EL SIGUIENTE REGISTRO DE LA BASE DE DATOS (MYSQL) 
                // v.add(new Contacto(reg.getString(1), reg.getString(2), reg.getString(3)));
                v.add(new Contacto(reg.getString("nombre"), reg.getString("apellidos"), reg.getString("telefono"))); // CADA REGISTRO QUE SE ENCUENTRE EN LA BASE DE DATOS (MYSQL) SE ALMACENARÁ EN EL VECTOR EN FORMA DE OBJETO Contacto 
            }
            /*
            CUANDO OBTENEMOS EL DATO DEL REGISTRO EXISTEN DOS FORMAS: 
                1. ESPECIFICAR EL NÚMERO DEL CAMPO [ 1 - ... ] 
                2. ESPECIFICAR EL NOMBRE DEL CAMPO 
            SEGÚN EL TIPO DE DATO QUE CORRESPONDE AL CAMPO DEBEMOS DE EJECUTAR UN .get CORRESPONDIENTE 
             */
            s.close();
            this.cerrar();
            return v;

        } catch (SQLException e) {

            this.cerrar();
            return null;

        }

    }

}
